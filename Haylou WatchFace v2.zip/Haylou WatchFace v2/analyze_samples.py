# -*- coding: utf-8 -*-
"""Анализ реальных .tbwf из папки samples: сводная таблица + docs/format_analysis.md.

Запуск:  python analyze_samples.py
Печатает таблицу по элементам (поля, значения, кадры, свойства) и пишет
отчёт в docs/format_analysis.md. Нужен, чтобы архитектура опиралась на факты,
а не на догадки.
"""

from __future__ import annotations

import os
import sys
from collections import OrderedDict, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from haylou import catalog, constants, tbwf
from haylou.model import DialElement

SAMPLES = constants.SAMPLES_DIR


def analyse(folder: str):
    """Собрать статистику по всем файлам папки."""
    files = sorted(f for f in os.listdir(folder) if f.lower().endswith(".tbwf"))
    per_element = OrderedDict()      # имя -> данные
    all_kinds = defaultdict(int)
    all_props = defaultdict(int)
    all_sections = defaultdict(int)
    all_colors = defaultdict(int)
    fonts = defaultdict(int)
    resources = defaultdict(int)
    info_files = []
    errors = []

    for fname in files:
        path = os.path.join(folder, fname)
        try:
            doc, res = tbwf.load(path)
        except Exception as exc:                       # noqa: BLE001
            errors.append((fname, str(exc)))
            continue
        info_files.append((fname, len(doc), len(res), doc.aspect_ratio,
                           doc.case_shape, doc.version))
        for el in doc.all_elements():
            all_kinds[el.kind] += 1
            if el.properties is not None:
                all_props[int(el.properties)] += 1
            all_sections[int(el.get_sections())] += 1
            for c in el.get_colors():
                all_colors[int(c)] += 1
            if el.kind == "font":
                fonts[str(el.get_resource())] += 1
            elif el.kind in ("resourceImage", "resourceCharacter"):
                resources[str(el.get_resource())] += 1
            key = el.name
            rec = per_element.setdefault(key, {
                "files": set(), "kinds": set(), "fields": set(),
                "sections": set(), "props": set(), "colors": set(),
                "grads": set(), "visible_false": 0, "count": 0,
            })
            rec["files"].add(fname)
            rec["kinds"].add(el.kind)
            rec["fields"].update(el.payload.keys())
            rec["fields"].update(el.extra.keys())
            rec["sections"].add(int(el.get_sections()))
            if el.properties is not None:
                rec["props"].add(int(el.properties))
            rec["grads"].add(el.get_gradient())
            rec["colors"].update(int(c) for c in el.get_colors())
            rec["count"] += 1
            if not el.visible:
                rec["visible_false"] += 1
    return (files, info_files, per_element, all_kinds, all_props, all_sections,
            all_colors, fonts, resources, errors)


def _fmt_set(values, limit: int = 8) -> str:
    items = sorted(values, key=lambda v: (str(type(v)), v)) if values else []
    txt = ", ".join(str(v) for v in items[:limit])
    if len(items) > limit:
        txt += " …(+%d)" % (len(items) - limit)
    return txt or "—"


def build_report(folder: str = SAMPLES) -> str:
    (files, info_files, per_element, all_kinds, all_props, all_sections,
     all_colors, fonts, resources, errors) = analyse(folder)

    lines = []
    add = lines.append
    add("# Разбор реальных файлов .tbwf (Haylou RS5)")
    add("")
    add("Сгенерировано скриптом `analyze_samples.py` по папке `samples/`.")
    add("")
    add("## Файлы")
    add("")
    add("| Файл | Элементов | Ресурсов | aspectRatio | caseShape | version |")
    add("|---|---|---|---|---|---|")
    for fname, count, res_count, aspect, shape, version in info_files:
        add("| %s | %d | %d | %.8f | %s | %s |" % (fname, count, res_count, aspect,
                                                    shape, version))
    add("")
    if errors:
        add("Файлы с ошибками разбора: " + "; ".join("%s: %s" % e for e in errors))
        add("")

    add("## Итоги по формату")
    add("")
    add("- Всего файлов: %d, элементов: %d" % (len(files), sum(
        r["count"] for r in per_element.values())))
    add("- Виды элементов: " + ", ".join("%s ×%d" % (k, v)
                                         for k, v in sorted(all_kinds.items())))
    add("- Значения `sections`: " + _fmt_set(set(all_sections), 12))
    add("- Значения `properties`: " + _fmt_set(set(all_props), 20))
    add("- Встреченные цвета (int32): " + _fmt_set(set(all_colors), 12))
    add("- Шрифты: " + _fmt_set(set(fonts), 12))
    add("")
    add("## Элементы: поля и значения")
    add("")
    add("| Элемент | Вид | Поля | sections | properties | visible=false | Файлов |")
    add("|---|---|---|---|---|---|---|")
    for name, rec in per_element.items():
        add("| %s | %s | %s | %s | %s | %d | %d |" % (
            name, "/".join(sorted(rec["kinds"])), _fmt_set(rec["fields"], 10),
            _fmt_set(rec["sections"], 6), _fmt_set(rec["props"], 6),
            rec["visible_false"], len(rec["files"])))
    add("")
    add("## Ресурсы в архивах (resourceImage / resourceCharacter)")
    add("")
    for res_name, count in sorted(resources.items()):
        add("- `%s` — %d раз" % (res_name, count))
    add("")
    add("## Что формат НЕ поддерживает (проверено по всем файлам)")
    add("")
    add("- Нет полей `rotation` / `angle` — вращать можно только стрелки "
        "(hourHand/minuteHand/secondHand), их крутит само приложение.")
    add("- Нет полей `condition` / `if` / `opacity` — условий по данным нет, "
        "только выбор кадра из `sections`.")
    add("- Нет анимации по времени (кроме покадровых секвенций `sections`).")
    add("- Нет пользовательских SVG и своих иконок: `resourceIcon.resource` — "
        "id из встроенной библиотеки Hello Haylou (30 штук).")
    add("- Свои шрифты — только файл в `/font/` с расширением .ttf и точным именем.")
    add("- Нет слоёв вне фиксированных имён: имя ключа = смысл элемента.")
    add("")
    return "\n".join(lines)


def print_table(folder: str = SAMPLES) -> None:
    """Кратко в консоль — для отчёта о приёмке."""
    (files, info_files, per_element, all_kinds, all_props, all_sections,
     all_colors, fonts, resources, errors) = analyse(folder)
    print("Файлов .tbwf: %d" % len(files))
    for fname, count, res_count, aspect, shape, version in info_files:
        print("  %-32s элементов=%-3d ресурсов=%-3d aspect=%.8f %s v%s"
              % (fname, count, res_count, aspect, shape, version))
    print()
    print("Виды:", ", ".join("%s=%d" % (k, v) for k, v in sorted(all_kinds.items())))
    print("sections:", _fmt_set(set(all_sections), 12))
    print("properties:", _fmt_set(set(all_props), 20))
    print()
    print("%-26s %-22s %-18s %-14s %s" % ("элемент", "вид", "sections", "properties", "файлов"))
    for name, rec in per_element.items():
        print("%-26s %-22s %-18s %-14s %d" % (
            name, "/".join(sorted(rec["kinds"])), _fmt_set(rec["sections"], 5),
            _fmt_set(rec["props"], 5), len(rec["files"])))
    if errors:
        print()
        for fname, msg in errors:
            print("ОШИБКА %s: %s" % (fname, msg))


def main() -> int:
    folder = sys.argv[1] if len(sys.argv) > 1 else SAMPLES
    if not os.path.isdir(folder):
        print("Папка не найдена:", folder)
        return 2
    print_table(folder)
    text = build_report(folder)
    os.makedirs(constants.DOCS_DIR, exist_ok=True)
    path = os.path.join(constants.DOCS_DIR, "format_analysis.md")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    print()
    print("Отчёт записан:", path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
