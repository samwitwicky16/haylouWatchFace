---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 56020588027136572418f452aa62d880_ddec5d4ee38c11f189bc525400248c00
    ReservedCode1: 0K0Vc6D7RImlJVtjvfUvKjjBq7XAUPXfAYPAyMTMSjAOEO2ynGG93N7syYrwmH5YqEys68IWzqfiexLMS1IIqR1xCZ/9t3CYivExcqgz+YKjiTphwyZXTF7Xt3OTxuwsHK2JplncikuLBLPupDv6UbYu/+saP+88gRY45jl7XcSW+dPA+u+ZfJA9jDk=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 56020588027136572418f452aa62d880_ddec5d4ee38c11f189bc525400248c00
    ReservedCode2: 0K0Vc6D7RImlJVtjvfUvKjjBq7XAUPXfAYPAyMTMSjAOEO2ynGG93N7syYrwmH5YqEys68IWzqfiexLMS1IIqR1xCZ/9t3CYivExcqgz+YKjiTphwyZXTF7Xt3OTxuwsHK2JplncikuLBLPupDv6UbYu/+saP+88gRY45jl7XcSW+dPA+u+ZfJA9jDk=
---

# Разбор реальных файлов .tbwf (Haylou RS5)

Сгенерировано скриптом `analyze_samples.py` по папке `samples/`.

## Файлы

| Файл | Элементов | Ресурсов | aspectRatio | caseShape | version |
|---|---|---|---|---|---|
| ais23.tbwf | 30 | 4 | 0.82142854 | rectangle | 1.0 |
| apple_7_green-rs4.tbwf | 30 | 5 | 0.85714287 | rectangle | 1.0 |
| bekasi_ds.tbwf | 30 | 24 | 0.82142854 | rectangle | 1.0 |
| calculadora_-_cian.tbwf | 27 | 26 | 0.82142854 | rectangle | 1.0 |
| casio_2223.tbwf | 27 | 2 | 0.82142854 | rectangle | 1.0 |
| duze_haylou_rs4.tbwf | 27 | 3 | 0.85714287 | rectangle | 1.0 |
| geba-a.tbwf | 27 | 11 | 0.82142854 | rectangle | 1.0 |
| geba_2.tbwf | 30 | 53 | 0.82142854 | rectangle | 1.0 |
| orange454.tbwf | 30 | 56 | 0.82142854 | rectangle | 1.0 |
| trainer-rs4.tbwf | 30 | 23 | 0.82142854 | rectangle | 1.0 |

## Итоги по формату

- Всего файлов: 10, элементов: 288
- Виды элементов: font ×140, none ×4, resourceCharacter ×30, resourceIcon ×89, resourceImage ×25
- Значения `sections`: 1, 2, 5, 7, 10, 11, 12, 14, 16
- Значения `properties`: 1, 2, 4, 16, 17, 20, 32, 33, 34, 36, 64, 65, 68
- Встреченные цвета (int32): -16449714, -16448251, -15996929, -14698753, -13763073, -12824065, -12237499, -10496513, -10132123, -9145228, -9079435, -7427393 …(+17)
- Шрифты: /font/DS-DIGIB.ttf, /font/MJletter2.ttf, /font/digital-7.ttf, big_shoulders_text_medium, big_shoulders_text_regular, fira_sans_condensed_bold, fira_sans_condensed_medium, fira_sans_condensed_regular, oswald_bold, oswald_medium, rubik_bold, rubik_light …(+5)

## Элементы: поля и значения

| Элемент | Вид | Поля | sections | properties | visible=false | Файлов |
|---|---|---|---|---|---|---|
| dial | resourceImage | height, mimeType, resource, sections, size, width | 1 | — | 0 | 10 |
| hour | font/resourceCharacter | family, resource, sections, size | 1, 10, 11, 12 | 32 | 0 | 10 |
| timeSeparator | font/resourceCharacter | family, resource, sections, size | 1, 11 | 32 | 6 | 10 |
| minute | font/resourceCharacter | family, resource, sections, size | 1, 10, 11, 12 | 32 | 0 | 10 |
| second | font/resourceCharacter | family, resource, sections, size | 1, 12 | — | 7 | 10 |
| hourHand | resourceIcon | pivotY, resource, sections, size | 1 | 1, 2 | 8 | 10 |
| minuteHand | resourceIcon | pivotY, resource, sections, size | 1 | 1, 2 | 8 | 10 |
| secondHand | resourceIcon | pivotY, resource, sections, size | 1 | 1, 2, 4 | 8 | 10 |
| year | font/resourceCharacter | family, resource, sections, size | 1, 11 | — | 4 | 6 |
| yearSeparator | font | family, size | 1 | — | 6 | 6 |
| month | font/resourceCharacter | family, resource, sections, size | 1, 11, 12, 14 | 16, 32 | 2 | 10 |
| dateSeparator | font/resourceCharacter | family, resource, sections, size | 1, 14 | — | 8 | 10 |
| day | font/resourceCharacter | family, resource, sections, size | 1, 11, 12, 14 | 32 | 0 | 10 |
| dayOfWeek | font/resourceImage | family, resource, sections, size | 1, 7 | 17, 33, 34, 65 | 2 | 10 |
| connectionResource | resourceIcon/resourceImage | resource, sections, size | 1, 2 | — | 5 | 10 |
| battery | font/resourceCharacter | family, resource, sections, size | 1, 12, 14 | 4, 20, 36 | 2 | 10 |
| batteryPercentSign | font | family, size | 1 | — | 9 | 10 |
| batteryResource | none/resourceIcon/resourceImage | resource, sections, size | 1, 5, 11 | — | 2 | 10 |
| weatherTemperature | font/resourceCharacter | family, resource, sections, size | 1, 14 | 4, 20, 36, 68 | 3 | 10 |
| weatherTemperatureUnitSign | font | family, size | 1 | 1, 4 | 10 | 10 |
| weatherResource | resourceIcon | resource, sections, size | 16 | — | 4 | 10 |
| step | font/resourceCharacter | family, resource, sections, size | 1, 12, 14 | 16 | 2 | 10 |
| stepResource | none/resourceIcon/resourceImage | height, mimeType, resource, sections, size, width | 1 | — | 4 | 10 |
| stepGoalProgressResource | none/resourceIcon/resourceImage | resource, sections, size | 1, 11 | — | 2 | 6 |
| calorie | font | family, size | 1 | 16, 64 | 6 | 10 |
| calorieResource | resourceIcon/resourceImage | height, mimeType, resource, sections, size, width | 1 | — | 7 | 10 |
| distance | font/resourceCharacter | family, resource, sections, size | 1, 12, 14 | 16, 64 | 4 | 10 |
| distanceResource | resourceIcon | resource, sections, size | 1 | — | 8 | 10 |
| heartRate | font/resourceCharacter | family, resource, sections, size | 1, 12, 14 | 16, 32 | 2 | 10 |
| heartRateResource | resourceIcon/resourceImage | height, mimeType, resource, sections, size, width | 1 | — | 5 | 10 |

## Ресурсы в архивах (resourceImage / resourceCharacter)

- `/resourceCharacter/Bateria /` — 2 раз
- `/resourceCharacter/Green/` — 1 раз
- `/resourceCharacter/Hora /` — 12 раз
- `/resourceCharacter/Hora/` — 6 раз
- `/resourceCharacter/Kilómetros /` — 8 раз
- `/resourceCharacter/White/` — 1 раз
- `/resourceImage/batteryResource/` — 4 раз
- `/resourceImage/calorieResource.png` — 1 раз
- `/resourceImage/connectionResource/` — 1 раз
- `/resourceImage/dayOfWeek/` — 2 раз
- `/resourceImage/dial.png` — 10 раз
- `/resourceImage/heartRateResource.png` — 1 раз
- `/resourceImage/stepGoalProgressResource/` — 3 раз
- `/resourceImage/stepResource.png` — 3 раз

## Что формат НЕ поддерживает (проверено по всем файлам)

- Нет полей `rotation` / `angle` — вращать можно только стрелки (hourHand/minuteHand/secondHand), их крутит само приложение.
- Нет полей `condition` / `if` / `opacity` — условий по данным нет, только выбор кадра из `sections`.
- Нет анимации по времени (кроме покадровых секвенций `sections`).
- Нет пользовательских SVG и своих иконок: `resourceIcon.resource` — id из встроенной библиотеки Hello Haylou (30 штук).
- Свои шрифты — только файл в `/font/` с расширением .ttf и точным именем.
- Нет слоёв вне фиксированных имён: имя ключа = смысл элемента.
*（内容由AI生成，仅供参考）*
