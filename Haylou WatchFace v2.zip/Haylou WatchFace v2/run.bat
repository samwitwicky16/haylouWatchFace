@echo off
rem ============================================================================
rem  Haylou Watchface Studio — запуск одним щелчком (Windows)
rem  Требуется Python 3.10+ и установленный Pillow:  pip install -r requirements.txt
rem ============================================================================
chcp 65001 >nul
cd /d "%~dp0"

set "PY=C:\Python312\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" main.py %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
    echo.
    echo Программа завершилась с кодом %RC%.
    echo Подробности — в файле projects\error.log
    pause
)
