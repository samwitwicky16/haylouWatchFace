# -*- coding: utf-8 -*-
"""
================================================================================
 HAYLOU WATCHFACE STUDIO — визуальный редактор циферблатов .tbwf (Haylou RS5)
================================================================================

 УСТАНОВКА
 ---------
 1. Установите Python 3.10–3.12 для Windows (проверено на 3.12.10).
 2. В папке проекта выполните:

        pip install -r requirements.txt

    Единственная внешняя зависимость — Pillow (PNG и рендер превью).
    tkinter входит в стандартную поставку Python для Windows.

 3. (Необязательно) положите образцы .tbwf в папку C:\\Haylou\\samples —
    они нужны для пункта меню «Образцы» и для самотеста.

 ЗАПУСК
 ------
        python main.py                     обычный запуск
        run.bat                            то же двойным щелчком
        python main.py --autoclose 8       авто-закрытие через 8 секунд
        python main.py --open samples\\a.tbwf
        python main.py --new minimal       сразу пустая заготовка
        python main.py --debug             подробный лог в консоль

 ПРОВЕРКА БЕЗ GUI
 ----------------
        python selftest.py

================================================================================
"""

from __future__ import annotations

import argparse
import datetime as _dt
import os
import sys
import traceback
from typing import Optional


# ------------------------------------------------------------------ DPI-aware
def _enable_dpi_awareness() -> None:
    """Сообщить Windows, что окно рисуется в физических пикселях.

    Без этого вызова система растягивает интерфейс, и текст выглядит мылом.
    """
    if not sys.platform.startswith("win"):
        return
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)   # per-monitor v2
        except Exception:                                    # noqa: BLE001
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:                                        # noqa: BLE001
        pass


# --------------------------------------------------------- корень в sys.path
def _prepare_import_path() -> str:
    """Разрешить импорт пакета haylou при любом рабочем каталоге."""
    root = os.path.dirname(os.path.abspath(__file__))
    if root not in sys.path:
        sys.path.insert(0, root)
    return root


ROOT = _prepare_import_path()
_enable_dpi_awareness()

from haylou import __version__, constants                     # noqa: E402
from haylou.gui.app import App                                # noqa: E402


# ------------------------------------------------------------------ лог ошибок
def _write_crash_log(text: str) -> Optional[str]:
    """Дописать аварийный трейсбек в projects/error.log."""
    try:
        os.makedirs(os.path.dirname(constants.ERROR_LOG), exist_ok=True)
        with open(constants.ERROR_LOG, "a", encoding="utf-8") as fh:
            fh.write("\n=== %s ===\n%s\n"
                     % (_dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), text))
        return constants.ERROR_LOG
    except OSError:
        return None


def _install_global_hook() -> None:
    """Перехватить фатальные исключения вне цикла tkinter."""
    def _hook(exc_type, exc_value, exc_tb):
        text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        sys.stderr.write(text)
        path = _write_crash_log(text)
        if path:
            sys.stderr.write("\nПодробности записаны в %s\n" % path)

    sys.excepthook = _hook


# ------------------------------------------------------------------ аргументы
def _parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="main.py",
        description="Haylou Watchface Studio — редактор циферблатов .tbwf (RS5 %dx%d)"
                    % (constants.SCREEN_W, constants.SCREEN_H),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Пример: python main.py --open samples\\duze_haylou_rs4.tbwf")
    parser.add_argument("--open", metavar="ФАЙЛ", default=None,
                        help="открыть .tbwf (или .haylou.json) при старте")
    parser.add_argument("--new", metavar="ШАБЛОН", default=None,
                        choices=["empty", "minimal", "full"],
                        help="создать заготовку: empty / minimal / full")
    parser.add_argument("--autoclose", metavar="СЕК", type=float, default=0.0,
                        help="закрыть окно автоматически через N секунд (для тестов)")
    parser.add_argument("--debug", action="store_true",
                        help="печатать отладочные сообщения в консоль")
    parser.add_argument("--version", action="version",
                        version="Haylou Watchface Studio %s" % __version__)
    return parser.parse_args(argv)


# ------------------------------------------------------------------ точка входа
def main(argv=None) -> int:
    """Создать окно редактора и войти в цикл событий."""
    args = _parse_args(argv)
    _install_global_hook()

    for folder in (constants.PROJECT_DIR, constants.PROJECTS_DIR, constants.DOCS_DIR,
                   constants.EXAMPLES_DIR, constants.SAMPLES_DIR):
        try:
            os.makedirs(folder, exist_ok=True)
        except OSError:
            pass

    print("Haylou Watchface Studio %s — экран %dx%d, aspectRatio %.8f"
          % (__version__, constants.SCREEN_W, constants.SCREEN_H,
             constants.ASPECT_RATIO))

    try:
        app = App(autoclose=args.autoclose)
    except Exception as exc:                                 # noqa: BLE001
        text = traceback.format_exc()
        sys.stderr.write(text)
        path = _write_crash_log(text)
        print("Не удалось создать окно: %s%s"
              % (exc, ("\nЛог: %s" % path) if path else ""), file=sys.stderr)
        return 2

    if args.debug:
        app.note("Отладочный режим включён")

    # ---- открытие файла или шаблона при старте
    if args.open:
        target = args.open
        if not os.path.isabs(target):
            target = os.path.join(ROOT, target)
        if os.path.exists(target):
            try:
                app.open_path(target)
                print("Открыт файл: %s" % target)
            except Exception as exc:                         # noqa: BLE001
                text = traceback.format_exc()
                _write_crash_log(text)
                app.note("Не удалось открыть %s: %s" % (target, exc), error=True)
        else:
            app.note("Файл не найден: %s" % target, error=True)
    elif args.new:
        try:
            app.new_document(args.new)
            print("Создана заготовка: %s" % args.new)
        except Exception as exc:                             # noqa: BLE001
            _write_crash_log(traceback.format_exc())
            app.note("Не удалось создать заготовку: %s" % exc, error=True)

    try:
        app.mainloop()
    except KeyboardInterrupt:
        app._shutdown()                                      # noqa: SLF001
    print("Окно закрыто.")
    return 0


if __name__ == "__main__":
    sys.exit(main())


# ==============================================================================
# РУКОВОДСТВО ПОЛЬЗОВАТЕЛЯ
# ==============================================================================
"""
1. ОБЩЕЕ УСТРОЙСТВО ОКНА
   Сверху — меню и панель инструментов, слева — превью циферблата 410×502,
   справа — четыре вкладки: «Слои», «Свойства», «Данные», «Ресурсы».
   Внизу — строка состояния: разрешение, координаты курсора (нормализованные),
   число слоёв, признак изменений, масштаб.

   Окно адаптивное: при ширине меньше 1040 px правая панель прячется в
   выдвижной ящик (кнопка «☰» в панели инструментов), при ширине 1040 px и
   больше — закреплена справа (380 px). Положение запоминается до следующего
   изменения размера.

2. ПРЕВЬЮ И МАСШТАБ
   - Колесо мыши — масштаб 25–400 %, Ctrl+0 — вернуть «вписать».
   - Перетаскивание слоя мышью двигает его; при отпускании позиция
     фиксируется в истории (undo), а координаты в свойствах обновляются.
   - Сетка (Ctrl+G) — линии каждые 10 % экрана; безопасная зона (Ctrl+B) —
     область, гарантированно видимая в круглом корпусе часов.
   - Кнопка «▶» проигрывает анимацию (секундная стрелка, моргание), флажок
     «Живые часы» подставляет системное время в симуляцию.

3. СЛОИ (вкладка «Слои»)
   Список отсортирован по порядку отрисовки: сверху — верхний слой.
   Кнопки: добавить типовой слой, дублировать (Ctrl+D), удалить (Del),
   поднять/опустить (Ctrl+↑ / Ctrl+↓), переименовать (F2).
   Справа от имени показан тип и признак видимости. Двойной щелчок —
   выбрать слой и увидеть его рамку на превью.

4. СВОЙСТВА (вкладка «Свойства»)
   - Имя слоя — ключ в JSON; переименование через «…».
   - Тип элемента: font / resourceCharacter / resourceIcon / resourceImage.
   - Положение X, Y — нормализованные 0…1 (0.5 — центр), размер — доля
     ширины экрана; поля и ползунки синхронизированы.
   - properties — целое число, кодирующее источник данных (шаги, пульс,
     погода и т. д.). Панель подсказывает типовое значение для выбранного
     слоя и предупреждает, если число не встречается в образцах RS5.
   - sections — число кадров в полосе ресурса (1, 2, 5, 7, 11, 14, 16).
   - Цвета: до четырёх значений int32 (−1 — белый, 0 — «не перерисовывать»),
     режим градиента solid / linear_vertical. Клик по квадратику открывает
     палитру.
   - Моргание и условия: период «горит / не горит» и простое условие показа
     (батарея, погода, ночь и т. п.). Сложные условия редактируются в JSON;
     если формат их не гарантирует, панель предлагает «запечь» слой в фон.

5. ДАННЫЕ (вкладка «Данные»)
   Симулятор показаний: время (вручную или «Сейчас»), шаги и цель, калории,
   дистанция, пульс, заряд и зарядка, 16 состояний погоды, связь с телефоном,
   ночной режим, язык дня недели. Кнопка «Демо» подставляет случайный набор,
   «Сброс» — исходные значения. Эти числа влияют только на превью и экспорт,
   в файл .tbwf они не пишутся.

6. РЕСУРСЫ (вкладка «Ресурсы»)
   Таблица всего, что упаковано в проект: путь в JSON, тип, размер, число
   ссылающихся слоёв. Есть превью, импорт PNG, извлечение наружу,
   переименование (ссылки слоёв обновляются автоматически), удаление и
   «Удалить неиспользуемые» — полезно перед сохранением, чтобы не раздувать
   файл. Двойной щелчок по ресурсу выделяет первый использующий его слой.

7. ФАЙЛЫ И ЭКСПОРТ
   - Открыть: .tbwf (zip с TiBoWaFe.json) и проекты *.haylou.json.
   - Сохранить / Сохранить как — пишет .tbwf с чистым JSON: служебные ключи
     (_blink, _cond, _note) вырезаются, aspectRatio приводится к 0.81673307.
   - Экспорт PNG: 410×502 и ×2 (820×1004) — для проверки и превью в сторе.
   - «Запечь в фон»: слои, которые формат не гарантирует (сложные условия,
     повороты, прозрачность поверх изображения), рисуются в картинку фона;
     результат — новый документ с одним фоном и оставшимися простыми слоями.
   - Автосохранение: каждые 120 секунд и при закрытии —
     projects\\autosave.haylou.json. При следующем запуске редактор предложит
     восстановить его (не блокируя работу).

8. ПРОВЕРКА ПЕРЕД УСТАНОВКОЙ НА ЧАСЫ
   Меню «Правка → Проверить» прогоняет валидатор: неизвестные имена слоёв,
   неподдерживаемые properties/sections, пустые ресурсы, слишком большой
   размер файла, отсутствие обязательных слоёв (часовая, минутная, секундная).
   Ошибки блокируют экспорт, предупреждения — нет.

9. ГОРЯЧИЕ КЛАВИШИ
   Ctrl+N — новая заготовка, Ctrl+O — открыть, Ctrl+S — сохранить,
   Ctrl+Shift+S — сохранить как, Ctrl+Z / Ctrl+Y — отмена / повтор,
   Ctrl+D — дублировать, Del — удалить, F2 — переименовать, Ctrl+G — сетка,
   Ctrl+B — безопасная зона, Ctrl+0 — вписать, Ctrl+E — экспорт PNG,
   Ctrl+T — проверить, F1 — эта справка.

10. ЕСЛИ ЧТО-ТО ПОШЛО НЕ ТАК
   Необработанные ошибки интерфейса попадают в projects\\error.log (полный
   трейсбек) и показываются в строке состояния. При сомнениях запустите
   `python selftest.py` — он проверяет ядро, рендер, чтение образцов,
   валидацию и запекание без участия GUI.
"""
