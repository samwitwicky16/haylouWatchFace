# -*- coding: utf-8 -*-

"""
================================================================================
 HAYLOU WATCHFACE STUDIO — САМОПРОВЕРКА (без GUI)
================================================================================

 УСТАНОВКА
 ---------
        pip install -r requirements.txt

 ЗАПУСК
 ------
        python selftest.py
        python selftest.py --verbose

 Что проверяется:
   1) импорт всех модулей ядра и константы устройства;
   2) конвертация цветов int32 <-> #RRGGBB;
   3) каталог: 30 имён элементов, 30 официальных иконок, роли/типовые значения;
   4) заготовки empty / minimal / full и их отрисовка;
   5) чтение всех образцов samples/*.tbwf, рендер в docs/preview_*.png,
      round-trip (сохранение -> перечитывание) с проверкой layers/properties/
      sections/colors;
   6) рендер всех 30 официальных иконок;
   7) симуляция: 16 состояний погоды, пороги заряда, ночь, Bluetooth;
   8) «запекание» в фон (bake) с записью файла в examples/;
   9) валидатор на намеренно испорченном документе;
  10) undo/redo.

 В конце печатается «SELFTEST PASSED» и число проверок. Код возврата 0 —
   всё хорошо, 1 — есть провалы (подробности в консоли).
================================================================================
"""

from __future__ import annotations

import argparse
import io
import os
import shutil
import sys
import tempfile
import traceback
from typing import Any, Dict, List, Tuple

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from haylou import __version__, bake, catalog, colors, conditions, constants
from haylou import history, model, renderer, tbwf, templates, validate

PASSED = 0
FAILED: List[str] = []
WARNINGS: List[str] = []
VERBOSE = False


# ---------------------------------------------------------------- утилиты вывода
def ok(message: str) -> None:
    """Отметить успешную проверку."""
    global PASSED
    PASSED += 1
    print("  OK   %s" % message)


def fail(message: str, exc: Any = None) -> None:
    """Отметить провал, но не останавливать прогон."""
    text = message
    if exc is not None:
        text += ": %s" % exc
    FAILED.append(text)
    print("  FAIL %s" % text)
    if VERBOSE and exc is not None:
        traceback.print_exc()


def warn(message: str) -> None:
    WARNINGS.append(message)
    print("  WARN %s" % message)


def step(title: str) -> None:
    print("\n[%s]" % title)


def guard(title: str):
    """Декоратор: исключение внутри шага превращается в FAIL, прогон идёт дальше."""
    def _decorator(func):
        def _wrapped(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as exc:                  # noqa: BLE001
                fail(title, exc)
                return None
        return _wrapped
    return _decorator


def _ensure_dirs() -> None:
    for folder in (constants.SAMPLES_DIR, constants.DOCS_DIR, constants.EXAMPLES_DIR,
                   constants.PROJECTS_DIR):
        os.makedirs(folder, exist_ok=True)


# ---------------------------------------------------------------- 1. константы
@guard("Константы устройства")
def test_constants() -> None:
    step("1. Константы устройства")
    if (constants.SCREEN_W, constants.SCREEN_H) != (410, 502):
        fail("Экран должен быть 410x502, получено %dx%d"
             % (constants.SCREEN_W, constants.SCREEN_H))
    else:
        ok("Экран 410x502")
    if abs(constants.ASPECT_RATIO - 0.81673307) > 1e-8:
        fail("aspectRatio RS5 = 0.81673307, получено %r" % constants.ASPECT_RATIO)
    else:
        ok("aspectRatio RS5 = 0.81673307")
    if constants.CASE_SHAPE != "rectangle":
        fail("caseShape должен быть rectangle, получено %r" % constants.CASE_SHAPE)
    else:
        ok("caseShape = rectangle")
    if len(constants.OBSERVED_PROPERTIES) < 10 or len(constants.OBSERVED_SECTIONS) < 5:
        fail("Списки наблюдаемых properties/sections подозрительно короткие")
    else:
        ok("Наблюдаемые properties: %s" % constants.OBSERVED_PROPERTIES)
        ok("Наблюдаемые sections: %s" % constants.OBSERVED_SECTIONS)


# ---------------------------------------------------------------- 2. цвета
@guard("Цвета int32")
def test_colors() -> None:
    step("2. Цвета int32 <-> #RRGGBB")
    cases = [(-1, "#FFFFFF"), (0, "#000000"), (-16777216, "#000000"),
             (-65536, "#FF0000"), (-16448251, "#050505")]
    for value, expected in cases:
        got = colors.argb_to_hex(value)
        if got.upper() != expected.upper():
            fail("argb_to_hex(%d) = %s, ожидалось %s" % (value, got, expected))
        else:
            ok("argb_to_hex(%d) = %s" % (value, got))
    for text in ("#FFFFFF", "#FF0000", "#123456"):
        back = colors.argb_to_hex(colors.hex_to_argb(text))
        if back.upper() != text.upper():
            fail("Цикл цветов для %s дал %s" % (text, back))
        else:
            ok("Цикл hex -> argb -> hex для %s" % text)
    if colors.to_signed(colors.to_unsigned(-1)) != -1:
        fail("to_signed/to_unsigned не согласованы")
    else:
        ok("Знаковое/беззнаковое представление согласовано")


# ---------------------------------------------------------------- 3. каталог
@guard("Каталог элементов")
def test_catalog() -> None:
    step("3. Каталог имён и иконок")
    names = list(catalog.ELEMENTS.keys())
    if len(names) != 30:
        fail("В каталоге %d имён, ожидалось 30" % len(names))
    else:
        ok("30 имён элементов")
    icons = catalog.OFFICIAL_ICONS
    if len(icons) != 30:
        fail("Официальных иконок %d, ожидалось 30" % len(icons))
    else:
        ok("30 официальных иконок")
    empty_ru = [n for n in names if not catalog.ru_name(n)]
    if empty_ru:
        fail("Без русской подписи: %s" % empty_ru[:5])
    else:
        ok("У всех имён есть русская подпись")
    bad_kind = [n for n in names if catalog.default_kind(n) not in catalog.ALL_KINDS]
    if bad_kind:
        fail("Некорректный default_kind у: %s" % bad_kind[:5])
    else:
        ok("default_kind у всех из допустимых видов")
    for name in ("hourHand", "minuteHand", "secondHand"):
        if not catalog.typical_properties(name):
            fail("У стрелки %s нет типовых properties" % name)
    ok("Типовые properties у стрелок заданы")
    hit = catalog.icons_for_element("hourHand")
    if not hit:
        fail("Для hourHand не нашлось ни одной официальной иконки")
    else:
        ok("Для hourHand доступно иконок: %d" % len(hit))
    if catalog.is_known("совсемНеСлой"):
        fail("is_known() считает известным несуществующее имя")
    else:
        ok("is_known() отвергает неизвестное имя")
    if catalog.our_icon_for("нет-такой-иконки") == "":
        fail("our_icon_for() не вернул запасную иконку")
    else:
        ok("our_icon_for() даёт запасную иконку")


# ---------------------------------------------------------------- 4. заготовки
@guard("Заготовки документов")
def test_templates() -> None:
    step("4. Заготовки empty / minimal / full")
    sizes: Dict[str, int] = {}
    for kind in ("empty", "minimal", "full"):
        doc, res = templates.build_template(kind)
        if not isinstance(doc, model.DialDocument):
            fail("build_template(%r) вернул не DialDocument" % kind)
            continue
        if abs(doc.aspect_ratio - constants.ASPECT_RATIO) > 1e-6:
            fail("Заготовка %s: aspectRatio %r" % (kind, doc.aspect_ratio))
        if kind == "empty":
            need = {"dial", "hour", "minute", "timeSeparator"}
            missing = sorted(need - set(doc.names()))
            if missing:
                fail("Заготовка empty: нет слоёв %s" % ", ".join(missing))
        sizes[kind] = len(doc)
        ok("Заготовка %-7s: слоёв %d, ресурсов %d" % (kind, len(doc), len(res)))
        image = renderer.render_document(doc, conditions.SimState(),
                                         constants.SCREEN_W, constants.SCREEN_H,
                                         resources=renderer.ResourceStore(res))
        if image.size != (constants.SCREEN_W, constants.SCREEN_H):
            fail("Рендер %s дал %r вместо 410x502" % (kind, image.size))
        else:
            ok("Рендер %-7s 410x502 выполнен" % kind)
    if sizes.get("minimal", 0) <= 0 or sizes.get("full", 0) <= sizes.get("minimal", 0):
        fail("Полная заготовка должна быть не меньше минимальной: %s" % sizes)
    else:
        ok("Размеры заготовок монотонны: %s" % sizes)
    for kind in ("empty", "minimal", "full"):
        doc, res = templates.build_template(kind)
        issues = validate.validate_document(doc, res)
        if validate.has_errors(issues) and kind != "empty":
            fail("Заготовка %s не проходит валидацию: %s"
                 % (kind, validate.summarize(issues)))
        else:
            ok("Валидация заготовки %-7s: ошибок нет (замечаний %d)" % (kind, len(issues)))


# ---------------------------------------------------------------- 5. образцы
@guard("Образцы .tbwf")
def test_samples() -> None:
    step("5. Образцы .tbwf: чтение, рендер, round-trip")
    if not os.path.isdir(constants.SAMPLES_DIR):
        warn("Папка samples отсутствует — шаг пропущен")
        return
    files = sorted(f for f in os.listdir(constants.SAMPLES_DIR)
                   if f.lower().endswith(".tbwf"))
    if not files:
        warn("В samples нет файлов .tbwf — шаг пропущен")
        return
    ok("Найдено образцов: %d" % len(files))

    for name in files:
        path = os.path.join(constants.SAMPLES_DIR, name)
        stem = os.path.splitext(name)[0]
        doc, res = tbwf.load(path)
        if len(doc) == 0:
            fail("%s: документ пуст" % name)
            continue
        ratio = float(doc.aspect_ratio)
        if abs(ratio - constants.ASPECT_RATIO) > 1e-6:
            warn("%s: aspectRatio %.8f (RS4-совместимый), в RS5 будет %.8f"
                 % (name, ratio, constants.ASPECT_RATIO))
        store = renderer.ResourceStore(res)
        image = renderer.render_document(doc, conditions.SimState(),
                                         constants.SCREEN_W, constants.SCREEN_H,
                                         resources=store)
        preview = os.path.join(constants.DOCS_DIR, "preview_%s.png" % stem)
        image.save(preview)
        ok("%-26s слоёв %2d, ресурсов %2d -> %s"
           % (name, len(doc), len(res), os.path.basename(preview)))

        # ---- round-trip через временный файл
        tmpdir = tempfile.mkdtemp(prefix="haylou_rt_")
        tmp_path = os.path.join(tmpdir, "roundtrip.tbwf")
        try:
            tbwf.save(doc, tmp_path, res, clean=True)
            doc2, res2 = tbwf.load(tmp_path)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
        if len(doc2) != len(doc):
            fail("%s: после round-trip %d слоёв вместо %d" % (name, len(doc2), len(doc)))
            continue
        mismatches: List[str] = []
        for el in doc.all_elements():
            el2 = doc2.get(el.name)
            if el2 is None:
                mismatches.append("%s: пропал слой" % el.name)
                continue
            if el2.properties != el.properties:
                mismatches.append("%s: properties %r -> %r"
                                  % (el.name, el.properties, el2.properties))
            if el2.get_sections() != el.get_sections():
                mismatches.append("%s: sections %d -> %d"
                                  % (el.name, el.get_sections(), el2.get_sections()))
            if list(el2.get_colors()) != list(el.get_colors()):
                mismatches.append("%s: цвета %s -> %s"
                                  % (el.name, el.get_colors(), el2.get_colors()))
        if mismatches:
            fail("%s: расхождения round-trip: %s" % (name, "; ".join(mismatches[:4])))
        else:
            ok("%-26s round-trip без потерь" % name)
        if len(res2) != len(res):
            # теряться могут только «сироты» — файлы, на которые не ссылается ни один слой;
            # ссылочные ресурсы обязаны выживать после сохранения
            used = tbwf.used_resources(doc, res)
            lost_used = [k for k in used if tbwf.find_key(res2, k) is None]
            if lost_used:
                fail("%s: после round-trip пропали используемые ресурсы: %s"
                     % (name, ", ".join(lost_used[:4])))
            else:
                ok("%s: вычищено %d неиспользуемых ресурсов (это норма)"
                   % (name, len(res) - len(res2)))


# ---------------------------------------------------------------- 6. иконки
@guard("Иконки")
def test_icons() -> None:
    step("6. Рендер 30 официальных иконок")
    drawn = 0
    for info in catalog.OFFICIAL_ICONS:
        icon_name = catalog.our_icon_for(str(info.get("id")))
        image = renderer.icon_image(icon_name, 32, (255, 255, 255, 255))
        if image is None or image.size != (32, 32):
            fail("Иконка %r (%s) не отрисована" % (info.get("id"), icon_name))
            continue
        drawn += 1
    if drawn != len(catalog.OFFICIAL_ICONS):
        fail("Отрисовано %d из %d иконок" % (drawn, len(catalog.OFFICIAL_ICONS)))
    else:
        ok("Все %d иконок отрисованы 32x32" % drawn)


# ---------------------------------------------------------------- 7. симуляция
@guard("Симуляция")
def test_simulation() -> None:
    step("7. Симуляция: погода, батарея, ночь, Bluetooth")
    doc, res = templates.build_template("full")
    store = renderer.ResourceStore(res)

    renders = 0
    for weather in range(16):
        sim = conditions.SimState()
        sim.weather = weather
        image = renderer.render_document(doc, sim, 205, 251, resources=store)
        if image.size != (205, 251):
            fail("Погода %d: неверный размер %r" % (weather, image.size))
        renders += 1
    ok("16 состояний погоды отрисованы")

    for battery in (0, 5, 10, 15, 50, 100):
        for charging in (False, True):
            sim = conditions.SimState()
            sim.battery = battery
            sim.charging = charging
            renderer.render_document(doc, sim, 205, 251, resources=store)
            renders += 1
    ok("Пороги заряда (0/5/10/15/50/100, с зарядкой и без) отрисованы")

    for night in (False, True):
        for connected in (False, True):
            sim = conditions.SimState()
            sim.is_night = night
            sim.connected = connected
            renderer.render_document(doc, sim, 205, 251, resources=store)
            renders += 1
    ok("Ночной режим и потеря Bluetooth отрисованы")

    sim = conditions.SimState()
    sim.random_demo(seed=42)
    renderer.render_document(doc, sim, 205, 251, resources=store)
    ok("Демо-набор значений отрисован")
    ok("Всего кадров симуляции: %d" % (renders + 1))

    cond_el = doc.get("battery") or doc.all_elements()[0]
    conditions.set_blink(cond_el, True, 1.0, 0.5)
    blink = conditions.get_blink(cond_el)
    if not blink.get("enabled") or abs(float(blink.get("on", 0)) - 1.0) > 1e-6:
        fail("set_blink/get_blink не согласованы: %r" % (blink,))
    else:
        ok("Моргание записывается и читается (%s)" % blink)
    conditions.set_blink(cond_el, False)
    conditions.set_condition(cond_el, True, "battery", [{"op": "lt", "value": 20}])
    got = conditions.get_condition(cond_el)
    if not got.get("enabled") or got.get("source") != "battery":
        fail("set_condition/get_condition не согласованы: %r" % (got,))
    else:
        ok("Условие записывается и читается (%s)" % got.get("source"))
    conditions.set_condition(cond_el, False)


# ---------------------------------------------------------------- 8. запекание
@guard("Запекание в фон")
def test_bake() -> None:
    step("8. Запекание в фон (bake)")
    doc, res = templates.build_template("full")
    store = renderer.ResourceStore(res)
    # даём запеканию реальную работу: моргание и условие часы не понимают —
    # такие слои должны «сплющиться» в фон
    conditions.set_blink(doc.get("second"), True)
    conditions.set_condition(doc.get("weatherTemperature"), True, "weather",
                             [{"op": "eq", "value": 2}])
    plan = bake.plan_bake(doc)
    ok("План запекания: %d слоёв" % len(plan))
    new_doc, new_res, report = bake.bake(doc, conditions.SimState(), res,
                                         frames=2, static=False)
    if len(new_doc) >= len(doc):
        warn("После запекания слоёв %d (было %d) — ожидалось меньше"
             % (len(new_doc), len(doc)))
    dict_report = report if isinstance(report, dict) else {}
    ok("Запекание выполнено: слоёв %d, ресурсов %d, отчёт: %s"
       % (len(new_doc), len(new_res),
          bake.describe_report(report)[:120].replace("\n", " ")))
    target = os.path.join(constants.EXAMPLES_DIR, "baked_test.png")
    report2 = bake.bake_to_file(doc, conditions.SimState(), res, target,
                                frames=2, static=False)
    if not os.path.exists(target):
        fail("bake_to_file не создал %s (отчёт: %r)" % (target, report2))
    else:
        size = os.path.getsize(target)
        ok("Файл запекания: %s (%d Б)" % (os.path.basename(target), size))
        if size < 512:
            fail("Файл запекания подозрительно мал: %d Б" % size)
    if not dict_report:
        warn("Отчёт bake() не словарь — GUI-диалог покажет только текст")


# ---------------------------------------------------------------- 9. валидация
@guard("Валидация")
def test_validate() -> None:
    step("9. Валидация испорченного документа")
    doc, res = templates.build_template("minimal")
    clean = validate.validate_document(doc, res)
    if validate.has_errors(clean):
        fail("Чистая заготовка не проходит валидацию: %s" % validate.summarize(clean))
    else:
        ok("Чистая заготовка: ошибок нет")

    broken = doc.clone()
    el = broken.add("hourHandBroken", element=broken.get("hourHand").clone()
                    if broken.get("hourHand") is not None else None)
    el.properties = 999999
    el.payload["resource"] = "/resourceImage/нет_такого_файла.png"
    broken.add("совсемНеизвестныйСлой", element=el.clone())
    issues = validate.validate_document(broken, res)
    if not validate.has_errors(issues):
        fail("Валидатор не нашёл ошибок в испорченном документе")
    else:
        ok("Найдено ошибок: %d" % len([i for i in issues if i.get("level") == "error"]))
        ok("Сводка: %s" % validate.summarize(issues).replace("\n", " ")[:160])

    # пустой документ
    empty_issues = validate.validate_document(model.DialDocument(), {})
    if not validate.has_errors(empty_issues):
        warn("Валидатор считает пустой документ корректным")
    else:
        ok("Пустой документ помечен как ошибочный")


# ---------------------------------------------------------------- 10. история
@guard("Undo/Redo")
def test_history() -> None:
    step("10. Undo/Redo")
    doc, _res = templates.build_template("minimal")
    hist = history.History(limit=10)
    hist.reset(doc, "старт")
    if hist.can_undo():
        fail("После reset() отменять нечего, а can_undo() истинно")
    else:
        ok("После reset() история пуста")

    changed = doc.clone()
    changed.add("tempLayer", element=templates.make_text("tempLayer", 0.5, 0.5, 0.05))
    hist.push(changed, "добавлен слой")
    if not hist.can_undo() or hist.undo_label() != "добавлен слой":
        fail("push() не создал точку отмены (%r)" % (hist.undo_label(),))
    else:
        ok("Точка отмены: %r" % hist.undo_label())

    undone = hist.undo()
    if undone is None or len(undone[0]) != len(doc):
        fail("undo() вернул неожиданное состояние: %r" % (undone,))
    else:
        ok("undo() вернул документ из %d слоёв" % len(undone[0]))
    if not hist.can_redo():
        fail("После undo() недоступен redo")
    else:
        redone = hist.redo()
        if redone is None or "tempLayer" not in redone[0]:
            fail("redo() не вернул добавленный слой")
        else:
            ok("redo() вернул документ из %d слоёв" % len(redone[0]))
    back, forward = hist.depth()
    ok("Глубина истории: отмен %d, повторов %d" % (back, forward))


# ---------------------------------------------------------------- 11. модель
@guard("Модель документа")
def test_model() -> None:
    step("11. Модель: добавление, порядок, клонирование")
    doc, _res = templates.build_template("minimal")
    base = len(doc)
    el = doc.add("testText", element=templates.make_text("testText", 0.5, 0.5, 0.06))
    if len(doc) != base + 1 or doc.get("testText") is None:
        fail("add() не добавил слой")
    else:
        ok("add() добавил слой (всего %d)" % len(doc))
    if el.get_size() is None:
        fail("У нового слоя нет размера")
    else:
        ok("Размер слоя: %.3f" % el.get_size())
    unique = doc.unique_name("testText")
    if unique == "testText":
        fail("unique_name() вернул занятое имя")
    else:
        ok("unique_name(): %s" % unique)
    names = doc.names()
    doc.move_by("testText", -1)
    moved = doc.names()
    if moved == names:
        fail("move_by() не изменил порядок")
    else:
        ok("move_by() изменил порядок слоёв")
    if not doc.rename("testText", "testText2"):
        fail("rename() не сработал")
    else:
        ok("rename() сработал (testText2)")
    clone = doc.clone()
    if len(clone) != len(doc):
        fail("clone() дал %d слоёв вместо %d" % (len(clone), len(doc)))
    else:
        ok("clone() сохранил число слоёв (%d)" % len(clone))
    if not doc.remove("testText2"):
        fail("remove() не удалил слой")
    else:
        ok("remove() удалил слой (осталось %d)" % len(doc))
    text = doc.to_json_text(clean=True)
    if "_blink" in text or "_cond" in text:
        warn("В чистом JSON остались служебные ключи _blink/_cond")
    else:
        ok("Чистый JSON без служебных ключей (%d символов)" % len(text))


# ---------------------------------------------------------------- main
def main(argv=None) -> int:
    global VERBOSE
    parser = argparse.ArgumentParser(description="Самопроверка Haylou Watchface Studio")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="печатать трейсбеки провалов")
    args = parser.parse_args(argv)
    VERBOSE = bool(args.verbose)

    print("=" * 74)
    print(" Haylou Watchface Studio %s — самопроверка" % __version__)
    print(" Python %s" % sys.version.split()[0])
    print("=" * 74)

    try:
        import PIL
        print(" Pillow %s" % getattr(PIL, "__version__", "?"))
    except Exception:                                # noqa: BLE001
        print(" Pillow не найден — превью в GUI работать не будет")

    _ensure_dirs()

    test_constants()
    test_colors()
    test_catalog()
    test_templates()
    test_samples()
    test_icons()
    test_simulation()
    test_bake()
    test_validate()
    test_history()
    test_model()

    print("\n" + "-" * 74)
    print(" Проверок пройдено: %d" % PASSED)
    print(" Предупреждений:    %d" % len(WARNINGS))
    print(" Провалов:          %d" % len(FAILED))
    if WARNINGS:
        print("\n Предупреждения (не блокируют работу):")
        for item in WARNINGS:
            print("   - %s" % item)
    if FAILED:
        print("\n Провалы:")
        for item in FAILED:
            print("   - %s" % item)
        print("\nSELFTEST FAILED")
        return 1
    print("\nSELFTEST PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
