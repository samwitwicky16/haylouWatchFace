# -*- coding: utf-8 -*-
"""Рендерер превью: документ + ресурсы + симуляция -> картинка PIL.

Зачем отдельный слой: один и тот же код рисует превью в окне, PNG-экспорт и
«запекание в фон». Здесь нет tkinter, поэтому рендер можно тестировать без GUI.

Система координат: x/y — доля от ширины/высоты экрана (0…1), size — доля от
ШИРИНЫ экрана (так ведут себя реальные файлы RS5). Стрелки вращаются вокруг
точки (x, y) — в часах это центр экрана.
"""

from __future__ import annotations

import io
import math
import os
from typing import Dict, List, Optional, Sequence, Tuple

from PIL import Image, ImageDraw, ImageFont

from . import catalog, colors, conditions, constants, icons, tbwf

RESAMPLE = getattr(Image, "Resampling", Image).LANCZOS
BICUBIC = getattr(Image, "Resampling", Image).BICUBIC

HAND_ROLES = ("hourHand", "minuteHand", "secondHand")

_FONT_CACHE: Dict[Tuple[str, int], ImageFont.FreeTypeFont] = {}
_ICON_CACHE: Dict[Tuple[str, int, int], Image.Image] = {}


# ---------------------------------------------------------------------------
# Хранилище ресурсов архива
# ---------------------------------------------------------------------------
class ResourceStore:
    """Байты из /resourceImage/ + /resourceCharacter/ + декодированные картинки.

    Ключи храним в «нормализованном» виде (без ведущего слэша), поиск — через
    tbwf.find_key: в реальных архивах встречаются пробелы и разный регистр.
    """

    def __init__(self, raw: Optional[Dict[str, bytes]] = None) -> None:
        self.raw: Dict[str, bytes] = {tbwf.normalize_res_path(k): v
                                      for k, v in (raw or {}).items()}
        self._images: Dict[str, Optional[Image.Image]] = {}
        self._frames: Dict[Tuple[str, int], List[Optional[Image.Image]]] = {}
        self._scaled: Dict[Tuple[str, int, int], Image.Image] = {}

    # --------------------------------------------------------------- данные
    def set_all(self, raw: Dict[str, bytes]) -> None:
        self.raw = {tbwf.normalize_res_path(k): v for k, v in (raw or {}).items()}
        self._images.clear()
        self._frames.clear()
        self._scaled.clear()

    def keys(self) -> List[str]:
        return sorted(self.raw.keys())

    def has(self, path: str) -> bool:
        return tbwf.find_key(self.raw, path) is not None

    def raw_bytes(self, path: str) -> Optional[bytes]:
        key = tbwf.find_key(self.raw, path)
        return self.raw.get(key) if key else None

    def put(self, path: str, data: bytes) -> str:
        """Положить/заменить ресурс; возвращает нормализованный путь."""
        norm = tbwf.normalize_res_path(path)
        old = tbwf.find_key(self.raw, norm)
        if old and old != norm:
            self.raw.pop(old, None)
        self.raw[norm] = data
        self._images.pop(norm, None)
        self._frames.clear()
        return norm

    def remove(self, path: str) -> bool:
        key = tbwf.find_key(self.raw, path)
        if not key:
            return False
        self.raw.pop(key, None)
        self._images.pop(key, None)
        self._frames.clear()
        return True

    # ------------------------------------------------------------- картинки
    def image(self, path: str) -> Optional[Image.Image]:
        key = tbwf.find_key(self.raw, path)
        if not key:
            return None
        if key in self._images:
            return self._images[key]
        img = tbwf.image_from_bytes(self.raw.get(key))
        if img is not None and img.mode != "RGBA":
            img = img.convert("RGBA")
        self._images[key] = img
        return img

    def frames(self, path: str, sections: int) -> List[Optional[Image.Image]]:
        """Кадры ресурса: одиночные файлы x_0.png… или папка с _0.png…"""
        sections = max(1, int(sections or 1))
        key = (tbwf.normalize_res_path(path), sections)
        if key in self._frames:
            return self._frames[key]
        out: List[Optional[Image.Image]] = []
        if sections <= 1:
            out = [self.image(path)]
        else:
            # tbwf.iter_frames отдаёт уже декодированные картинки + пути
            imgs, _paths = tbwf.iter_frames(path, sections, self.raw)
            out = list(imgs) if imgs else [self.image(path)]
        self._frames[key] = out
        return out

    def scaled(self, path: str, width: int, height: int) -> Optional[Image.Image]:
        width, height = max(1, int(width)), max(1, int(height))
        key = (tbwf.normalize_res_path(path), width, height)
        if key in self._scaled:
            return self._scaled[key]
        img = self.image(path)
        if img is None:
            return None
        out = img.resize((width, height), RESAMPLE)
        if len(self._scaled) > 400:
            self._scaled.clear()
        self._scaled[key] = out
        return out

    def glyph(self, folder: str, char: str, px: int) -> Optional[Image.Image]:
        """Глиф цифры/знака для resourceCharacter (файлы _0.png, _colon.png…)."""
        suffix = constants.CHAR_GLYPHS.get(char)
        if not suffix:
            return None
        img = self.image(folder.rstrip("/") + "/" + suffix + ".png")
        if img is None:
            return None
        h = max(1, int(px))
        w = max(1, int(round(img.width * (h / max(1, img.height)))))
        return img.resize((w, h), RESAMPLE)

    def has_glyphs(self, folder: str) -> bool:
        if not folder:
            return False
        for suffix in ("_0", "_1", "_colon"):
            if self.has(folder.rstrip("/") + "/" + suffix + ".png"):
                return True
        return False

    def font_bytes(self, family: str) -> Optional[bytes]:
        """Свой шрифт из архива: family вида '/font/DS-DIGIB.ttf'."""
        if not family.startswith(constants.FONT_DIR.replace("//", "/")):
            family2 = family.lstrip("/")
            if not family2.startswith("font/"):
                return None
            family = "/" + family2
        return self.raw_bytes(family)


class PreviewCache:
    """Совместимое имя (кое-где в коде используется) — это тот же стор."""

    def __new__(cls, raw: Optional[Dict[str, bytes]] = None) -> ResourceStore:  # type: ignore[misc]
        return ResourceStore(raw)


# ---------------------------------------------------------------------------
# Шрифты
# ---------------------------------------------------------------------------
def find_font_file(family: str) -> Optional[str]:
    """Файл TTF на диске для служебного имени шрифта Hello Haylou."""
    candidates = constants.FONT_FILE_CANDIDATES.get(family)
    if not candidates:
        candidates = ["segoeui.ttf", "arial.ttf", "DejaVuSans.ttf"]
    roots = [
        os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Microsoft\Windows\Fonts"),
    ]
    for name in candidates:
        for root in roots:
            if not root:
                continue
            path = os.path.join(root, name)
            if os.path.isfile(path):
                return path
    return None


def load_font(family: str, px: int,
              store: Optional[ResourceStore] = None) -> ImageFont.ImageFont:
    """Шрифт нужного размера: свой из архива -> системный фолбэк."""
    px = max(4, int(px))
    key = (str(family or "sans-serif"), px)
    cached = _FONT_CACHE.get(key)
    if cached is not None:
        return cached
    font: Optional[ImageFont.ImageFont] = None
    data = store.font_bytes(family) if (store and family) else None
    if data:
        try:
            font = ImageFont.truetype(io.BytesIO(data), px)
        except Exception:
            font = None
    if font is None:
        path = find_font_file(str(family or ""))
        try:
            font = ImageFont.truetype(path, px) if path else ImageFont.load_default()
        except Exception:
            font = ImageFont.load_default()
    _FONT_CACHE[key] = font  # type: ignore[assignment]
    return font


def clear_caches() -> None:
    _FONT_CACHE.clear()
    _ICON_CACHE.clear()


# ---------------------------------------------------------------------------
# Значения и углы
# ---------------------------------------------------------------------------
def text_value(role: str, sim: "conditions.SimState",
               element: Optional["tbwf.DialElement"] = None) -> str:
    """Текст для элемента: ручной ввод -> роль -> подсказка-заглушка."""
    if element is not None:
        return conditions.value_for_element(element, sim)
    return conditions.value_for_role(role, sim)


def hand_angle(role: str, sim: "conditions.SimState") -> float:
    """Угол стрелки в градусах (0 — вверх, по часовой стрелке)."""
    v = sim.values()
    h = int(v["hour"]) % 12
    m = int(v["minute"])
    s = int(v["second"])
    if role == "hourHand":
        return (h + m / 60.0 + s / 3600.0) * 30.0
    if role == "minuteHand":
        return (m + s / 60.0) * 6.0
    if role == "secondHand":
        return s * 6.0
    return 0.0


# ---------------------------------------------------------------------------
# Вспомогательная графика
# ---------------------------------------------------------------------------
def placeholder_dial(width: int, height: int) -> Image.Image:
    """Фон-заглушка, если dial.png в проекте ещё нет."""
    img = Image.new("RGBA", (width, height), (16, 18, 22, 255))
    draw = ImageDraw.Draw(img)
    for y in range(height):
        k = y / max(1, height - 1)
        draw.line([(0, y), (width, y)], fill=(int(18 + 16 * k), int(20 + 18 * k),
                                              int(26 + 22 * k), 255))
    step = max(10, width // 12)
    for x in range(0, width, step):
        draw.line([(x, 0), (x, height)], fill=(255, 255, 255, 12))
    for y in range(0, height, step):
        draw.line([(0, y), (width, y)], fill=(255, 255, 255, 12))
    draw.rectangle([0, 0, width - 1, height - 1], outline=(92, 98, 112, 200))
    return img


def icon_image(name: str, px: int, rgba: Tuple[int, int, int, int]) -> Image.Image:
    """Иконка из библиотеки (с кэшем по имени/размеру/цвету)."""
    px = max(2, int(px))
    key = (str(name), px, int(colors.rgba_to_argb(rgba)))
    cached = _ICON_CACHE.get(key)
    if cached is not None:
        return cached
    img = icons.render_icon(str(name), px, rgba)
    if len(_ICON_CACHE) > 600:
        _ICON_CACHE.clear()
    _ICON_CACHE[key] = img
    return img


def _rotate_pivot(img: Image.Image, angle: float,
                  pivot: Tuple[float, float]) -> Tuple[Image.Image, int]:
    """Повернуть картинку вокруг точки pivot; вернуть (canvas, размер).

    Точка вращения попадает ровно в центр canvas — дальше её легко совместить
    с (x, y) элемента. Размер canvas взят с запасом, чтобы не обрезать края.
    """
    w, h = img.size
    half = int(math.ceil(math.hypot(w, h))) + 2
    size = half * 2
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    off_x = int(round(half - pivot[0]))
    off_y = int(round(half - pivot[1]))
    canvas.alpha_composite(img, (off_x, off_y))
    if abs(angle % 360.0) > 0.01:
        canvas = canvas.rotate(-(angle % 360.0), resample=BICUBIC, center=(half, half))
    return canvas, size


def _blit_pivot(canvas: Image.Image, img: Image.Image, angle: float,
                pivot: Tuple[float, float], cx: float, cy: float) -> None:
    """Наложить картинку так, чтобы её pivot оказался в точке (cx, cy)."""
    rot, size = _rotate_pivot(img, angle, pivot)
    canvas.alpha_composite(rot, (int(round(cx - size / 2.0)),
                                 int(round(cy - size / 2.0))))


def element_box(el: "tbwf.DialElement", scale: float) -> Tuple[float, float, float, float]:
    """Габарит элемента в пикселях превью: (x0, y0, x1, y1)."""
    w = constants.SCREEN_W * scale
    h = constants.SCREEN_H * scale
    cx = (el.x if el.x is not None else 0.5) * w
    cy = (el.y if el.y is not None else 0.5) * h
    size = max(2.0, (el.get_size() or 0.06) * w)
    role = catalog.data_role(el.name)
    if role in HAND_ROLES:
        return (cx - size / 2.0, cy - size, cx + size / 2.0, cy + size * 0.1)
    if el.is_text:
        return (cx - size * 1.2, cy - size * 0.7, cx + size * 1.2, cy + size * 0.7)
    return (cx - size / 2.0, cy - size / 2.0, cx + size / 2.0, cy + size / 2.0)


def element_box_screen(el: "tbwf.DialElement",
                       scale: float = 1.0) -> Tuple[int, int, int, int]:
    x0, y0, x1, y1 = element_box(el, scale)
    return int(round(x0)), int(round(y0)), int(round(x1)), int(round(y1))


def element_at(doc: "tbwf.DialDocument", scale: float, x: float, y: float,
               tolerance: float = 4.0) -> Optional[str]:
    """Верхний элемент под курсором (координаты уже в пикселях превью)."""
    for name in reversed(doc.names()):
        el = doc.get(name)
        if el is None or name == "dial":
            continue
        x0, y0, x1, y1 = element_box(el, scale)
        if (x0 - tolerance) <= x <= (x1 + tolerance) and \
                (y0 - tolerance) <= y <= (y1 + tolerance):
            return name
    return "dial" if "dial" in doc else None


# ---------------------------------------------------------------------------
# Отрисовка одного элемента
# ---------------------------------------------------------------------------
def _element_rgba(el: "tbwf.DialElement", sim: "conditions.SimState") -> Tuple[int, int, int, int]:
    """Цвет элемента с учётом правил «по состоянию» (только превью)."""
    cols = el.get_colors() or [0]
    override, _vis = conditions.tint_override(el, sim)
    cond = conditions.evaluate_condition(el, sim)
    if cond and cond.get("color") is not None:
        override = int(cond["color"])
    if override is not None:
        cols = [int(override)]
    default = 0 if el.kind == "resourceIcon" else -1
    argb = colors.first_color(cols, default)
    if el.kind == "resourceIcon" and not colors.is_repaint_enabled(argb):
        argb = -1                      # иконку всё равно нужно видеть в превью
    return colors.argb_to_rgba(argb)


def _frame_index(el: "tbwf.DialElement", sim: "conditions.SimState") -> int:
    cond = conditions.evaluate_condition(el, sim)
    if cond and cond.get("frame") is not None:
        return int(cond["frame"])
    return conditions.resolve_frame_index(el, sim)


def draw_element(canvas: Image.Image, el: "tbwf.DialElement",
                  store: ResourceStore, sim: "conditions.SimState",
                  scale: float, t: float = 0.0,
                  ignore_blink: bool = False) -> None:
    """Нарисовать элемент на канве нужного размера."""
    if el.kind == "none" and el.name != "dial":
        # Служебная запись без ресурса: рисовать нечего
        return
    if not el.visible:
        return
    if not ignore_blink and not conditions.blink_visible(el, t):
        return

    cw, ch = canvas.size
    w = constants.SCREEN_W * scale
    h = constants.SCREEN_H * scale
    cx = (el.x if el.x is not None else 0.5) * w * (cw / max(1.0, w))
    cy = (el.y if el.y is not None else 0.5) * h * (ch / max(1.0, h))
    size_px = max(1, int(round((el.get_size() or 0.06) * w)))
    role = catalog.data_role(el.name)
    rgba = _element_rgba(el, sim)

    # --- фон -----------------------------------------------------------
    if el.name == "dial":
        res = el.get_resource() or (constants.RES_IMAGE_DIR + "dial.png")
        img = store.scaled(res, cw, ch)
        if img is None:
            img = placeholder_dial(cw, ch)
        canvas.alpha_composite(img, (0, 0))
        return

    # --- картинка из архива --------------------------------------------
    if el.kind == "resourceImage":
        frames = store.frames(el.get_resource(), el.get_sections())
        img = None
        if frames:
            idx = max(0, min(len(frames) - 1, _frame_index(el, sim)))
            img = frames[idx] or frames[0]
        if img is None:
            return
        ratio = img.height / max(1, img.width)
        out = img.resize((size_px, max(1, int(round(size_px * ratio)))), RESAMPLE)
        if rgba[3] < 255:
            out = _apply_alpha(out, rgba[3])
        canvas.alpha_composite(out, (int(round(cx - out.width / 2.0)),
                                     int(round(cy - out.height / 2.0))))
        return

    # --- текст системным шрифтом ---------------------------------------
    if el.kind == "font":
        text = conditions.value_for_element(el, sim) or conditions.placeholder_text(el)
        if not text:
            return
        family = str(el.payload.get("family") or "sans-serif")
        font = load_font(family, size_px, store)
        draw = ImageDraw.Draw(canvas)
        anchor = str(el.payload.get("anchor") or "mm")
        try:
            draw.text((cx, cy), text, font=font, fill=rgba, anchor=anchor)  # type: ignore[arg-type]
        except Exception:
            draw.text((cx, cy), text, font=font, fill=rgba)
        return

    # --- текст «своими» картинками (resourceCharacter) -------------------
    if el.kind == "resourceCharacter":
        folder = el.get_resource() or constants.RES_CHAR_DIR
        text = conditions.value_for_element(el, sim) or conditions.placeholder_text(el)
        if not text:
            return
        glyphs = []
        if store.has_glyphs(folder):
            for ch in text:
                g = store.glyph(folder, ch, size_px)
                if g is None:
                    glyphs = []
                    break
                glyphs.append(g)
        if glyphs:
            total = sum(g.width for g in glyphs)
            x = cx - total / 2.0
            for g in glyphs:
                canvas.alpha_composite(g, (int(round(x)), int(round(cy - size_px / 2.0))))
                x += g.width
            return
        font = load_font("sans-serif-medium", size_px, store)
        draw = ImageDraw.Draw(canvas)
        try:
            draw.text((cx, cy), text, font=font, fill=rgba, anchor="mm")
        except Exception:
            draw.text((cx, cy), text, font=font, fill=rgba)
        return

    # --- иконка из библиотеки приложения --------------------------------
    if el.kind == "resourceIcon":
        official = el.get_resource()
        custom = el.extra.get(constants.EXT_CUSTOM_ICON)
        icon_name = custom or catalog.our_icon_for(official) or "dot"
        if role in HAND_ROLES:
            img = icon_image(icon_name, size_px, rgba)
            angle = hand_angle(role, sim)
            # ось вращения — центр нижней кромки (стрелка «растёт» вверх)
            _blit_pivot(canvas, img, angle, (img.width / 2.0, float(img.height)), cx, cy)
            return
        frames = store.frames(el.get_resource(), el.get_sections()) \
            if el.get_sections() > 1 else []
        if frames and not custom:
            idx = max(0, min(len(frames) - 1, _frame_index(el, sim)))
            src = frames[idx]
            if src is not None:
                ratio = src.height / max(1, src.width)
                out = src.resize((size_px, max(1, int(round(size_px * ratio)))), RESAMPLE)
                canvas.alpha_composite(out, (int(round(cx - out.width / 2.0)),
                                             int(round(cy - out.height / 2.0))))
                return
        img = icon_image(icon_name, size_px, rgba)
        canvas.alpha_composite(img, (int(round(cx - img.width / 2.0)),
                                     int(round(cy - img.height / 2.0))))
        return


def _apply_alpha(img: Image.Image, alpha: int) -> Image.Image:
    """Умножить альфу картинки на коэффициент 0…255."""
    alpha = max(0, min(255, int(alpha)))
    if alpha >= 255:
        return img
    r, g, b, a = img.split()
    a = a.point(lambda v: int(v * alpha / 255))
    return Image.merge("RGBA", (r, g, b, a))


# ---------------------------------------------------------------------------
# Публичный API
# ---------------------------------------------------------------------------
def render_document(doc: "tbwf.DialDocument", sim: "conditions.SimState",
                    tw: int, th: int, selected: Optional[str] = None,
                    show_grid: bool = False,
                    resources: Optional[ResourceStore] = None,
                    t: float = 0.0, ignore_blink: bool = False) -> Image.Image:
    """Отрисовать документ в картинку tw x th (масштаб подбирается сам).

    selected — имя слоя, который нужно обвести рамкой (для GUI),
    show_grid — включить сетку 0.1 экрана (для точного позиционирования).
    """
    tw = max(8, int(tw))
    th = max(8, int(th))
    scale = min(tw / float(constants.SCREEN_W), th / float(constants.SCREEN_H))
    canvas = Image.new("RGBA", (tw, th), (12, 14, 18, 255))
    if "dial" not in doc:
        canvas.alpha_composite(placeholder_dial(tw, th), (0, 0))
    store = resources or ResourceStore()
    for el in doc.all_elements():
        draw_element(canvas, el, store, sim, scale, t=t, ignore_blink=ignore_blink)
    if show_grid:
        _draw_grid(canvas)
    if selected:
        el = doc.get(selected)
        if el is not None:
            x0, y0, x1, y1 = element_box_screen(el, scale)
            ImageDraw.Draw(canvas).rectangle([x0, y0, x1, y1],
                                             outline=(0, 200, 255, 255), width=2)
    return canvas


def _draw_grid(canvas: Image.Image) -> None:
    w, h = canvas.size
    draw = ImageDraw.Draw(canvas)
    for i in range(1, 10):
        x = int(w * i / 10.0)
        y = int(h * i / 10.0)
        draw.line([(x, 0), (x, h)], fill=(255, 255, 255, 34))
        draw.line([(0, y), (w, y)], fill=(255, 255, 255, 34))
    draw.line([(0, h // 2), (w, h // 2)], fill=(0, 200, 255, 70))
    draw.line([(w // 2, 0), (w // 2, h)], fill=(0, 200, 255, 70))


def render(doc: "tbwf.DialDocument", store: Optional[ResourceStore],
           sim: "conditions.SimState", t: float = 0.0,
           scale: float = 1.0, ignore_blink: bool = False) -> Image.Image:
    """Совместимая обёртка: кадр в масштабе scale от 410x502."""
    return render_document(doc, sim,
                           int(round(constants.SCREEN_W * scale)),
                           int(round(constants.SCREEN_H * scale)),
                           resources=store, t=t, ignore_blink=ignore_blink)


def render_export(doc: "tbwf.DialDocument", store: Optional[ResourceStore],
                  sim: "conditions.SimState", scale: float = 1.0) -> Image.Image:
    """PNG-экспорт: без «моргания» и без рамок выделения."""
    return render(doc, store, sim, t=0.0, scale=scale, ignore_blink=True)


def render_flat(doc: "tbwf.DialDocument", sim: "conditions.SimState",
                resources: Optional[ResourceStore] = None,
                width: int = constants.SCREEN_W,
                height: int = constants.SCREEN_H) -> Image.Image:
    """Кадр для запекания: все элементы принудительно видимы."""
    clone = doc.clone()
    for el in clone.all_elements():
        el.visible = True
        el.extra.pop(constants.EXT_BLINK, None)
    return render_document(clone, sim, width, height, resources=resources)
