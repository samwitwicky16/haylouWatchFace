# -*- coding: utf-8 -*-
"""Библиотека монохромных векторных иконок (37 штук).

Иконки описаны как SVG-path в системе координат 24x24 и растеризуются
собственным движком (svgpath) с суперсэмплингом — поэтому они выглядят
гладко в любом размере и перекрашиваются в любой цвет.
"""

from __future__ import annotations

import math
from collections import OrderedDict
from typing import Dict, List, Tuple

from PIL import Image

from .svgpath import circle_path, line_path, rect_path, render_shape

# Кэш отрендеренных иконок: (имя, размер, цвет) -> картинка
_CACHE: Dict[Tuple[str, int, Tuple[int, int, int, int]], Image.Image] = {}
_CACHE_LIMIT = 600


def _sh(d: str, fill: bool = True, stroke: float = 0.0) -> dict:
    return {"d": d, "fill": fill, "stroke": stroke}


def _rays(cx: float, cy: float, r1: float, r2: float, count: int = 8,
          start_deg: float = 0.0) -> str:
    """Звезда-лучи одним путём (для солнца, снежинки, шестерёнки)."""
    out = []
    for i in range(count):
        a = math.radians(start_deg + 360.0 * i / count)
        x1 = cx + r1 * math.cos(a)
        y1 = cy + r1 * math.sin(a)
        x2 = cx + r2 * math.cos(a)
        y2 = cy + r2 * math.sin(a)
        out.append(line_path([(x1, y1), (x2, y2)]))
    return "".join(out)


def _branch(cx: float, cy: float, r: float, count: int = 6) -> str:
    """Веточки снежинки: короткие штрихи под углом к лучам."""
    out = []
    for i in range(count):
        a = math.radians(360.0 * i / count)
        px = cx + r * 0.62 * math.cos(a)
        py = cy + r * 0.62 * math.sin(a)
        for d in (-40, 40):
            b = math.radians(360.0 * i / count + d)
            out.append(line_path([(px, py),
                                  (px + r * 0.28 * math.cos(b),
                                   py + r * 0.28 * math.sin(b))]))
    return "".join(out)


def _build_defs() -> "OrderedDict[str, dict]":
    D: "OrderedDict[str, dict]" = OrderedDict()

    def add(name: str, ru: str, group: str, shapes: List[dict]) -> None:
        D[name] = {"ru": ru, "group": group, "shapes": shapes}

    # ---------------------------- Здоровье --------------------------------
    add("heart", "Сердце", "Здоровье", [_sh(
        "M12 21.2C12 21.2 2.8 15.4 2.8 8.6C2.8 5.4 5.2 3 8.3 3"
        "C10.3 3 11.6 4.1 12 5.1C12.4 4.1 13.7 3 15.7 3"
        "C18.8 3 21.2 5.4 21.2 8.6C21.2 15.4 12 21.2 12 21.2Z")])
    add("heart_pulse", "Пульс", "Здоровье", [
        _sh("M20.4 8.6C20.4 5.9 18.4 3.8 15.7 3.8C13.6 3.8 12.3 5.2 12 5.9"
            "C11.7 5.2 10.4 3.8 8.3 3.8C5.6 3.8 3.6 5.9 3.6 8.6"
            "C3.6 14.6 12 20.6 12 20.6C12 20.6 20.4 14.6 20.4 8.6Z",
            fill=False, stroke=1.7),
        _sh(line_path([(4.6, 11.2), (8.4, 11.2), (9.8, 8.2), (11.6, 14.0),
                       (13.2, 9.6), (14.4, 11.2), (19.4, 11.2)]), fill=False, stroke=1.7),
    ])
    add("flame", "Огонь (калории)", "Здоровье", [_sh(
        "M12 2.2C12 2.2 6.6 7.2 6.6 12.4C6.6 16.6 8.9 19.8 12 19.8"
        "C15.1 19.8 17.4 16.6 17.4 12.4C17.4 9.6 15.4 6.8 14.2 5.4"
        "C13.9 7.0 12.9 8.1 11.9 8.6C12.3 6.2 12 2.2 12 2.2Z"),
        _sh("M12 22.2C9.7 22.2 7.9 20.4 7.9 18.1C7.9 16.1 9.4 14.6 12 12.8"
            "C14.6 14.6 16.1 16.1 16.1 18.1C16.1 20.4 14.3 22.2 12 22.2Z",
            fill=False, stroke=1.2)])
    add("footprint", "След ноги", "Здоровье", [
        _sh("M9.4 9.6C10.6 9.6 11.4 10.9 11.4 12.8C11.4 14.7 10.6 16 9.4 16"
            "C8.2 16 7.4 14.7 7.4 12.8C7.4 10.9 8.2 9.6 9.4 9.6Z"),
        _sh("M6.6 17.6C7.9 17.6 8.8 18.6 8.8 19.8C8.8 21 7.9 22 6.6 22"
            "C5.3 22 4.4 21 4.4 19.8C4.4 18.6 5.3 17.6 6.6 17.6Z"),
        _sh(circle_path(14.6, 7.2, 3.3), fill=False, stroke=1.6),
        _sh(circle_path(17.6, 11.6, 2.2), fill=False, stroke=1.4),
    ])
    add("shoe", "Обувь", "Здоровье", [_sh(
        "M3 17.2C3 15.6 4.2 14.4 5.8 14.2C8.2 13.9 9.8 12.6 10.4 10.4"
        "C10.8 8.8 11.4 8 12.4 8C13.4 8 14 8.8 14.2 10.2C14.6 12.6 16.4 14.2 18.8 15"
        "C20.4 15.6 21.2 16.6 21.2 18C21.2 19.4 20 20.2 18.4 20.2H5.2"
        "C3.8 20.2 3 19.2 3 17.2Z"),
        _sh(line_path([(3.4, 17.0), (20.8, 17.0)]), fill=False, stroke=0.9)])
    add("run", "Бег", "Здоровье", [
        _sh(circle_path(15.4, 4.6, 2.1)),
        _sh(line_path([(13.6, 8.0), (10.4, 11.4), (12.6, 14.2), (9.4, 18.2)]),
            fill=False, stroke=2.0),
        _sh(line_path([(12.4, 9.6), (16.4, 12.2), (17.6, 16.0)]), fill=False, stroke=2.0),
        _sh(line_path([(10.4, 11.4), (5.8, 10.6)]), fill=False, stroke=2.0),
    ])
    add("drop", "Капля (вода)", "Здоровье", [_sh(
        "M12 2.4C12 2.4 5.4 10.2 5.4 14.4C5.4 18.1 8.3 21 12 21"
        "C15.7 21 18.6 18.1 18.6 14.4C18.6 10.2 12 2.4 12 2.4Z")])
    add("moon", "Луна (сон, ночь)", "Здоровье", [_sh(
        "M15.4 2.6C10.6 3.6 7.4 7.8 7.4 12.4C7.4 17.0 10.6 21.2 15.4 22.2"
        "C16.2 21.2 16.8 19.4 16.8 17.4C16.8 11.8 12.4 6.8 15.4 2.6Z")])
    add("sun", "Солнце", "Здоровье", [
        _sh(circle_path(12, 12, 4.6), fill=False, stroke=2.2),
        _sh(_rays(12, 12, 7.0, 10.4, 8), fill=False, stroke=2.0)])
    add("thermometer", "Термометр", "Здоровье", [
        _sh("M10.2 4.4A1.8 1.8 0 0 1 13.8 4.4V13.2A4.4 4.4 0 1 1 10.2 13.2Z",
            fill=False, stroke=1.8),
        _sh(circle_path(12, 17.4, 2.4)),
        _sh(rect_path(11.2, 7.0, 1.6, 8.4)),
    ])
    add("dumbbell", "Гантель", "Здоровье", [
        _sh(rect_path(8.6, 10.6, 6.8, 2.8)),
        _sh(rect_path(5.4, 7.6, 2.6, 8.8)),
        _sh(rect_path(16.0, 7.6, 2.6, 8.8)),
        _sh(rect_path(2.6, 9.6, 1.8, 4.8)),
        _sh(rect_path(19.6, 9.6, 1.8, 4.8)),
    ])
    add("lungs", "Лёгкие", "Здоровье", [
        _sh(rect_path(11.2, 2.6, 1.6, 8.0)),
        _sh("M11.2 8.6C9.0 8.0 6.4 9.2 5.2 12.2C4.0 15.2 4.2 19.6 6.0 20.6"
            "C7.8 21.6 10.6 19.6 11.2 16.4Z", fill=False, stroke=1.7),
        _sh("M12.8 8.6C15.0 8.0 17.6 9.2 18.8 12.2C20.0 15.2 19.8 19.6 18.0 20.6"
            "C16.2 21.6 13.4 19.6 12.8 16.4Z", fill=False, stroke=1.7),
    ])

    # ---------------------------- Погода ----------------------------------
    _cloud = ("M6.4 18.4A4.2 4.2 0 0 1 6.4 10.0A5.6 5.6 0 0 1 17.2 9.4"
              "A4.2 4.2 0 0 1 17.2 18.4Z")
    add("cloud", "Облако", "Погода", [_sh(_cloud)])
    add("cloud_rain", "Дождь", "Погода", [
        _sh(_cloud),
        _sh(line_path([(8.4, 19.6), (7.4, 22.4)]), fill=False, stroke=1.7),
        _sh(line_path([(12.0, 19.6), (11.0, 22.4)]), fill=False, stroke=1.7),
        _sh(line_path([(15.6, 19.6), (14.6, 22.4)]), fill=False, stroke=1.7),
    ])
    add("cloud_snow", "Снег", "Погода", [
        _sh(_cloud),
        _sh(circle_path(9.0, 21.0, 1.1)),
        _sh(circle_path(15.0, 21.0, 1.1)),
        _sh(circle_path(12.0, 22.6, 1.1)),
    ])
    add("cloud_lightning", "Гроза", "Погода", [
        _sh(_cloud),
        _sh("M12.6 18.4L9.4 23.4H12.2L11.4 26.0L15.0 20.8H12.0L12.6 18.4Z"),
    ])
    add("cloud_fog", "Туман", "Погода", [
        _sh(_cloud),
        _sh(line_path([(5.4, 20.4), (18.6, 20.4)]), fill=False, stroke=1.6),
        _sh(line_path([(7.4, 23.2), (16.6, 23.2)]), fill=False, stroke=1.6),
    ])
    add("wind", "Ветер", "Погода", [
        _sh("M3.2 8.4H14.4A2.8 2.8 0 1 0 11.6 5.6", fill=False, stroke=1.9),
        _sh("M3.2 13.2H17.6A2.8 2.8 0 1 1 14.8 16.0", fill=False, stroke=1.9),
        _sh("M3.2 18.0H11.2", fill=False, stroke=1.9),
    ])
    add("cloud_sun", "Облачно с солнцем", "Погода", [
        _sh(circle_path(15.6, 7.4, 3.4), fill=False, stroke=1.9),
        _sh(_rays(15.6, 7.4, 5.2, 7.6, 6, 30), fill=False, stroke=1.6),
        _sh("M6.0 19.4A4.0 4.0 0 0 1 6.0 11.4A5.2 5.2 0 0 1 15.6 11.0"
            "A3.8 3.8 0 0 1 15.6 19.4Z"),
    ])
    add("snowflake", "Снежинка", "Погода", [
        _sh(_rays(12, 12, 2.0, 10.6, 6, -90), fill=False, stroke=1.6),
        _sh(_branch(12, 12, 10.6, 6), fill=False, stroke=1.3),
        _sh(circle_path(12, 12, 1.6)),
    ])

    # ---------------------------- Техника ---------------------------------
    add("battery", "Батарея", "Техника", [
        _sh(rect_path(2.4, 7.4, 17.0, 9.2, 2.2), fill=False, stroke=1.8),
        _sh(rect_path(20.0, 10.2, 1.8, 3.6, 0.8)),
        _sh(rect_path(4.6, 9.6, 9.4, 4.8, 1.0)),
    ])
    add("battery_low", "Батарея: низкий заряд", "Техника", [
        _sh(rect_path(2.4, 7.4, 17.0, 9.2, 2.2), fill=False, stroke=1.8),
        _sh(rect_path(20.0, 10.2, 1.8, 3.6, 0.8)),
        _sh(rect_path(4.6, 9.6, 3.2, 4.8, 0.8)),
    ])
    add("bluetooth", "Bluetooth", "Техника", [
        _sh(line_path([(12, 3.0), (17.6, 7.6), (6.6, 16.4)]), fill=False, stroke=1.9),
        _sh(line_path([(12, 21.0), (17.6, 16.4), (6.6, 7.6)]), fill=False, stroke=1.9),
        _sh(line_path([(6.6, 3.0), (6.6, 21.0)]), fill=False, stroke=1.9),
    ])
    add("wifi", "Wi-Fi", "Техника", [
        _sh("M2.2 9.0A15 15 0 0 1 21.8 9.0", fill=False, stroke=1.9),
        _sh("M5.6 12.8A10.4 10.4 0 0 1 18.4 12.8", fill=False, stroke=1.9),
        _sh("M8.8 16.4A5.8 5.8 0 0 1 15.2 16.4", fill=False, stroke=1.9),
        _sh(circle_path(12, 19.8, 1.4)),
    ])
    add("gear", "Шестерёнка (настройки)", "Техника", [
        _sh(circle_path(12, 12, 5.8), fill=False, stroke=2.2),
        _sh(_rays(12, 12, 7.4, 10.2, 8, -90), fill=False, stroke=2.4),
        _sh(circle_path(12, 12, 2.0)),
    ])
    add("watch", "Часы-устройство", "Техника", [
        _sh(rect_path(7.0, 5.4, 10.0, 13.2, 2.6), fill=False, stroke=1.8),
        _sh(rect_path(9.4, 1.6, 5.2, 3.6, 1.0)),
        _sh(rect_path(9.4, 18.8, 5.2, 3.6, 1.0)),
        _sh(line_path([(12, 9.4), (12, 12.4), (14.4, 13.8)]), fill=False, stroke=1.5),
    ])
    add("charging", "Зарядка", "Техника", [
        _sh(rect_path(2.0, 7.0, 15.4, 10.0, 2.4), fill=False, stroke=1.7),
        _sh("M12.6 4.4L7.6 13.4H11.0L10.2 19.6L15.4 10.4H11.8L12.6 4.4Z"),
    ])

    # ---------------------------- Навигация -------------------------------
    add("map_marker", "Метка на карте", "Навигация", [
        _sh("M12 2.2C8.0 2.2 4.8 5.4 4.8 9.4C4.8 14.6 12 21.8 12 21.8"
            "C12 21.8 19.2 14.6 19.2 9.4C19.2 5.4 16.0 2.2 12 2.2Z"),
        _sh(circle_path(12, 9.2, 2.2), fill=False, stroke=1.2),
    ])
    add("compass", "Компас", "Навигация", [
        _sh(circle_path(12, 12, 9.2), fill=False, stroke=1.7),
        _sh("M15.6 8.4L13.4 13.4L8.4 15.6L10.6 10.6Z"),
    ])
    add("route", "Маршрут", "Навигация", [
        _sh(circle_path(6.2, 18.0, 2.8), fill=False, stroke=1.8),
        _sh(circle_path(17.8, 6.0, 2.8), fill=False, stroke=1.8),
        _sh("M8.8 16.4C12.0 14.4 9.0 10.4 12.4 9.0C14.2 8.2 15.4 8.0 16.4 7.6",
            fill=False, stroke=1.6),
    ])
    add("arrow_up", "Стрелка вверх", "Навигация", [
        _sh("M12 2.6L19.4 12.2H14.6V21.4H9.4V12.2H4.6Z")])
    add("flag", "Флаг (цель)", "Навигация", [
        _sh(rect_path(4.6, 2.4, 1.8, 19.2, 0.6)),
        _sh("M6.4 3.4H19.6L15.4 8.2L19.6 13.0H6.4Z"),
    ])
    add("target", "Цель", "Навигация", [
        _sh(circle_path(12, 12, 9.0), fill=False, stroke=1.8),
        _sh(circle_path(12, 12, 5.4), fill=False, stroke=1.8),
        _sh(circle_path(12, 12, 1.8)),
    ])

    # ---------------------------- Декор -----------------------------------
    add("star", "Звезда", "Декор", [_sh(
        "M12 2.2L14.9 8.8L22.2 9.6L16.7 14.4L18.3 21.6L12 17.8L5.7 21.6"
        "L7.3 14.4L1.8 9.6L9.1 8.8Z")])
    add("ring", "Кольцо прогресса", "Декор", [
        _sh(circle_path(12, 12, 9.4), fill=False, stroke=2.0),
    ])
    add("dot", "Точка", "Декор", [_sh(circle_path(12, 12, 3.4))])
    add("divider", "Линия-разделитель", "Декор", [
        _sh(line_path([(2.6, 12), (21.4, 12)]), fill=False, stroke=2.0),
        _sh(circle_path(12, 12, 2.2)),
    ])
    add("hexagon", "Шестиугольник", "Декор", [])

    # ---------------------------- Стрелки ---------------------------------
    add("hand_hour", "Часовая стрелка", "Стрелки", [_sh(
        "M12 24L14.4 20.2L13.6 6.6L12 3.2L10.4 6.6L9.6 20.2Z")])
    add("hand_minute", "Минутная стрелка", "Стрелки", [_sh(
        "M12 24L13.4 20.6L12.8 2.4L12 1.2L11.2 2.4L10.6 20.6Z")])
    add("hand_second", "Секундная стрелка", "Стрелки", [
        _sh("M11.7 24L12.3 24L12.7 3.0L12 2.0L11.3 3.0Z"),
        _sh(circle_path(12, 20.6, 2.2), fill=False, stroke=1.2),
        _sh(circle_path(12, 12, 1.3)),
    ])
    return D


ICON_DEFS: "OrderedDict[str, dict]" = _build_defs()

# «Шестиугольник» достраиваем отдельно, чтобы не загромождать литерал
ICON_DEFS["hexagon"]["shapes"] = [_sh(
    "M12 2.4L20.4 7.2V16.8L12 21.6L3.6 16.8V7.2Z", fill=False, stroke=2.0)]


def icon_names() -> List[str]:
    return list(ICON_DEFS.keys())


def icon_ru(name: str) -> str:
    info = ICON_DEFS.get(name)
    return info["ru"] if info else name


def icon_groups() -> Dict[str, List[str]]:
    """Иконки, сгруппированные по темам (для панели «Ресурсы»)."""
    groups: Dict[str, List[str]] = OrderedDict()
    for name, info in ICON_DEFS.items():
        groups.setdefault(info["group"], []).append(name)
    return groups


def clear_cache() -> None:
    _CACHE.clear()


def render_icon(name: str, px: int, color: Tuple[int, int, int, int] = (255, 255, 255, 255),
                supersample: int = 4) -> Image.Image:
    """Отрисовать иконку нужного размера и цвета (с кэшированием).

    px: 1..1024. Неизвестное имя -> иконка «звезда» (чтобы превью не падало).
    """
    px = max(1, int(px))
    color = tuple(int(c) for c in color)  # type: ignore[assignment]
    key = (name, px, color)  # type: ignore[assignment]
    cached = _CACHE.get(key)
    if cached is not None:
        return cached.copy()
    info = ICON_DEFS.get(name) or ICON_DEFS["star"]
    # для очень крупных размеров суперсэмплинг уменьшаем, чтобы не тратить память
    ss = supersample if px <= 256 else 2
    img = render_shape(px, info["shapes"], (24.0, 24.0), color, supersample=ss)
    if len(_CACHE) > _CACHE_LIMIT:
        _CACHE.clear()
    _CACHE[key] = img
    return img.copy()
