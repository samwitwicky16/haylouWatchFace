# -*- coding: utf-8 -*-
"""Шаблоны новых циферблатов и генерация дефолтного фона.

Три заготовки (как требует спецификация):
  empty   — только фон;
  minimal — только время (час : минута);
  full    — все 30 известных элементов, часть скрыта (visible = false).

Все координаты подобраны по реальным файлам RS5: x/y — доли экрана, size —
доля ширины (410 px). Скрытые элементы не ломают файл: Hello Haylou их просто
не показывает, а пользователь включает нужные в панели слоёв.
"""

from __future__ import annotations

import io
from typing import Dict, Optional, Tuple

from PIL import Image, ImageDraw

from . import catalog, constants
from .model import DialDocument, DialElement

TEMPLATES = ("empty", "minimal", "full")
TEMPLATE_RU = {"empty": "Пустой (только фон)",
               "minimal": "Минимализм (только время)",
               "full": "Полный (все блоки)"}


# ---------------------------------------------------------------------------
# Фон
# ---------------------------------------------------------------------------
def default_dial_image(width: int = constants.SCREEN_W,
                       height: int = constants.SCREEN_H) -> Image.Image:
    """Дефолтный фон 410x502: тёмный градиент с тонкой рамкой и метками."""
    img = Image.new("RGB", (width, height), (10, 11, 14))
    draw = ImageDraw.Draw(img)
    for y in range(height):
        k = y / float(max(1, height - 1))
        draw.line([(0, y), (width, y)],
                  fill=(int(12 + 14 * k), int(13 + 16 * k), int(18 + 20 * k)))
    # тонкая внутренняя рамка
    inset = max(6, width // 40)
    draw.rounded_rectangle([inset, inset, width - inset, height - inset],
                           radius=inset * 2, outline=(46, 50, 60), width=2)
    # минутные метки по кругу (радиус — половина ширины)
    cx, cy = width / 2.0, height / 2.0
    import math
    r_out = width * 0.46
    for i in range(60):
        ang = math.radians(i * 6)
        r_in = r_out - (width * 0.035 if i % 5 == 0 else width * 0.016)
        w = 3 if i % 5 == 0 else 1
        x0 = cx + r_in * math.sin(ang)
        y0 = cy - r_in * math.cos(ang)
        x1 = cx + r_out * math.sin(ang)
        y1 = cy - r_out * math.cos(ang)
        draw.line([(x0, y0), (x1, y1)], fill=(120, 126, 140) if i % 5 == 0 else (60, 64, 74), width=w)
    return img


def default_dial_bytes() -> bytes:
    """PNG-байты дефолтного фона (для записи в архив проекта)."""
    buf = io.BytesIO()
    default_dial_image().save(buf, format="PNG")
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Конструкторы элементов
# ---------------------------------------------------------------------------
def _props(name: str) -> Optional[int]:
    """Типовое значение properties для известных элементов (иначе не пишем)."""
    return constants.DEFAULT_PROPERTIES_BY_NAME.get(name)


def make_dial(size: float = 1.0) -> DialElement:
    el = DialElement(name="dial", kind="resourceImage")
    el.payload = {"resource": constants.RES_IMAGE_DIR + "dial.png",
                  "sections": 1, "size": float(size),
                  "width": constants.SCREEN_W, "height": constants.SCREEN_H,
                  "mimeType": "image/png"}
    el.color = None
    el.visible = True
    return el


def make_text(name: str, x: float, y: float, size: float,
              family: str = "sans-serif-medium", color: int = -1,
              visible: bool = True, extra: Optional[Dict] = None) -> DialElement:
    """Текстовый элемент на встроенном шрифте Hello Haylou."""
    el = DialElement(name=name, kind="font")
    el.payload = {"family": family, "sections": 1, "size": float(size)}
    el.set_colors([int(color)])
    el.properties = _props(name)
    el.x, el.y = float(x), float(y)
    el.visible = bool(visible)
    if extra:
        el.extra.update(extra)
    return el


def make_char(name: str, x: float, y: float, size: float, sections: int = 14,
              folder: str = "/resourceCharacter/Digits/", color: int = -1,
              visible: bool = True) -> DialElement:
    """Цифровой элемент «своими» картинками (resourceCharacter)."""
    el = DialElement(name=name, kind="resourceCharacter")
    el.payload = {"resource": folder, "sections": int(sections), "size": float(size)}
    el.set_colors([int(color)])
    el.properties = _props(name)
    el.x, el.y = float(x), float(y)
    el.visible = bool(visible)
    return el


def make_icon(name: str, official_id: str, x: float, y: float, size: float,
              sections: int = 1, color: int = -1, visible: bool = True) -> DialElement:
    """Иконка из встроенной библиотеки приложения (в архив не входит)."""
    el = DialElement(name=name, kind="resourceIcon")
    el.payload = {"resource": official_id, "sections": int(sections),
                  "size": float(size)}
    el.set_colors([int(color)])
    el.properties = _props(name)
    el.x, el.y = float(x), float(y)
    el.visible = bool(visible)
    return el


def make_image(name: str, resource: str, x: float, y: float, size: float,
               sections: int = 1, color: int = -1, visible: bool = True) -> DialElement:
    """Картинка из архива проекта (/resourceImage/...)."""
    el = DialElement(name=name, kind="resourceImage")
    el.payload = {"resource": resource, "sections": int(sections),
                  "size": float(size)}
    el.set_colors([int(color)])
    el.properties = _props(name)
    el.x, el.y = float(x), float(y)
    el.visible = bool(visible)
    return el


# ---------------------------------------------------------------------------
# Собственно шаблоны
# ---------------------------------------------------------------------------
def build_template(kind: str = "full") -> Tuple[DialDocument, Dict[str, bytes]]:
    """Собрать документ + ресурсы (пока только dial.png)."""
    kind = (kind or "full").lower()
    if kind not in TEMPLATES:
        kind = "full"
    doc = DialDocument(aspect_ratio=constants.ASPECT_RATIO,
                       case_shape=constants.CASE_SHAPE,
                       version=constants.JSON_VERSION)
    resources: Dict[str, bytes] = {
        # ключи ресурсов внутри проекта хранятся без ведущего «/» (см. tbwf.normalize_res_path)
        constants.RES_IMAGE_DIR.lstrip("/") + "dial.png": default_dial_bytes()
    }
    doc.add("dial", make_dial())

    # ----------------------------------------------------------------- время
    doc.add("hour", make_text("hour", 0.318, 0.395, 0.140, "oswald_medium"))
    doc.add("timeSeparator", make_text("timeSeparator", 0.500, 0.395, 0.095,
                                       "oswald_medium"))
    doc.add("minute", make_text("minute", 0.682, 0.395, 0.140, "oswald_medium"))

    if kind == "empty":
        return doc, resources          # только фон + время

    # ------------------------------------------------------------------ дата
    doc.add("day", make_char("day", 0.430, 0.560, 0.062))
    doc.add("dateSeparator", make_char("dateSeparator", 0.500, 0.556, 0.062))
    doc.add("month", make_char("month", 0.570, 0.560, 0.062))

    if kind == "minimal":
        return doc, resources          # время + дата, без иконок

    # ------------------------------------------------------------- остальное
    doc.add("second", make_text("second", 0.5, 0.487, 0.062, "sans-serif",
                                visible=False))
    doc.add("year", make_char("year", 0.5, 0.610, 0.055, visible=False))
    doc.add("yearSeparator", make_char("yearSeparator", 0.44, 0.610, 0.055,
                                       visible=False))
    doc.add("dayOfWeek", make_text("dayOfWeek", 0.5, 0.618, 0.055,
                                   "sans-serif-medium"))

    # --------------------------------------------------------------- батарея
    doc.add("batteryResource", make_icon(
        "batteryResource", "batteryResource_ic_wf_anim_battery_horizontal.png",
        0.215, 0.715, 0.070, sections=5, color=0))
    doc.add("battery", make_char("battery", 0.315, 0.715, 0.070))
    doc.add("batteryPercentSign", make_text("batteryPercentSign", 0.408, 0.712,
                                            0.045, "sans-serif"))

    # ------------------------------------------------------------------ шаги
    doc.add("stepResource", make_icon(
        "stepResource", "stepResource_ic_wf_step_shoe_print.png",
        0.215, 0.800, 0.064, color=0))
    doc.add("step", make_char("step", 0.320, 0.800, 0.072))
    doc.add("stepGoalProgressResource", make_icon(
        "stepGoalProgressResource",
        "stepGoalProgressResource_ic_wf_anim_goal_circular.png",
        0.5, 0.5, 0.82, sections=11, color=0, visible=False))

    # ---------------------------------------------------------------- пульс
    doc.add("heartRateResource", make_icon(
        "heartRateResource", "heartRateResource_ic_wf_heart_rate_beat.png",
        0.645, 0.800, 0.064, color=0))
    doc.add("heartRate", make_char("heartRate", 0.745, 0.800, 0.072))

    # -------------------------------------------------------- калории/путь
    doc.add("calorieResource", make_icon(
        "calorieResource", "calorieResource_ic_wf_calorie_burn.png",
        0.215, 0.880, 0.064, color=0))
    doc.add("calorie", make_char("calorie", 0.320, 0.880, 0.072))
    doc.add("distanceResource", make_icon(
        "distanceResource", "distanceResource_ic_wf_distance_map_marker.png",
        0.645, 0.880, 0.064, color=0))
    doc.add("distance", make_char("distance", 0.745, 0.880, 0.072))

    # ------------------------------------------------------------- погода
    doc.add("weatherResource", make_icon(
        "weatherResource", "weatherResource_ic_wf_anim_weather_outline.png",
        0.430, 0.952, 0.075, sections=16))
    doc.add("weatherTemperature", make_char("weatherTemperature", 0.505, 0.952,
                                            0.075))
    doc.add("weatherTemperatureUnitSign", make_text(
        "weatherTemperatureUnitSign", 0.612, 0.948, 0.048, "sans-serif-medium"))

    # ------------------------------------------------------------ Bluetooth
    doc.add("connectionResource", make_icon(
        "connectionResource", "connectionResource_ic_wf_anim_connection_link.png",
        0.905, 0.100, 0.055, sections=2, color=0))

    # ------------------------------------------------------------- стрелки
    doc.add("hourHand", make_icon(
        "hourHand", "hourHand_ic_wf_hand_hour_fill.png", 0.5, 0.5, 0.250,
        color=-1, visible=False))
    doc.add("minuteHand", make_icon(
        "minuteHand", "minuteHand_ic_wf_hand_minute_fill.png", 0.5, 0.5, 0.350,
        color=-1, visible=False))
    doc.add("secondHand", make_icon(
        "secondHand", "secondHand_ic_wf_hand_second_fill.png", 0.5, 0.5, 0.450,
        color=-16711936, visible=False))
    return doc, resources


def build_empty() -> Tuple[DialDocument, Dict[str, bytes]]:
    return build_template("empty")


def build_minimal() -> Tuple[DialDocument, Dict[str, bytes]]:
    return build_template("minimal")


def build_full() -> Tuple[DialDocument, Dict[str, bytes]]:
    return build_template("full")
