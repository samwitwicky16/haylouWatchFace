# -*- coding: utf-8 -*-
"""Работа с цветами формата .tbwf.

В формате цвет — одно знаковое 32-битное число ARGB:
    -1          -> #FFFFFFFF (белый, непрозрачный)
    -16448251   -> #FF050505 (почти чёрный)
    0           -> особое значение «не перекрашивать» (актуально для иконок)
Порядок байт именно A,R,G,B, а не R,G,B,A — это важно.
"""

from __future__ import annotations

from typing import Iterable, Sequence, Tuple

from PIL import Image


def to_unsigned(value: int) -> int:
    """Привести знаковое 32-битное число к беззнаковому виду 0..2^32-1."""
    return int(value) & 0xFFFFFFFF


def to_signed(value: int) -> int:
    """Привести число к знаковому 32-битному диапазону (как в JSON)."""
    value = int(value) & 0xFFFFFFFF
    if value >= 0x80000000:
        value -= 0x100000000
    return value


def argb_to_rgba(value: int) -> Tuple[int, int, int, int]:
    """ARGB-число -> кортеж (R, G, B, A)."""
    u = to_unsigned(value)
    a = (u >> 24) & 0xFF
    r = (u >> 16) & 0xFF
    g = (u >> 8) & 0xFF
    b = u & 0xFF
    return (r, g, b, a)


def rgba_to_argb(rgba: Sequence[int]) -> int:
    """(R, G, B, A) -> знаковое ARGB-число для записи в JSON."""
    r, g, b = (int(max(0, min(255, c))) for c in rgba[:3])
    a = int(max(0, min(255, rgba[3]))) if len(rgba) > 3 else 255
    return to_signed((a << 24) | (r << 16) | (g << 8) | b)


def argb_to_hex(value: int) -> str:
    """ARGB-число -> строка '#RRGGBB' (альфа отбрасывается, она отдельным полем)."""
    r, g, b, _a = argb_to_rgba(value)
    return "#%02X%02X%02X" % (r, g, b)


def hex_to_argb(text: str, alpha: int = 255) -> int:
    """Строка '#RRGGBB' (или 'RRGGBB') -> знаковое ARGB-число."""
    t = (text or "").strip().lstrip("#")
    if len(t) == 3:                      # #ABC -> #AABBCC
        t = "".join(ch * 2 for ch in t)
    if len(t) != 6:
        raise ValueError("ожидается цвет вида #RRGGBB, получено: %r" % text)
    r = int(t[0:2], 16)
    g = int(t[2:4], 16)
    b = int(t[4:6], 16)
    return rgba_to_argb((r, g, b, alpha))


def parse_int32(text: str) -> int:
    """Разобрать ввод пользователя: '-1', '0xFF050505', '#FFFFFF' -> int32."""
    t = (text or "").strip()
    if not t:
        raise ValueError("пустое значение цвета")
    sign = 1
    if t[0] in "+-":
        if t[0] == "-":
            sign = -1
        t = t[1:].strip()
    if t.lower().startswith("0x"):
        return to_signed(sign * int(t, 16))
    if t.startswith("#"):
        return hex_to_argb(t)
    return to_signed(sign * int(t, 10))


def is_repaint_enabled(value: int) -> bool:
    """0 означает «оставить картинку как есть», остальные значения — перекрашивать."""
    return to_unsigned(value) != 0


def first_color(colors: Iterable[int], default: int = -1) -> int:
    """Первый цвет из списка (или значение по умолчанию)."""
    for c in colors or []:
        return int(c)
    return default


def make_gradient_image(width: int, height: int, colors: Sequence[int],
                        positions: Sequence[float] | None = None,
                        gradient: str = "solid") -> Image.Image:
    """Создать картинку-заливку по описанию color из JSON.

    solid          — один цвет;
    linear_vertical — вертикальный градиент по 2–3 цветам и их позициям.
    """
    width = max(1, int(width))
    height = max(1, int(height))
    cols = list(colors) if colors else [-1]
    if gradient != "linear_vertical" or len(cols) < 2:
        return Image.new("RGBA", (width, height), argb_to_rgba(cols[0]))

    pos = list(positions or [])
    if len(pos) != len(cols):
        # Позиции не заданы корректно — распределяем равномерно.
        n = len(cols) - 1
        pos = [i / n if n else 0.0 for i in range(len(cols))]
    stops = [(max(0.0, min(1.0, float(p))), argb_to_rgba(c)) for p, c in zip(pos, cols)]
    stops.sort(key=lambda s: s[0])

    img = Image.new("RGBA", (width, height), stops[-1][1])
    px = img.load()
    for y in range(height):
        t = y / max(1, height - 1)
        # ищем отрезок, в который попало t
        left = stops[0]
        right = stops[-1]
        for i in range(len(stops) - 1):
            if stops[i][0] <= t <= stops[i + 1][0]:
                left, right = stops[i], stops[i + 1]
                break
        span = (right[0] - left[0]) or 1e-9
        k = (t - left[0]) / span
        k = max(0.0, min(1.0, k))
        color = tuple(int(round(left[1][i] + (right[1][i] - left[1][i]) * k)) for i in range(4))
        for x in range(width):
            px[x, y] = color
    return img


def color_to_tk(value: int) -> str:
    """ARGB -> строка цвета для tkinter ('#rrggbb')."""
    r, g, b, _a = argb_to_rgba(value)
    return "#%02x%02x%02x" % (r, g, b)


def luminance(value: int) -> float:
    """Относительная яркость 0..1 (для авто-контраста подписей)."""
    r, g, b, _a = argb_to_rgba(value)
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0
