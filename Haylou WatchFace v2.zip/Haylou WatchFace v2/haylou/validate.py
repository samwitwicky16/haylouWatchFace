# -*- coding: utf-8 -*-
"""Валидация документа перед экспортом.

Правила взяты из спецификации (п.9) и из наблюдений по реальным файлам RS5.
Возвращаем список «замечаний» — словари с уровнем (error/warn) и текстом,
чтобы GUI мог показать их списком, а selftest — посчитать.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from . import catalog, constants, tbwf
from .model import DialDocument, DialElement

INT32_MIN, INT32_MAX = -2147483648, 2147483647


def _issue(level: str, name: str, message: str) -> Dict[str, str]:
    return {"level": level, "element": name, "message": message}


def validate_element(el: DialElement, resources: Optional[Dict[str, bytes]]) -> List[Dict[str, str]]:
    """Проверить один элемент."""
    out: List[Dict[str, str]] = []
    name = el.name

    # --- координаты -----------------------------------------------------
    if el.name != "dial":
        if el.x is None or el.y is None:
            out.append(_issue("error", name, "не заданы координаты x/y"))
        else:
            if not (0.0 <= float(el.x) <= 1.0):
                out.append(_issue("error", name, "x вне диапазона 0…1: %.4f" % el.x))
            if not (0.0 <= float(el.y) <= 1.0):
                out.append(_issue("error", name, "y вне диапазона 0…1: %.4f" % el.y))

    # --- размер ---------------------------------------------------------
    size = el.get_size()
    if size is None:
        out.append(_issue("error", name, "не задан size"))
    elif size <= 0:
        out.append(_issue("error", name, "size должен быть > 0: %.4f" % size))
    elif size > 2.0:
        out.append(_issue("warn", name, "size > 2 — элемент больше двух экранов"))

    # --- sections -------------------------------------------------------
    sections = el.payload.get("sections", 1)
    try:
        sec_int = int(sections)
    except (TypeError, ValueError):
        sec_int = -1
    if sec_int < 1:
        out.append(_issue("error", name, "sections должен быть целым >= 1"))

    # --- properties -----------------------------------------------------
    if el.properties is not None:
        if el.properties < 0:
            out.append(_issue("error", name, "properties не может быть < 0"))
        elif el.properties not in constants.OBSERVED_PROPERTIES:
            out.append(_issue("warn", name,
                              "properties=%d не встречался в рабочих файлах" % el.properties))

    # --- цвет -----------------------------------------------------------
    if el.color is not None:
        gradient = el.get_gradient()
        if gradient not in constants.GRADIENT_KINDS:
            out.append(_issue("error", name, "неизвестный gradient: %s" % gradient))
        cols = el.get_colors()
        if not cols:
            out.append(_issue("error", name, "color.colors пуст"))
        for c in cols:
            try:
                ci = int(c)
            except (TypeError, ValueError):
                out.append(_issue("error", name, "цвет не число: %r" % (c,)))
                continue
            if not (INT32_MIN <= ci <= INT32_MAX):
                out.append(_issue("error", name, "цвет вне int32: %d" % ci))
        pos = (el.color or {}).get("positions")
        if pos is not None and len(pos) != len(cols):
            out.append(_issue("error", name,
                              "positions не совпадает по длине с colors (%d/%d)"
                              % (len(pos), len(cols))))
        if gradient == "linear_vertical" and len(cols) < 2:
            out.append(_issue("error", name, "для градиента нужно >= 2 цветов"))

    # --- вид ресурса ----------------------------------------------------
    info = catalog.get_info(name)
    if info.get("known"):
        allowed = info.get("kind_allowed") or []
        if el.kind not in allowed and el.kind != "none":
            out.append(_issue("warn", name,
                              "вид %s не типичен для этого элемента (%s)"
                              % (el.kind, ", ".join(allowed))))
    else:
        out.append(_issue("warn", name, "неизвестное имя элемента — приложение может проигнорировать"))

    # --- ресурсы --------------------------------------------------------
    if el.kind == "resourceImage":
        res = el.get_resource()
        if not res:
            out.append(_issue("error", name, "не указан resource"))
        elif resources is not None:
            frames, paths = tbwf.iter_frames(res, sec_int if sec_int > 0 else 1,
                                             resources)
            if not frames:
                out.append(_issue("error", name, "файла нет в архиве: %s" % res))
            elif len(frames) < max(1, sec_int):
                out.append(_issue("warn", name,
                                  "кадров %d меньше, чем sections=%d"
                                  % (len(frames), sec_int)))
    elif el.kind == "resourceCharacter":
        res = el.get_resource()
        if not res:
            out.append(_issue("error", name, "не указана папка resourceCharacter"))
        elif resources is not None:
            exists = any(tbwf.find_key(resources, res.rstrip("/") + "/" + s + ".png")
                         for s in ("_0", "_1", "_colon", "_dot"))
            if not exists:
                out.append(_issue("warn", name,
                                  "в архиве нет глифов для %s (будет системный шрифт)" % res))
    elif el.kind == "resourceIcon":
        res = el.get_resource()
        if not res:
            out.append(_issue("error", name, "не выбран официальный id иконки"))
        elif catalog.official_icon(res) is None:
            out.append(_issue("error", name,
                              "id '%s' отсутствует в списке 30 официальных иконок" % res))
    elif el.kind == "font":
        family = el.get_resource()
        if not family:
            out.append(_issue("error", name, "не указан family шрифта"))
        elif not family.startswith(constants.FONT_DIR) and \
                family not in constants.FONT_FILE_CANDIDATES:
            out.append(_issue("warn", name,
                              "неизвестный шрифт '%s' — часы подставят свой" % family))
    elif el.kind == "none":
        if el.name != "dial":
            out.append(_issue("warn", name, "элемент без ресурса — рисовать нечего"))

    # --- что формат не умеет -------------------------------------------
    if el.extra.get(constants.EXT_BLINK):
        out.append(_issue("warn", name, "«моргание» в формат не входит — только запекание"))
    return out


def validate_document(doc: DialDocument,
                      resources: Optional[Dict[str, bytes]] = None) -> List[Dict[str, str]]:
    """Проверить весь документ. Пустой список — всё чисто."""
    issues: List[Dict[str, str]] = []
    # ключи ресурсов могут прийти как с ведущим «/», так и без него — приводим к одному виду
    if resources is not None:
        resources = {tbwf.normalize_res_path(k): v for k, v in resources.items()}

    # --- верхний уровень ------------------------------------------------
    if abs(float(doc.aspect_ratio) - constants.ASPECT_RATIO) > 0.002:
        if any(abs(float(doc.aspect_ratio) - a) < 0.002 for a in constants.LEGACY_ASPECTS):
            issues.append(_issue("warn", "aspectRatio",
                                 "значение %.8f — это RS4, для RS5 нужно %.8f"
                                 % (doc.aspect_ratio, constants.ASPECT_RATIO)))
        else:
            issues.append(_issue("warn", "aspectRatio",
                                 "aspectRatio %.8f не совпадает с RS5 (%.8f)"
                                 % (doc.aspect_ratio, constants.ASPECT_RATIO)))
    if doc.case_shape != constants.CASE_SHAPE:
        issues.append(_issue("warn", "caseShape",
                             "caseShape '%s' — у RS5 должно быть '%s'"
                             % (doc.case_shape, constants.CASE_SHAPE)))
    if "dial" not in doc:
        issues.append(_issue("error", "dial", "нет элемента dial (фона)"))

    # --- элементы -------------------------------------------------------
    for el in doc.all_elements():
        issues.extend(validate_element(el, resources))
    return issues


def summarize(issues: List[Dict[str, str]]) -> str:
    """Одна строка для статус-бара."""
    errors = sum(1 for i in issues if i["level"] == "error")
    warns = sum(1 for i in issues if i["level"] == "warn")
    if not issues:
        return "Проверка пройдена: замечаний нет"
    return "Проверка: %d ошибок, %d предупреждений" % (errors, warns)


def has_errors(issues: List[Dict[str, str]]) -> bool:
    return any(i["level"] == "error" for i in issues)
