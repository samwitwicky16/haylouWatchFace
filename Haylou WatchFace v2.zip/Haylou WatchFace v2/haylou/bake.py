# -*- coding: utf-8 -*-
"""Режим «запечь в фон».

Формат .tbwf не умеет: своих иконок (кроме встроенной библиотеки), условий
«если заряд < 20 — красный», моргания по времени. Поэтому всё, что не
выражается штатно, мы рисуем прямо в картинку фона и убираем из элементов.

Кадры: моргание превращается в последовательность dial_0.png, dial_1.png…
и у элемента dial ставится sections = N. Тот же механизм покадровых ресурсов,
что и у иконок — «вероятно работает» (см. отчёт в README).
"""

from __future__ import annotations

import io
from typing import Dict, List, Optional, Tuple

from PIL import Image

from . import conditions, constants, renderer, tbwf
from .model import DialDocument, DialElement


def _png(img: Image.Image) -> bytes:
    buf = io.BytesIO()
    img.convert("RGBA").save(buf, format="PNG")
    return buf.getvalue()


def plan_bake(doc: DialDocument) -> List[str]:
    """Какие слои придётся запечь (по именам)."""
    out = []
    for el in doc.all_elements():
        if el.name == "dial":
            continue
        if conditions.has_unsupported(el):
            out.append(el.name)
    return out


def bake(doc: DialDocument, sim: "conditions.SimState",
         resources: Dict[str, bytes], frames: int = 2,
         static: bool = False) -> Tuple[DialDocument, Dict[str, bytes], Dict[str, object]]:
    """Запечь неподдерживаемые слои в фон.

    sim     — состояние, в котором фиксируются значения (шаги, пульс, погода);
    frames  — сколько кадров фона делать (2 = «горит / не горит»);
    static  — True: один кадр, моргание просто «включено».
    Возвращает (новый документ, новые ресурсы, отчёт).
    """
    new_doc = doc.clone()
    new_res: Dict[str, bytes] = dict(resources)
    store = renderer.ResourceStore(resources)

    baked_names = plan_bake(new_doc)
    if not baked_names:
        return new_doc, new_res, {"baked": [], "frames": 1, "changed": False}

    # Слои, которые остаются «живыми» (штатные возможности формата)
    keep: List[DialElement] = []
    bake: List[DialElement] = []
    for el in new_doc.all_elements():
        if el.name in baked_names:
            bake.append(el)
        else:
            keep.append(el)

    n_frames = 1 if static else max(1, int(frames))
    new_doc.elements.clear()
    base_dial = None
    for el in keep:
        if el.name == "dial":
            base_dial = el
        new_doc.elements[el.name] = el
    if base_dial is None:
        base_dial = DialElement(name="dial", kind="resourceImage")
        base_dial.payload = {"resource": constants.RES_IMAGE_DIR + "dial.png",
                             "sections": 1, "size": 1.0,
                             "width": constants.SCREEN_W,
                             "height": constants.SCREEN_H,
                             "mimeType": "image/png"}
        items = [("dial", base_dial)] + list(new_doc.elements.items())
        from collections import OrderedDict
        new_doc.elements = OrderedDict(items)

    # --- рисуем кадры ---------------------------------------------------
    blink_any = any(conditions.get_blink(el).get("enabled") for el in bake)
    frame_paths: List[str] = []
    for i in range(n_frames):
        canvas = renderer.render_document(new_doc, sim, constants.SCREEN_W,
                                          constants.SCREEN_H, resources=store,
                                          ignore_blink=True)
        # На кадр «выключено» моргающие слои не рисуем, остальные рисуем всегда
        for el in bake:
            blink = conditions.get_blink(el)
            if blink.get("enabled") and n_frames > 1 and i % 2 == 1:
                continue
            temp = el.clone()
            temp.extra.pop(constants.EXT_BLINK, None)
            temp.extra.pop(constants.EXT_COND, None)
            renderer.draw_element(canvas, temp, store, sim, 1.0, ignore_blink=True)
        if n_frames == 1:
            path = constants.RES_IMAGE_DIR + "dial.png"
        else:
            path = constants.RES_IMAGE_DIR + "dial_%d.png" % i
        frame_paths.append(path)
        new_res[path] = _png(canvas)

    # --- правим dial ----------------------------------------------------
    if n_frames == 1:
        base_dial.payload["resource"] = constants.RES_IMAGE_DIR + "dial.png"
        base_dial.payload["sections"] = 1
    elif len(frame_paths) == 1:
        base_dial.payload["resource"] = frame_paths[0]
        base_dial.payload["sections"] = 1
    else:
        base_dial.payload["resource"] = frame_paths[0]
        base_dial.payload["sections"] = n_frames

    report: Dict[str, object] = {
        "baked": baked_names,
        "frames": n_frames if blink_any else 1,
        "blink": blink_any,
        "changed": True,
        "paths": frame_paths,
    }
    return new_doc, new_res, report


def bake_to_file(doc: DialDocument, sim: "conditions.SimState",
                 resources: Dict[str, bytes], path: str,
                 frames: int = 2, static: bool = False) -> Dict[str, object]:
    """Запечь и сразу сохранить .tbwf. Возвращает отчёт."""
    new_doc, new_res, report = bake(doc, sim, resources, frames=frames, static=static)
    tbwf.save(new_doc, path, new_res, clean=True)
    report["path"] = path
    return report


def describe_report(report: Dict[str, object]) -> str:
    """Человеческая строка про результат запекания."""
    if not report.get("changed"):
        return "Запекать нечего: все элементы поддерживаются форматом."
    names = report.get("baked") or []
    frames = report.get("frames") or 1
    txt = "Запечено в фон слоёв: %d (%s). Кадров фона: %d." % (
        len(names), ", ".join(str(n) for n in names), int(frames))
    if report.get("blink"):
        txt += " Моргание стало кадрами dial_0…dial_%d." % (int(frames) - 1)
    return txt
