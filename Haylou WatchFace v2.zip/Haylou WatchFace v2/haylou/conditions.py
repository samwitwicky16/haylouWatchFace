# -*- coding: utf-8 -*-
"""Симуляция данных, выбор кадра и условия.

Честно о возможностях формата: в .tbwf НЕТ полей «условие» и «анимация по
времени». Штатный механизм — `sections`: приложение само подставляет кадр по
реальному состоянию (погода / заряд / Bluetooth / цель по шагам / день недели).
Поэтому:
  * смена кадра у секвенций resourceIcon / resourceImage — работает штатно;
  * условия по данным для своих картинок и цветов   — только запеканием;
  * «моргание» (периодический показ/скрытие)        — только запеканием.
"""

from __future__ import annotations

import datetime as _dt
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import catalog, constants

# 16 состояний погоды строго в порядке из спецификации (кадр = индекс)
WEATHER_STATES: List[dict] = [
    dict(key="clear", ru="Ясно", icon="sun", frame=0),
    dict(key="mostly_clear", ru="Малооблачно", icon="cloud_sun", frame=1),
    dict(key="partly_cloudy", ru="Облачно", icon="cloud_sun", frame=2),
    dict(key="overcast", ru="Пасмурно", icon="cloud_fog", frame=3),
    dict(key="rain", ru="Дождь", icon="cloud_rain", frame=4),
    dict(key="showers", ru="Ливень", icon="cloud_rain", frame=5),
    dict(key="thunder", ru="Гроза", icon="cloud_lightning", frame=6),
    dict(key="snow", ru="Снег", icon="cloud_snow", frame=7),
    dict(key="blizzard", ru="Метель", icon="snowflake", frame=8),
    dict(key="fog", ru="Туман", icon="cloud_fog", frame=9),
    dict(key="wind", ru="Ветер", icon="wind", frame=10),
    dict(key="hot", ru="Жара", icon="sun", frame=11),
    dict(key="frost", ru="Мороз", icon="snowflake", frame=12),
    dict(key="ice", ru="Гололёд", icon="cloud_snow", frame=13),
    dict(key="night_clear", ru="Ясно (ночь)", icon="moon", frame=14),
    dict(key="unknown", ru="Неизвестно", icon="cloud", frame=15),
]

WEEKDAY_SHORT_RU = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"]
WEEKDAY_SHORT_EN = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]

CONDITION_SOURCES = {
    "battery": "Заряд (%)",
    "steps": "Шаги, % от цели",
    "weather": "Погода (0-15)",
    "connection": "Bluetooth (1/0)",
    "hour": "Час (0-23)",
}
CONDITION_OPS = ["<", "<=", "==", ">=", ">"]


# ---------------------------------------------------------------------------
# Состояние симуляции
# ---------------------------------------------------------------------------
@dataclass
class SimState:
    """Демо-данные, подставляемые в превью."""

    time: _dt.datetime = field(default_factory=_dt.datetime.now)
    steps: int = 6420
    steps_goal: int = 10000
    heart: int = 72
    battery: int = 76
    charging: bool = False
    weather: int = 2           # 0..15, индекс WEATHER_STATES
    connected: bool = True
    is_night: bool = False
    calories: int = 289
    distance: float = 4.82
    weekday_language: str = "ru"

    # ----------------------------------------------------------- псевдонимы
    @property
    def now(self) -> _dt.datetime:
        return self.time

    @now.setter
    def now(self, value: _dt.datetime) -> None:
        self.time = value

    @property
    def step_goal(self) -> int:
        return self.steps_goal

    @step_goal.setter
    def step_goal(self, value: int) -> None:
        self.steps_goal = value

    @property
    def weather_index(self) -> int:
        return self.weather

    @weather_index.setter
    def weather_index(self, value: int) -> None:
        self.weather = value

    # ------------------------------------------------------------- значения
    def progress(self) -> float:
        if self.steps_goal <= 0:
            return 0.0
        return max(0.0, min(1.0, float(self.steps) / float(self.steps_goal)))

    def weather_info(self) -> dict:
        idx = max(0, min(len(WEATHER_STATES) - 1, int(self.weather)))
        return WEATHER_STATES[idx]

    def temperature(self) -> int:
        base = {0: 21, 1: 19, 2: 17, 3: 14, 4: 12, 5: 11, 6: 15, 7: -3,
                8: -8, 9: 8, 10: 13, 11: 33, 12: -14, 13: -1, 14: 16, 15: 10}
        return int(base.get(int(self.weather), 10))

    def values(self) -> Dict[str, object]:
        return {
            "hour": self.time.hour, "minute": self.time.minute,
            "second": self.time.second, "year": self.time.year,
            "month": self.time.month, "day": self.time.day,
            "weekday": self.time.weekday(), "steps": self.steps,
            "stepsProgress": self.progress(), "calories": self.calories,
            "distance": self.distance, "heart": self.heart,
            "battery": self.battery, "temp": self.temperature(),
            "weather": self.weather,
            "connected": 1 if self.connected else 0,
            "charging": 1 if self.charging else 0,
            "night": 1 if self.is_night else 0,
        }

    # --------------------------------------------------------- сериализация
    def to_dict(self) -> dict:
        return {
            "time": self.time.strftime("%Y-%m-%dT%H:%M:%S"),
            "steps": self.steps, "steps_goal": self.steps_goal,
            "heart": self.heart, "battery": self.battery,
            "charging": self.charging, "weather": self.weather,
            "connected": self.connected, "is_night": self.is_night,
            "calories": self.calories, "distance": self.distance,
            "weekday_language": self.weekday_language,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SimState":
        st = cls()
        try:
            st.time = _dt.datetime.strptime(str(data.get("time")), "%Y-%m-%dT%H:%M:%S")
        except Exception:
            pass
        for key in ("steps", "steps_goal", "heart", "battery", "weather", "calories"):
            if key in data:
                try:
                    setattr(st, key, int(data[key]))
                except (TypeError, ValueError):
                    pass
        try:
            st.distance = float(data.get("distance", st.distance))
        except (TypeError, ValueError):
            pass
        st.charging = bool(data.get("charging", False))
        st.connected = bool(data.get("connected", True))
        st.is_night = bool(data.get("is_night", False))
        st.weekday_language = str(data.get("weekday_language", "ru"))
        return st

    def random_demo(self, seed: Optional[int] = None) -> None:
        """Случайные, но правдоподобные данные — кнопка «Демо»."""
        rnd = random.Random(seed)
        self.steps = rnd.randint(300, 19900)
        self.steps_goal = rnd.choice([6000, 8000, 10000, 12000])
        self.heart = rnd.randint(54, 152)
        self.battery = rnd.choice([3, 8, 15, 22, 35, 48, 61, 79, 92, 100])
        self.weather = rnd.randint(0, 15)
        self.connected = rnd.random() > 0.25
        self.charging = rnd.random() > 0.8
        self.is_night = rnd.random() > 0.7
        self.calories = int(self.steps * 0.045)
        self.distance = round(self.steps * 0.00075, 2)


# ---------------------------------------------------------------------------
# Текст по смысловой роли (роли — из catalog.data_role)
# ---------------------------------------------------------------------------
_ROLE_TEXT = {
    "hour": lambda v: "%02d" % int(v["hour"]),
    "minute": lambda v: "%02d" % int(v["minute"]),
    "second": lambda v: "%02d" % int(v["second"]),
    "year": lambda v: "%d" % int(v["year"]),
    "month": lambda v: "%02d" % int(v["month"]),
    "day": lambda v: "%02d" % int(v["day"]),
    "yearSep": lambda v: "",
    "timeSep": lambda v: ":",
    "dateSep": lambda v: ".",
    "steps": lambda v: "%d" % int(v["steps"]),
    "calories": lambda v: "%d" % int(v["calories"]),
    "distance": lambda v: "%.2f" % float(v["distance"]),
    "heart": lambda v: "%d" % int(v["heart"]),
    "battery": lambda v: "%d" % int(v["battery"]),
    "percent": lambda v: "%",
    "degree": lambda v: "°",
    "temp": lambda v: ("−%d" % abs(int(v["temp"]))) if int(v["temp"]) < 0
                      else ("%d" % int(v["temp"])),
}


def value_for_role(role: str, sim: SimState) -> str:
    """Строка для текстового элемента по роли (или по имени элемента)."""
    if role in catalog.ELEMENTS:
        role = catalog.data_role(role)
    if role == "weekday":
        names = WEEKDAY_SHORT_EN if sim.weekday_language == "en" else WEEKDAY_SHORT_RU
        return names[int(sim.time.weekday()) % 7]
    fn = _ROLE_TEXT.get(role)
    return fn(sim.values()) if fn else ""


def value_for_element(element, sim: SimState) -> str:
    """Строка для конкретного элемента (учитывает ручной текст в extra)."""
    manual = element.extra.get("_text")
    if isinstance(manual, str) and manual:
        return manual
    return value_for_role(catalog.data_role(element.name), sim)


def placeholder_text(element) -> str:
    """Черновик значения, чтобы «пустой» элемент не выглядел сломанным."""
    role = catalog.data_role(element.name)
    return {
        "hour": "--", "minute": "--", "second": "--", "timeSep": ":",
        "year": "2026", "month": "11", "day": "18", "dateSep": ".",
        "yearSep": "", "weekday": "ВТ", "steps": "12345", "calories": "412",
        "distance": "5.60", "heart": "78", "battery": "76", "percent": "%",
        "temp": "−3", "degree": "°", "dial": "", "none": "",
    }.get(role, "")


# ---------------------------------------------------------------------------
# Выбор кадра по состоянию
# ---------------------------------------------------------------------------
def _battery_frame(sim: SimState, sections: int) -> int:
    """Кадры соответствуют уровням 0,10,…,100 % (для 11 кадров)."""
    sections = max(1, int(sections))
    if sections == 1:
        return 0
    levels = [round(i * 100.0 / (sections - 1)) for i in range(sections)]
    best = 0
    for i, level in enumerate(levels):
        if sim.battery >= level:
            best = i
    return best


def _goal_frame(sim: SimState, sections: int) -> int:
    if sections <= 1:
        return 0
    return max(0, min(sections - 1, int(round(sim.progress() * (sections - 1)))))


def _weather_frame(sim: SimState, sections: int) -> int:
    if sections <= 1:
        return 0
    if sections == 16:
        return max(0, min(15, int(sim.weather)))
    return max(0, min(sections - 1,
                    int(round(int(sim.weather) * (sections - 1) / 15.0))))


def _connection_frame(sim: SimState, sections: int) -> int:
    """По спецификации: 0 — связь есть, 1 — связи нет (при двух кадрах)."""
    if sections <= 1:
        return 0
    return 0 if sim.connected else min(1, sections - 1)


def resolve_frame_index(element, sim: SimState) -> int:
    """Индекс кадра для элемента в текущем состоянии симуляции."""
    sections = max(1, int(element.get_sections() or 1))
    if sections <= 1:
        return 0
    role = catalog.data_role(element.name)
    if role == "weather":
        return _weather_frame(sim, sections)
    if role == "batteryIcon":
        return _battery_frame(sim, sections)
    if role == "connection":
        return _connection_frame(sim, sections)
    if role == "goal":
        return _goal_frame(sim, sections)
    if role == "weekday":
        return min(int(sim.time.weekday()), sections - 1)
    if role == "second":
        return min(sim.time.second, sections - 1)
    if role == "minute":
        return min(sim.time.minute, sections - 1)
    if role == "hour":
        return min(sim.time.hour, sections - 1)
    if role == "battery":
        return _battery_frame(sim, sections)
    return min(int(sim.time.second), sections - 1)


frame_for_element = resolve_frame_index     # имя из спецификации


def frame_count_hint(element) -> str:
    """Подсказка про кадры для панели свойств."""
    sections = max(1, int(element.get_sections() or 1))
    if sections <= 1:
        return "1 кадр — покадровой анимации нет"
    role = catalog.data_role(element.name)
    hints = {
        "weather": "16 состояний погоды, кадр выбирает приложение",
        "batteryIcon": "кадры по уровню заряда (0…100 %)",
        "connection": "0 — связь есть, 1 — связи нет",
        "goal": "кадры по прогрессу цели по шагам",
        "weekday": "7 кадров — дни недели ПН…ВС",
    }
    return "%d кадров · %s" % (sections, hints.get(role, "кадр по условию симуляции"))


# ---------------------------------------------------------------------------
# Цветовые переопределения по состоянию (только превью и запекание)
# ---------------------------------------------------------------------------
def tint_override(element, sim: SimState) -> Tuple[Optional[int], Optional[bool]]:
    """(цвет int32 или None, visible или None) — реакция на данные.

    Низкий заряд → красный, ночь → приглушение, нет Bluetooth → серый.
    В файл это не пишется: формат таких правил не умеет.
    """
    role = catalog.data_role(element.name)
    color = None
    if role in ("batteryIcon", "battery"):
        if sim.battery <= 15:
            color = -65536          # красный
        elif sim.battery <= 30:
            color = -23296          # оранжевый
    if sim.is_night and role in ("steps", "calories", "distance", "heart",
                                 "stepsIcon", "caloriesIcon", "distanceIcon",
                                 "heartIcon"):
        color = -5723992            # приглушённый серо-синий
    if not sim.connected and role in ("weather", "temp", "degree"):
        color = -8355712            # серый
    return color, None


# ---------------------------------------------------------------------------
# Условия и «моргание» (проектные расширения, в формат НЕ пишутся)
# ---------------------------------------------------------------------------
def get_blink(element) -> dict:
    raw = element.extra.get(constants.EXT_BLINK)
    if isinstance(raw, dict):
        return {
            "enabled": bool(raw.get("enabled", False)),
            "on": float(raw.get("on", 1.0) or 1.0),
            "off": float(raw.get("off", 0.6) or 0.6),
        }
    return {"enabled": False, "on": 1.0, "off": 0.6}


def set_blink(element, enabled: bool, on: float = 1.0, off: float = 0.6) -> None:
    element.extra[constants.EXT_BLINK] = {
        "enabled": bool(enabled), "on": max(0.05, float(on)),
        "off": max(0.05, float(off)),
    }


def get_condition(element) -> dict:
    raw = element.extra.get(constants.EXT_COND)
    if isinstance(raw, dict):
        rules = raw.get("rules")
        return {
            "enabled": bool(raw.get("enabled", False)),
            "source": str(raw.get("source") or "battery"),
            "rules": [dict(r) for r in rules] if isinstance(rules, list) else [],
        }
    return {"enabled": False, "source": "battery", "rules": []}


def set_condition(element, enabled: bool, source: str = "", rules: Optional[List[dict]] = None) -> None:
    element.extra[constants.EXT_COND] = {
        "enabled": bool(enabled), "source": str(source or ""),
        "rules": [dict(r) for r in (rules or [])],
    }


def evaluate_condition(element, sim: SimState) -> Optional[dict]:
    """Проверить условия элемента: {'frame':.., 'color':..} или None."""
    cond = get_condition(element)
    if not cond["enabled"] or not cond["rules"]:
        return None
    vals = sim.values()
    source = cond["source"]
    if source == "steps":
        current = float(vals["stepsProgress"]) * 100.0
    elif source == "weather":
        current = float(vals["weather"])
    elif source == "connection":
        current = float(vals["connected"])
    elif source == "hour":
        current = float(vals["hour"])
    else:
        current = float(vals["battery"])
    for rule in cond["rules"]:
        try:
            op = str(rule.get("op") or "<=")
            threshold = float(rule.get("value", 0))
        except (TypeError, ValueError):
            continue
        hit = {"<": current < threshold, "<=": current <= threshold,
               "==": abs(current - threshold) < 1e-9,
               ">=": current >= threshold, ">": current > threshold}.get(op, False)
        if hit:
            out: Dict[str, object] = {}
            if rule.get("frame") not in (None, ""):
                try:
                    out["frame"] = int(rule["frame"])
                except (TypeError, ValueError):
                    pass
            if rule.get("color") not in (None, ""):
                try:
                    out["color"] = int(rule["color"])
                except (TypeError, ValueError):
                    pass
            if out:
                return out
    return None


def blink_visible(element, t_seconds: float) -> bool:
    """Виден ли элемент в момент t (для «моргания» в превью)."""
    blink = get_blink(element)
    if not blink["enabled"]:
        return True
    period = blink["on"] + blink["off"]
    if period <= 0:
        return True
    return (t_seconds % period) < blink["on"]


def has_unsupported(element) -> List[str]:
    """Что в элементе не выразить средствами формата (для отчёта и запекания)."""
    problems = []
    if get_blink(element).get("enabled"):
        problems.append("моргание")
    if get_condition(element).get("enabled"):
        problems.append("условие по данным")
    if element.kind == "resourceIcon":
        official = element.get_resource()
        if not official:
            problems.append("не выбран официальный id иконки")
        elif catalog.official_icon(official) is None:
            problems.append("неизвестный id иконки — приложение его не найдёт")
        if element.extra.get(constants.EXT_CUSTOM_ICON):
            problems.append("своя иконка вместо встроенной")
    return problems


def pretty_weather_list() -> List[str]:
    return ["%d — %s" % (i, item["ru"]) for i, item in enumerate(WEATHER_STATES)]
