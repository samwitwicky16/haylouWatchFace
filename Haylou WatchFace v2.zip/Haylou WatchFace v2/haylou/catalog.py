# -*- coding: utf-8 -*-
"""Справочник формата: 30 известных имён элементов + 30 официальных иконок.

Это единый источник правды для GUI, валидации и рендера:
имя слоя -> русская подпись, допустимые виды ресурса, типовые sections/properties,
смысловая роль (по ней берётся значение из симуляции).
"""

from __future__ import annotations

from collections import OrderedDict
from typing import Dict, List, Optional

# ---------------------------------------------------------------------------
# Каталог имён элементов. Порядок = «естественный» порядок отрисовки,
# им пользуется заготовка «полный циферблат».
# ---------------------------------------------------------------------------
ALL_KINDS = ["font", "resourceCharacter", "resourceImage", "resourceIcon"]
IMAGE_KINDS = ["resourceImage", "resourceIcon"]
HAND_KINDS = ["resourceIcon", "resourceImage"]

ELEMENTS: "OrderedDict[str, dict]" = OrderedDict([
    ("dial", dict(ru="Фон циферблата", kind_default="resourceImage",
                  kind_allowed=["resourceImage"], typical_properties=[],
                  typical_sections=[1], data_role="dial")),
    ("hour", dict(ru="Часы (число)", kind_default="font", kind_allowed=ALL_KINDS,
                  typical_properties=[], typical_sections=[1],
                  data_role="hour")),
    ("timeSeparator", dict(ru="Разделитель времени", kind_default="font",
                           kind_allowed=ALL_KINDS, typical_properties=[],
                           typical_sections=[1], data_role="timeSep")),
    ("minute", dict(ru="Минуты", kind_default="font", kind_allowed=ALL_KINDS,
                    typical_properties=[], typical_sections=[1],
                    data_role="minute")),
    ("second", dict(ru="Секунды", kind_default="font", kind_allowed=ALL_KINDS,
                    typical_properties=[], typical_sections=[1],
                    data_role="second")),
    ("hourHand", dict(ru="Часовая стрелка", kind_default="resourceIcon",
                      kind_allowed=HAND_KINDS, typical_properties=[1],
                      typical_sections=[1], data_role="hourHand")),
    ("minuteHand", dict(ru="Минутная стрелка", kind_default="resourceIcon",
                        kind_allowed=HAND_KINDS, typical_properties=[1],
                        typical_sections=[1], data_role="minuteHand")),
    ("secondHand", dict(ru="Секундная стрелка", kind_default="resourceIcon",
                        kind_allowed=HAND_KINDS, typical_properties=[4],
                        typical_sections=[1], data_role="secondHand")),
    ("year", dict(ru="Год", kind_default="font", kind_allowed=ALL_KINDS,
                  typical_properties=[], typical_sections=[1],
                  data_role="year")),
    ("yearSeparator", dict(ru="Разделитель года", kind_default="font",
                           kind_allowed=ALL_KINDS, typical_properties=[],
                           typical_sections=[1], data_role="yearSep")),
    ("month", dict(ru="Месяц", kind_default="font", kind_allowed=ALL_KINDS,
                   typical_properties=[], typical_sections=[1],
                   data_role="month")),
    ("dateSeparator", dict(ru="Разделитель даты", kind_default="font",
                           kind_allowed=ALL_KINDS, typical_properties=[],
                           typical_sections=[1], data_role="dateSep")),
    ("day", dict(ru="День", kind_default="font", kind_allowed=ALL_KINDS,
                 typical_properties=[], typical_sections=[1],
                 data_role="day")),
    ("dayOfWeek", dict(ru="День недели", kind_default="font",
                       kind_allowed=ALL_KINDS, typical_properties=[34],
                       typical_sections=[1, 7], data_role="weekday")),
    ("step", dict(ru="Шаги", kind_default="font", kind_allowed=ALL_KINDS,
                  typical_properties=[], typical_sections=[1],
                  data_role="steps")),
    ("stepResource", dict(ru="Иконка шагов", kind_default="resourceIcon",
                          kind_allowed=ALL_KINDS, typical_properties=[],
                          typical_sections=[1], data_role="stepsIcon")),
    ("stepGoalProgressResource", dict(ru="Кольцо цели по шагам",
                                      kind_default="resourceIcon",
                                      kind_allowed=ALL_KINDS,
                                      typical_properties=[], typical_sections=[11],
                                      data_role="goal")),
    ("calorie", dict(ru="Калории", kind_default="font", kind_allowed=ALL_KINDS,
                     typical_properties=[], typical_sections=[1],
                     data_role="calories")),
    ("calorieResource", dict(ru="Иконка калорий", kind_default="resourceIcon",
                             kind_allowed=ALL_KINDS, typical_properties=[],
                             typical_sections=[1], data_role="caloriesIcon")),
    ("distance", dict(ru="Дистанция", kind_default="font",
                      kind_allowed=ALL_KINDS, typical_properties=[],
                      typical_sections=[1], data_role="distance")),
    ("distanceResource", dict(ru="Иконка дистанции", kind_default="resourceIcon",
                              kind_allowed=ALL_KINDS, typical_properties=[],
                              typical_sections=[1], data_role="distanceIcon")),
    ("heartRate", dict(ru="Пульс", kind_default="font", kind_allowed=ALL_KINDS,
                       typical_properties=[], typical_sections=[1],
                       data_role="heart")),
    ("heartRateResource", dict(ru="Иконка пульса", kind_default="resourceIcon",
                               kind_allowed=ALL_KINDS, typical_properties=[],
                               typical_sections=[1], data_role="heartIcon")),
    ("battery", dict(ru="Заряд", kind_default="font", kind_allowed=ALL_KINDS,
                     typical_properties=[36], typical_sections=[1],
                     data_role="battery")),
    ("batteryPercentSign", dict(ru="Знак процента", kind_default="font",
                                kind_allowed=ALL_KINDS, typical_properties=[],
                                typical_sections=[1], data_role="percent")),
    ("batteryResource", dict(ru="Иконка заряда", kind_default="resourceIcon",
                             kind_allowed=ALL_KINDS, typical_properties=[],
                             typical_sections=[5, 11], data_role="batteryIcon")),
    ("connectionResource", dict(ru="Иконка Bluetooth", kind_default="resourceIcon",
                                kind_allowed=ALL_KINDS, typical_properties=[],
                                typical_sections=[2], data_role="connection")),
    ("weatherTemperature", dict(ru="Температура", kind_default="font",
                                kind_allowed=ALL_KINDS, typical_properties=[4],
                                typical_sections=[1], data_role="temp")),
    ("weatherTemperatureUnitSign", dict(ru="Знак градуса", kind_default="font",
                                        kind_allowed=ALL_KINDS,
                                        typical_properties=[4],
                                        typical_sections=[1], data_role="degree")),
    ("weatherResource", dict(ru="Иконка погоды", kind_default="resourceIcon",
                             kind_allowed=ALL_KINDS, typical_properties=[],
                             typical_sections=[16], data_role="weather")),
])

# Группы для удобной навигации в GUI
ELEMENT_GROUPS = OrderedDict([
    ("Фон и время", ["dial", "hour", "timeSeparator", "minute", "second"]),
    ("Стрелки", ["hourHand", "minuteHand", "secondHand"]),
    ("Дата", ["year", "yearSeparator", "month", "dateSeparator", "day", "dayOfWeek"]),
    ("Активность", ["step", "stepResource", "stepGoalProgressResource",
                    "calorie", "calorieResource", "distance", "distanceResource"]),
    ("Здоровье", ["heartRate", "heartRateResource"]),
    ("Батарея и связь", ["battery", "batteryPercentSign", "batteryResource",
                         "connectionResource"]),
    ("Погода", ["weatherResource", "weatherTemperature",
                "weatherTemperatureUnitSign"]),
])

# ---------------------------------------------------------------------------
# 30 официальных id встроенных иконок Hello Haylou + наши «двойники».
# В файл всегда пишется официальный id, наша иконка нужна только для превью.
# ---------------------------------------------------------------------------
OFFICIAL_ICONS: List[dict] = [
    dict(id="batteryResource_ic_wf_anim_battery_circle.png", ru="Батарея: круг",
         element="batteryResource", our_icon="battery", sections=11),
    dict(id="batteryResource_ic_wf_anim_battery_horizontal.png", ru="Батарея: горизонтальная",
         element="batteryResource", our_icon="battery", sections=5),
    dict(id="batteryResource_ic_wf_anim_battery_semicircular.png", ru="Батарея: полукруг",
         element="batteryResource", our_icon="battery", sections=11),
    dict(id="batteryResource_ic_wf_anim_battery_vertical.png", ru="Батарея: вертикальная",
         element="batteryResource", our_icon="battery_low", sections=5),
    dict(id="calorieResource_ic_wf_calorie_burn.png", ru="Калории: огонь",
         element="calorieResource", our_icon="flame", sections=1),
    dict(id="calorieResource_ic_wf_calorie_burn_5.png", ru="Калории: огонь (5 кадров)",
         element="calorieResource", our_icon="flame", sections=5),
    dict(id="connectionResource_ic_wf_anim_connection_ble.png", ru="Связь: BLE",
         element="connectionResource", our_icon="bluetooth", sections=2),
    dict(id="connectionResource_ic_wf_anim_connection_link.png", ru="Связь: звено",
         element="connectionResource", our_icon="bluetooth", sections=2),
    dict(id="distanceResource_ic_wf_distance_direction.png", ru="Дистанция: направление",
         element="distanceResource", our_icon="route", sections=1),
    dict(id="distanceResource_ic_wf_distance_map_marker.png", ru="Дистанция: маркер",
         element="distanceResource", our_icon="map_marker", sections=1),
    dict(id="heartRateResource_ic_wf_heart_rate_beat.png", ru="Пульс: кардиограмма",
         element="heartRateResource", our_icon="heart_pulse", sections=1),
    dict(id="heartRateResource_ic_wf_heart_rate_favorite.png", ru="Пульс: сердце",
         element="heartRateResource", our_icon="heart", sections=1),
    dict(id="hourHand_ic_wf_hand_hour_fill.png", ru="Часовая: заливка",
         element="hourHand", our_icon="hand_hour", sections=1),
    dict(id="hourHand_ic_wf_hand_hour_fill_2.png", ru="Часовая: заливка 2",
         element="hourHand", our_icon="hand_hour", sections=1),
    dict(id="hourHand_ic_wf_hand_hour_outline.png", ru="Часовая: контур",
         element="hourHand", our_icon="hand_hour", sections=1),
    dict(id="hourHand_ic_wf_hand_hour_round.png", ru="Часовая: круглая",
         element="hourHand", our_icon="hand_hour", sections=1),
    dict(id="minuteHand_ic_wf_hand_minute_fill.png", ru="Минутная: заливка",
         element="minuteHand", our_icon="hand_minute", sections=1),
    dict(id="minuteHand_ic_wf_hand_minute_fill_2.png", ru="Минутная: заливка 2",
         element="minuteHand", our_icon="hand_minute", sections=1),
    dict(id="minuteHand_ic_wf_hand_minute_outline.png", ru="Минутная: контур",
         element="minuteHand", our_icon="hand_minute", sections=1),
    dict(id="minuteHand_ic_wf_hand_minute_round.png", ru="Минутная: круглая",
         element="minuteHand", our_icon="hand_minute", sections=1),
    dict(id="secondHand_ic_wf_hand_second_fill.png", ru="Секундная: заливка",
         element="secondHand", our_icon="hand_second", sections=1),
    dict(id="secondHand_ic_wf_hand_second_fill_2.png", ru="Секундная: заливка 2",
         element="secondHand", our_icon="hand_second", sections=1),
    dict(id="secondHand_ic_wf_hand_second_outline.png", ru="Секундная: контур",
         element="secondHand", our_icon="hand_second", sections=1),
    dict(id="secondHand_ic_wf_hand_second_round.png", ru="Секундная: круглая",
         element="secondHand", our_icon="hand_second", sections=1),
    dict(id="stepGoalProgressResource_ic_wf_anim_goal_circular.png",
         ru="Цель по шагам: кольцо", element="stepGoalProgressResource",
         our_icon="ring", sections=11),
    dict(id="stepResource_ic_wf_step_foot_print.png", ru="Шаги: след",
         element="stepResource", our_icon="footprint", sections=1),
    dict(id="stepResource_ic_wf_step_shoe_print.png", ru="Шаги: отпечаток",
         element="stepResource", our_icon="shoe", sections=1),
    dict(id="stepResource_ic_wf_step_sneakers_2.png", ru="Шаги: кроссовки",
         element="stepResource", our_icon="run", sections=1),
    dict(id="weatherResource_ic_wf_anim_weather_fill.png", ru="Погода: заливка",
         element="weatherResource", our_icon="cloud_sun", sections=16),
    dict(id="weatherResource_ic_wf_anim_weather_outline.png", ru="Погода: контур",
         element="weatherResource", our_icon="cloud", sections=16),
]

_OFFICIAL_BY_ID: Dict[str, dict] = {item["id"]: item for item in OFFICIAL_ICONS}


# ---------------------------------------------------------------------------
# Функции доступа
# ---------------------------------------------------------------------------
def is_known(name: str) -> bool:
    return name in ELEMENTS


def get_info(name: str) -> dict:
    """Информация об имени; для неизвестных имён возвращается безопасный дефолт."""
    info = ELEMENTS.get(name)
    if info is None:
        return dict(ru=None, kind_default="font", kind_allowed=list(ALL_KINDS),
                    typical_properties=[], typical_sections=[1],
                    data_role="none", known=False)
    out = dict(info)
    out["known"] = True
    return out


def ru_name(name: str) -> str:
    """Русская подпись слоя (для неизвестных — само имя)."""
    info = ELEMENTS.get(name)
    return info["ru"] if info else name


def data_role(name: str) -> str:
    info = ELEMENTS.get(name)
    return info["data_role"] if info else "none"


def default_kind(name: str) -> str:
    info = ELEMENTS.get(name)
    return info["kind_default"] if info else "font"


def allowed_kinds(name: str) -> List[str]:
    info = ELEMENTS.get(name)
    return list(info["kind_allowed"]) if info else list(ALL_KINDS)


def typical_properties(name: str) -> List[int]:
    info = ELEMENTS.get(name)
    return list(info["typical_properties"]) if info else []


def typical_sections(name: str) -> List[int]:
    info = ELEMENTS.get(name)
    return list(info["typical_sections"]) if info else [1]


def official_icon(icon_id: str) -> Optional[dict]:
    return _OFFICIAL_BY_ID.get(icon_id)


def icons_for_element(name: str) -> List[dict]:
    """Официальные иконки, привязанные к данному имени слоя."""
    return [item for item in OFFICIAL_ICONS if item["element"] == name]


def our_icon_for(official_id: str, fallback: str = "star") -> str:
    """Какой нашей иконкой нарисовать официальный id в превью."""
    item = _OFFICIAL_BY_ID.get(official_id)
    if item:
        return item["our_icon"]
    # Попытка угадать по вхождению ключевого слова в id
    low = (official_id or "").lower()
    for key, icon in (("battery", "battery"), ("calorie", "flame"),
                      ("connection", "bluetooth"), ("distance", "route"),
                      ("heart", "heart"), ("hand_hour", "hand_hour"),
                      ("hand_minute", "hand_minute"), ("hand_second", "hand_second"),
                      ("goal", "ring"), ("step", "footprint"), ("weather", "cloud_sun")):
        if key in low:
            return icon
    return fallback


def role_label(role: str) -> str:
    """Русская подпись смысловой роли (для панели свойств)."""
    return {
        "dial": "фон", "hour": "часы", "minute": "минуты", "second": "секунды",
        "timeSep": "разделитель времени", "hourHand": "часовая стрелка",
        "minuteHand": "минутная стрелка", "secondHand": "секундная стрелка",
        "year": "год", "yearSep": "разделитель года", "month": "месяц",
        "dateSep": "разделитель даты", "day": "день", "weekday": "день недели",
        "steps": "шаги", "stepsIcon": "иконка шагов", "goal": "цель по шагам",
        "calories": "калории", "caloriesIcon": "иконка калорий",
        "distance": "дистанция", "distanceIcon": "иконка дистанции",
        "heart": "пульс", "heartIcon": "иконка пульса", "battery": "заряд",
        "percent": "знак %", "batteryIcon": "иконка заряда",
        "connection": "Bluetooth", "temp": "температура", "degree": "градус",
        "weather": "погода", "none": "без данных",
    }.get(role, role)
