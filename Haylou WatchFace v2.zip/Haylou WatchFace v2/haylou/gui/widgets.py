# -*- coding: utf-8 -*-
"""Мелкие переиспользуемые виджеты tkinter для редактора."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Callable, Optional


class ScrollFrame(ttk.Frame):
    """Прокручиваемая область: внутрь кладём self.inner."""

    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        self.canvas = tk.Canvas(self, bg="#ffffff", highlightthickness=0)
        self.vs = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vs.set)
        self.vs.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = ttk.Frame(self.canvas, padding=6)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._on_inner)
        self.canvas.bind("<Configure>", self._on_canvas)
        self.canvas.bind("<Enter>", self._bind_wheel)
        self.canvas.bind("<Leave>", self._unbind_wheel)

    def _on_inner(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas(self, event):
        self.canvas.itemconfigure(self._win, width=event.width)

    def _bind_wheel(self, _event=None):
        self.canvas.bind_all("<MouseWheel>", self._wheel)

    def _unbind_wheel(self, _event=None):
        self.canvas.unbind_all("<MouseWheel>")

    def _wheel(self, event):
        # Прокрутка только если контент выше видимой области
        try:
            bbox = self.canvas.bbox("all")
            if not bbox or bbox[3] <= self.canvas.winfo_height():
                return
            self.canvas.yview_scroll(int(-event.delta / 120), "units")
        except tk.TclError:
            pass

    def clear(self):
        for child in self.inner.winfo_children():
            child.destroy()
        self.canvas.yview_moveto(0)


class Section(ttk.LabelFrame):
    """Секция в боковой панели с единым стилем."""

    def __init__(self, master, title: str, **kw):
        kw.setdefault("padding", 6)
        super().__init__(master, text=title, **kw)
        self.body = ttk.Frame(self)
        self.body.pack(fill="both", expand=True)
        self.body.columnconfigure(1, weight=1)


def label(parent, text: str, **kw) -> ttk.Label:
    return ttk.Label(parent, text=text, **kw)


def row_entry(parent, row: int, caption: str, var, width: int = 8,
              command: Optional[Callable] = None, label_width: int = 14) -> ttk.Entry:
    """Строка «подпись + поле ввода». command вызывается по Enter/FocusOut."""
    ttk.Label(parent, text=caption, width=label_width).grid(
        row=row, column=0, sticky="w", pady=1)
    ent = ttk.Entry(parent, textvariable=var, width=width)
    ent.grid(row=row, column=1, sticky="ew", pady=1)
    if command is not None:
        ent.bind("<Return>", lambda e: command())
        ent.bind("<FocusOut>", lambda e: command())
    return ent


def row_scale(parent, row: int, caption: str, var, from_: float, to: float,
              command: Optional[Callable] = None, label_width: int = 14) -> ttk.Scale:
    ttk.Label(parent, text=caption, width=label_width).grid(
        row=row, column=0, sticky="w", pady=1)
    sc = ttk.Scale(parent, from_=from_, to=to, variable=var,
                   command=(lambda v: command()) if command else None)
    sc.grid(row=row, column=1, sticky="ew", pady=1)
    return sc


class Swatch(tk.Canvas):
    """Квадратик цвета, по клику — палитра (через колбэк)."""

    def __init__(self, master, hex_color: str = "#FFFFFF", size: int = 20,
                 on_click: Optional[Callable] = None):
        super().__init__(master, width=size, height=size, highlightthickness=1,
                         highlightbackground="#888", bd=0)
        self._size = size
        self._on_click = on_click
        self.set_color(hex_color)
        if on_click is not None:
            self.bind("<Button-1>", lambda e: on_click())

    def set_color(self, hex_color: str):
        self.delete("all")
        self.create_rectangle(0, 0, self._size, self._size, fill=hex_color, outline="")


class IconGrid(tk.Frame):
    """Сетка кнопок-иконок с подписями (для библиотеки иконок)."""

    def __init__(self, master, on_pick: Callable[[str], None],
                 thumb: int = 30, columns: int = 4, bg: str = "#ffffff"):
        super().__init__(master, bg=bg)
        self.on_pick = on_pick
        self.thumb = thumb
        self.columns = columns
        self.bg = bg
        self._images = {}          # держим ссылки, иначе Tk выбросит картинки
        self._cells = 0

    def clear(self):
        for child in self.winfo_children():
            child.destroy()
        self._images.clear()
        self._cells = 0

    def add_icon(self, name: str, ru: str, image, rgba_text: str = "#000000"):
        idx = self._cells
        self._cells += 1
        r, c = divmod(idx, self.columns)
        cell = tk.Frame(self, bg=self.bg)
        cell.grid(row=r, column=c, padx=2, pady=2, sticky="nsew")
        btn = tk.Label(cell, image=image, bg=self.bg, cursor="hand2",
                       bd=1, relief="flat", padx=2, pady=2)
        btn.image = image                      # noqa: SLF001  (ссылка на картинку)
        btn.pack()
        btn.bind("<Button-1>", lambda e, n=name: self.on_pick(n))
        lbl = tk.Label(cell, text=ru, bg=self.bg, fg=rgba_text, font=("Segoe UI", 7),
                       wraplength=self.thumb * 2, justify="center")
        lbl.pack()
        self.columnconfigure(c, weight=1)


class ToggleButton(ttk.Checkbutton):
    """Флажок в виде кнопки — удобно для тулбара."""

    def __init__(self, master, text: str, var: tk.BooleanVar, command=None):
        super().__init__(master, text=text, variable=var, style="Toolbutton",
                         command=command)
