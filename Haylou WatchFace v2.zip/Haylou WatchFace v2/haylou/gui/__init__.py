# -*- coding: utf-8 -*-
"""GUI-слой редактора Haylou Watchface Studio.

Модули:
    app            — главное окно, меню, панель инструментов, статусбар
    canvas_view    — канва превью (вписать/масштаб, выбор и перетаскивание)
    panel_layers   — список слоёв: порядок, видимость, добавление/удаление
    panel_props    — свойства выбранного слоя
    panel_sim      — симуляция данных (шаги, пульс, заряд, погода, ночь…)
    panel_resources— ресурсы проекта и библиотека официальных иконок
    widgets        — мелкие переиспользуемые виджеты
"""

__all__ = ["app", "canvas_view", "panel_layers", "panel_props",
           "panel_sim", "panel_resources", "widgets"]
