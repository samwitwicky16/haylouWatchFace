# -*- coding: utf-8 -*-
"""Канва превью: масштабирование под окно, выбор и перетаскивание слоёв."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Optional, Tuple

from PIL import Image, ImageTk

from .. import constants, renderer

MIN_ZOOM = 0.08
MAX_ZOOM = 3.0
SNAP_VALUES = (0.5, 1.0 / 3.0, 2.0 / 3.0, 0.25, 0.75)
SNAP_EPS = 0.008


class PreviewCanvas(ttk.Frame):
    """Превью циферблата. Все данные берём у приложения (app)."""

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.canvas = tk.Canvas(self, bg="#242a35", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self._photo = None
        self._pending = None
        self.zoom = 0.8
        self.ox = 0
        self.oy = 0
        self._drag = None
        self.canvas.bind("<Configure>", lambda e: self.schedule(80))
        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind("<MouseWheel>", self._on_wheel)
        self.canvas.bind("<Button-4>", lambda e: self._zoom_step(+0.1))
        self.canvas.bind("<Button-5>", lambda e: self._zoom_step(-0.1))

    # ------------------------------------------------------------------ служебное
    def schedule(self, delay: int = 40):
        """Склеить несколько запросов перерисовки в один."""
        if self._pending is not None:
            try:
                self.after_cancel(self._pending)
            except tk.TclError:
                pass
        self._pending = self.after(delay, self.redraw)

    def _geom(self) -> Tuple[float, int, int, int, int]:
        cw = max(1, self.canvas.winfo_width())
        ch = max(1, self.canvas.winfo_height())
        margin = 18
        zoom = min((cw - 2 * margin) / constants.SCREEN_W,
                   (ch - 2 * margin) / constants.SCREEN_H)
        zoom = max(MIN_ZOOM, zoom) * self.app.zoom_mult
        bw = constants.SCREEN_W * zoom
        bh = constants.SCREEN_H * zoom
        ox = int((cw - bw) / 2)
        oy = int((ch - bh) / 2)
        return zoom, ox, oy, int(bw), int(bh)

    def _zoom_step(self, delta: float):
        self.app.zoom_mult = max(0.3, min(MAX_ZOOM, self.app.zoom_mult + delta))
        self.schedule(10)

    def _on_wheel(self, event):
        if event.state & 0x0004:      # Ctrl + колесо = масштаб
            self._zoom_step(0.08 if event.delta > 0 else -0.08)

    # ------------------------------------------------------------------ отрисовка
    def redraw(self):
        self._pending = None
        doc = self.app.doc
        if doc is None:
            self.canvas.delete("all")
            return
        self.canvas.delete("all")
        zoom, ox, oy, bw, bh = self._geom()
        self.zoom, self.ox, self.oy = zoom, ox, oy

        try:
            img = renderer.render_document(doc, self.app.sim,
                                           constants.SCREEN_W, constants.SCREEN_H,
                                           resources=self.app.store,
                                           t=self.app.t)
        except Exception as exc:                       # noqa: BLE001
            img = renderer.placeholder_dial(constants.SCREEN_W, constants.SCREEN_H)
            self.app.note("Ошибка отрисовки: %s" % exc, error=True)

        if zoom != 1.0:
            img = img.resize((bw, bh), Image.LANCZOS)
        self._photo = ImageTk.PhotoImage(img)
        self.canvas.create_image(ox, oy, image=self._photo, anchor="nw",
                                 tags="paper")
        self.canvas.create_rectangle(ox, oy, ox + bw, oy + bh,
                                     outline="#0d1117", width=2)

        if self.app.show_grid:
            self._draw_grid(ox, oy, bw, bh)
        if self.app.show_safe:
            self._draw_safe(ox, oy, bw, bh)
        self._draw_selection(ox, oy)

    def _draw_grid(self, ox, oy, bw, bh):
        for i in range(1, 10):
            x = ox + bw * i / 10.0
            y = oy + bh * i / 10.0
            self.canvas.create_line(x, oy, x, oy + bh, fill="#48566b", dash=(2, 4))
            self.canvas.create_line(ox, y, ox + bw, y, fill="#48566b", dash=(2, 4))
        self.canvas.create_line(ox + bw / 2, oy, ox + bw / 2, oy + bh,
                                fill="#6d7f96", dash=(1, 3))
        self.canvas.create_line(ox, oy + bh / 2, ox + bw, oy + bh / 2,
                                fill="#6d7f96", dash=(1, 3))

    def _draw_safe(self, ox, oy, bw, bh):
        # Круглая «безопасная зона» — подсказка, что у RS5 прямоугольный экран,
        # но углы лучше не занимать важным.
        pad = min(bw, bh) * 0.04
        self.canvas.create_rectangle(ox + pad, oy + pad, ox + bw - pad, oy + bh - pad,
                                     outline="#7f8c9b", dash=(4, 4))

    def _element_box_canvas(self, el):
        """Рамка элемента в координатах канвы."""
        zoom = self.zoom
        try:
            x0, y0, x1, y1 = renderer.element_box_screen(el, zoom)
        except Exception:                              # noqa: BLE001
            size = (el.get_size() or 0.06) * constants.SCREEN_W * zoom
            cx = (el.x or 0.5) * constants.SCREEN_W * zoom
            cy = (el.y or 0.5) * constants.SCREEN_H * zoom
            x0, y0, x1, y1 = cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2
        return (x0 + self.ox, y0 + self.oy, x1 + self.ox, y1 + self.oy)

    def _draw_selection(self, ox, oy):
        name = self.app.selected
        if not name or name not in self.app.doc:
            return
        el = self.app.doc.elements[name]
        x0, y0, x1, y1 = self._element_box_canvas(el)
        self.canvas.create_rectangle(x0, y0, x1, y1, outline="#42a5f5", width=2)
        for (px, py) in ((x0, y0), (x1, y0), (x0, y1), (x1, y1)):
            self.canvas.create_rectangle(px - 3, py - 3, px + 3, py + 3,
                                         fill="#42a5f5", outline="")
        label = "%s  x=%.3f y=%.3f" % (name, el.x if el.x is not None else 0.5,
                                       el.y if el.y is not None else 0.5)
        self.canvas.create_text(x0, max(oy + 8, y0 - 8), text=label, anchor="sw",
                                fill="#cfe3ff", font=("Segoe UI", 8))

    # ------------------------------------------------------------------ мышь
    def _to_logical(self, cx, cy):
        lx = (cx - self.ox) / max(1e-6, self.zoom)
        ly = (cy - self.oy) / max(1e-6, self.zoom)
        return lx, ly

    def hit_test(self, cx, cy) -> Optional[str]:
        doc = self.app.doc
        if doc is None:
            return None
        for el in reversed(doc.all_elements()):
            if el.name == "dial" or not el.visible:
                continue
            x0, y0, x1, y1 = self._element_box_canvas(el)
            if x0 - 4 <= cx <= x1 + 4 and y0 - 4 <= cy <= y1 + 4:
                return el.name
        return None

    def _on_press(self, event):
        name = self.hit_test(event.x, event.y)
        self.app.select(name)
        if not name:
            self._drag = None
            return
        el = self.app.doc.elements[name]
        self._drag = {
            "name": name,
            "start_x": el.x if el.x is not None else 0.5,
            "start_y": el.y if el.y is not None else 0.5,
            "px": event.x, "py": event.y,
            "moved": False,
        }
        self.canvas.focus_set()

    def _on_drag(self, event):
        if not self._drag:
            return
        el = self.app.doc.elements.get(self._drag["name"])
        if el is None or el.name == "dial":
            return
        dx = (event.x - self._drag["px"]) / max(1e-6, self.zoom) / constants.SCREEN_W
        dy = (event.y - self._drag["py"]) / max(1e-6, self.zoom) / constants.SCREEN_H
        nx = self._drag["start_x"] + dx
        ny = self._drag["start_y"] + dy
        if not (event.state & 0x0001):                  # Shift — без привязки
            nx = self._snap(nx)
            ny = self._snap(ny)
        el.x = max(0.0, min(1.0, nx))
        el.y = max(0.0, min(1.0, ny))
        self._drag["moved"] = True
        self.app.on_geometry_drag(el)
        self.schedule(10)

    def _snap(self, value: float) -> float:
        for target in SNAP_VALUES:
            if abs(value - target) < SNAP_EPS:
                return target
        return value

    def _on_release(self, event):
        drag, self._drag = self._drag, None
        if drag and drag["moved"]:
            el = self.app.doc.elements.get(drag["name"])
            if el is not None:
                self.app.push_history("Перемещение «%s»" % self.app.ru_name(el.name))
                self.app.after_change()
