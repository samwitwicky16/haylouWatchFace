# -*- coding: utf-8 -*-
"""Панель «Слои»: дерево слоёв документа с порядком отрисовки.

Список показывает слои снизу вверх (как в JSON, первый — самый нижний).
Кнопки позволяют добавить слой, поднять/опустить его, скопировать,
удалить и переключить видимость (или клавишей Пробел).
"""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk
from typing import Optional

from .. import catalog
from .widgets import Section


# Быстрое меню «добавить слой»: подпись → (базовое имя, kind)
QUICK_ADD = [
    ("Текст (время/дата)", "textTime", "font"),
    ("Цифры (шрифт-картинки)", "digits", "resourceCharacter"),
    ("Иконка (официальная)", "icon", "resourceIcon"),
    ("Картинка (PNG из ресурсов)", "picture", "resourceImage"),
    ("Стрелка часов", "hourHand", "resourceImage"),
    ("Стрелка минут", "minuteHand", "resourceImage"),
    ("Стрелка секунд", "secondHand", "resourceImage"),
]


class LayersPanel(ttk.Frame):
    """Дерево слоёв + операции над порядком и видимостью."""

    def __init__(self, master, app) -> None:
        super().__init__(master, padding=6)
        self.app = app
        self._syncing = False

        # ------------------------------------------------------------- дерево
        sec = Section(self, "Слои циферблата")
        sec.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(sec.body, columns=("ru", "kind", "vis"),
                                 show="tree headings", height=18)
        self.tree.heading("#0", text="Слой")
        self.tree.heading("ru", text="Название")
        self.tree.heading("kind", text="Тип")
        self.tree.heading("vis", text="Вид")
        self.tree.column("#0", width=140, anchor="w")
        self.tree.column("ru", width=120, anchor="w")
        self.tree.column("kind", width=86, anchor="w")
        self.tree.column("vis", width=38, anchor="center")
        vs = ttk.Scrollbar(sec.body, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")

        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<space>", lambda e: self._toggle_visible())
        self.tree.bind("<Button-3>", self._on_right_click)

        # ------------------------------------------------------------ кнопки
        btns = ttk.Frame(self)
        btns.pack(fill="x", pady=(6, 0))
        self.btn_add = ttk.Menubutton(btns, text="Добавить ▾")
        menu = tk.Menu(self.btn_add, tearoff=0)
        for caption, base, kind in QUICK_ADD:
            menu.add_command(label=caption,
                             command=lambda b=base, k=kind: self.app.add_element(b, k))
        menu.add_separator()
        menu.add_command(label="Пустой слой (font)",
                         command=lambda: self.app.add_element("layer", "font"))
        self.btn_add["menu"] = menu
        self.btn_add.pack(side="left")

        ttk.Button(btns, text="▲", width=3, command=lambda: self._move(-1)).pack(side="left", padx=(6, 0))
        ttk.Button(btns, text="▼", width=3, command=lambda: self._move(1)).pack(side="left", padx=2)
        ttk.Button(btns, text="Копия", command=self.app.duplicate_selected).pack(side="left", padx=2)
        ttk.Button(btns, text="Удалить", command=self.app.delete_selected).pack(side="left", padx=2)

        btns2 = ttk.Frame(self)
        btns2.pack(fill="x", pady=(4, 0))
        ttk.Button(btns2, text="Видимость", command=self._toggle_visible).pack(side="left")
        ttk.Button(btns2, text="Переименовать", command=self.app.rename_selected).pack(side="left", padx=4)

        self.lbl_count = ttk.Label(self, text="", style="Hint.TLabel")
        self.lbl_count.pack(anchor="w", pady=(4, 0))

    # ================================================================= служебное
    def refresh(self) -> None:
        """Полностью перестроить дерево по документу."""
        doc = self.app.doc
        self._syncing = True
        try:
            self.tree.delete(*self.tree.get_children(""))
            if doc is None:
                self.lbl_count.configure(text="документ не открыт")
                return
            total = 0
            for name, el in doc.elements.items():
                total += 1
                ru = self.app.ru_name(name)
                kind = el.kind or "—"
                vis = "да" if el.visible else "нет"
                self.tree.insert("", "end", iid=name, text=name,
                                 values=(ru, kind, vis))
            self.lbl_count.configure(
                text="Всего слоёв: %d%s" % (total, "" if total else " (пусто)"))
            if self.app.selected and self.tree.exists(self.app.selected):
                self.tree.selection_set(self.app.selected)
                self.tree.see(self.app.selected)
        finally:
            self._syncing = False

    def highlight(self, name: Optional[str]) -> None:
        """Подсветить слой, не порождая лишних событий."""
        self._syncing = True
        try:
            if name and self.tree.exists(name):
                self.tree.selection_set(name)
                self.tree.see(name)
            elif not name:
                self.tree.selection_remove(*self.tree.selection())
        finally:
            self._syncing = False

    # ================================================================= события
    def _on_select(self, _event=None) -> None:
        if self._syncing:
            return
        sel = self.tree.selection()
        if not sel:
            return
        self.app.select(sel[0])

    def _on_right_click(self, event) -> None:
        item = self.tree.identify_row(event.y)
        if not item:
            return
        self.tree.selection_set(item)
        self.app.select(item)
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Дублировать", command=self.app.duplicate_selected)
        menu.add_command(label="Переименовать…", command=self.app.rename_selected)
        menu.add_separator()
        menu.add_command(label="Поднять выше", command=lambda: self._move(-1))
        menu.add_command(label="Опустить ниже", command=lambda: self._move(1))
        menu.add_command(label="На самый верх", command=lambda: self._move(-999))
        menu.add_command(label="В самый низ", command=lambda: self._move(999))
        menu.add_separator()
        menu.add_command(label="Показать/скрыть", command=self._toggle_visible)
        menu.add_command(label="Удалить", command=self.app.delete_selected)
        menu.tk_popup(event.x_root, event.y_root)

    # ================================================================= операции
    def _move(self, delta: int) -> None:
        doc = self.app.doc
        name = self.app.selected
        if doc is None or not name:
            return
        if delta in (-999, 999):
            index = 0 if delta < 0 else len(doc) - 1
            self.app.push_history("Перемещение слоя «%s»" % name)
            doc.move(name, index)
        else:
            self.app.push_history("Перемещение слоя «%s»" % name)
            doc.move_by(name, delta)
        self.app.after_change()
        self.app.canvas_view.schedule(10)

    def _toggle_visible(self) -> None:
        doc = self.app.doc
        name = self.app.selected
        if doc is None or not name:
            return
        el = doc.elements.get(name)
        if el is None:
            return
        if name == "dial":
            messagebox.showinfo("Слой", "Фон dial лучше не скрывать — превью станет пустым.")
        el.visible = not el.visible
        self.app.push_history("Видимость «%s»" % name)
        self.app.after_change()
        self.app.canvas_view.schedule(10)
        self.app.note("Слой «%s»: %s" % (name, "виден" if el.visible else "скрыт"))
