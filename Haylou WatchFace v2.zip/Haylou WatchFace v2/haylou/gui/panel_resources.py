# -*- coding: utf-8 -*-
"""Панель «Ресурсы»: картинки и шрифтовые файлы внутри проекта.

Внутри проекта ресурсы лежат как словарь «путь в JSON → байты» (см. tbfw.py).
Панель показывает, что именно упаковано в файл, сколько слоёв ссылается на
каждый ресурс, и позволяет импортировать/извлекать/удалять их.

Чистка «мусора» (кнопка «Удалить неиспользуемые») полезна перед сохранением:
лишние картинки раздувают .tbwf и замедляют загрузку часов.
"""

from __future__ import annotations

import io
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Dict, List, Optional

from .. import constants

try:                                              # Pillow нужен только для превью
    from PIL import Image, ImageTk
    HAS_PIL = True
except Exception:                                 # noqa: BLE001
    Image = ImageTk = None                        # type: ignore[assignment]
    HAS_PIL = False


def _kind_of(path: str) -> str:
    """Тип ресурса по префиксу пути."""
    low = "/" + (path or "").replace("\\", "/").strip().lstrip("/").lower()
    if low.startswith(constants.RES_IMAGE_DIR.lower()):
        return "изображение"
    if low.startswith(constants.RES_CHAR_DIR.lower()):
        return "цифры/символы"
    if low.startswith(constants.FONT_DIR.lower()):
        return "шрифт"
    return "прочее"


def _human_size(size: int) -> str:
    if size < 1024:
        return "%d Б" % size
    if size < 1024 * 1024:
        return "%.1f КБ" % (size / 1024.0)
    return "%.2f МБ" % (size / (1024.0 * 1024.0))


class ResourcesPanel(ttk.Frame):
    """Список ресурсов документа с превью и обслуживанием."""

    def __init__(self, master, app) -> None:
        super().__init__(master, padding=6)
        self.app = app
        self._photo = None
        self._thumb_key: Optional[str] = None

        ttk.Label(self, text="Ресурсы проекта",
                  style="Section.TLabel").pack(anchor="w")
        ttk.Label(self, text="Всё, что упаковано внутрь .tbwf: фон, цифры, иконки, шрифты.",
                  style="Hint.TLabel", wraplength=330, justify="left").pack(anchor="w",
                                                                           pady=(0, 6))

        holder = ttk.Frame(self)
        holder.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(holder, columns=("kind", "size", "used"),
                                 show="tree headings", height=12)
        self.tree.heading("#0", text="Путь ресурса")
        self.tree.heading("kind", text="Тип")
        self.tree.heading("size", text="Размер")
        self.tree.heading("used", text="Слоёв")
        self.tree.column("#0", width=170, stretch=True)
        self.tree.column("kind", width=90, stretch=False)
        self.tree.column("size", width=64, anchor="e", stretch=False)
        self.tree.column("used", width=48, anchor="center", stretch=False)
        vs = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        vs.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Double-1>", self._on_double)

        # --------------------------------------------------------- превью
        pv = ttk.LabelFrame(self, text="Превью", padding=4)
        pv.pack(fill="x", pady=(6, 4))
        self.lbl_preview = ttk.Label(pv, text="Выберите ресурс", anchor="center")
        self.lbl_preview.pack(fill="both", expand=True, ipady=6)
        self.lbl_info = ttk.Label(pv, text="", style="Hint.TLabel",
                                  wraplength=330, justify="left")
        self.lbl_info.pack(anchor="w")

        # --------------------------------------------------------- кнопки
        row = ttk.Frame(self)
        row.pack(fill="x", pady=(2, 0))
        ttk.Button(row, text="Импорт PNG…", command=self.import_png).pack(side="left")
        ttk.Button(row, text="Извлечь…", command=self.extract_one).pack(side="left", padx=4)
        ttk.Button(row, text="Переименовать…", command=self.rename_one).pack(side="left")
        row2 = ttk.Frame(self)
        row2.pack(fill="x", pady=(4, 0))
        ttk.Button(row2, text="Удалить…", command=self.delete_one).pack(side="left")
        ttk.Button(row2, text="Удалить неиспользуемые",
                   command=self.clean_unused).pack(side="left", padx=4)
        ttk.Button(row2, text="Обновить", command=self.refresh).pack(side="left")

    # ================================================================ список
    def refresh(self) -> None:
        """Перестроить таблицу ресурсов."""
        if not self.winfo_exists():
            return
        selection = self._selected_key()
        for item in self.tree.get_children(""):
            self.tree.delete(item)

        usage = self._usage_map()
        self.app.resources = dict(self.app.resources or {})
        total = 0
        for key in sorted(self.app.resources.keys()):
            data = self.app.resources.get(key) or b""
            size = len(data)
            total += size
            used = usage.get(key, 0)
            self.tree.insert("", "end", iid=key, text=key,
                             values=(_kind_of(key), _human_size(size),
                                     used if used else "—"))
        if not self.app.resources:
            self.lbl_info.configure(text="Ресурсов нет.")
        else:
            self.lbl_info.configure(
                text="Всего: %d шт., %s" % (len(self.app.resources), _human_size(total)))
        if selection and self.tree.exists(selection):
            self.tree.selection_set(selection)
            self.tree.see(selection)
        self._refresh_preview()

    def _usage_map(self) -> Dict[str, int]:
        """Сколько слоёв ссылается на каждый ресурс."""
        usage: Dict[str, int] = {}
        doc = self.app.doc
        if doc is None:
            return usage
        for el in doc.all_elements():
            res = el.get_resource()
            if not res:
                continue
            key = res if res in self.app.resources else None
            if key is None:
                # ссылка может вести на папку — ищем по префиксу
                for k in self.app.resources:
                    if res and k.startswith(res):
                        usage[k] = usage.get(k, 0) + 1
                continue
            usage[key] = usage.get(key, 0) + 1
        return usage

    def _selected_key(self) -> Optional[str]:
        sel = self.tree.selection()
        return sel[0] if sel else None

    def _on_select(self, _event=None) -> None:
        self._refresh_preview()

    def _on_double(self, _event=None) -> None:
        """Двойной клик — выделить первый слой, использующий ресурс."""
        key = self._selected_key()
        doc = self.app.doc
        if not key or doc is None:
            return
        for el in doc.all_elements():
            res = el.get_resource()
            if res and (res == key or key.startswith(res)):
                self.app.select(el.name)
                self.app.note("Слой «%s» использует %s" % (el.name, key))
                return
        self.app.note("На этот ресурс пока не ссылается ни один слой")

    # --------------------------------------------------------------- превью
    def _refresh_preview(self) -> None:
        key = self._selected_key()
        if not key:
            self.lbl_preview.configure(image="", text="Выберите ресурс")
            self._photo = None
            return
        data = self.app.resources.get(key) or b""
        usage = self._usage_map().get(key, 0)
        self.lbl_info.configure(text="%s\n%s, ссылок: %d"
                                     % (key, _human_size(len(data)),
                                        usage))
        if not HAS_PIL:
            self.lbl_preview.configure(image="", text="Превью недоступно (нет Pillow)")
            return
        if self._thumb_key == key and self._photo is not None:
            return
        try:
            image = Image.open(io.BytesIO(data))
            image.load()
            preview = image.convert("RGBA")
            preview.thumbnail((220, 220))
            self._photo = ImageTk.PhotoImage(preview)
            self.lbl_preview.configure(image=self._photo, text="")
            self._thumb_key = key
        except Exception as exc:                  # noqa: BLE001
            self._photo = None
            self._thumb_key = None
            self.lbl_preview.configure(image="",
                                       text="Не картинка (%s)" % type(exc).__name__)

    # ================================================================ действия
    def import_png(self) -> None:
        """Импорт одного или нескольких PNG в ресурсы."""
        paths = filedialog.askopenfilenames(
            title="Импорт изображений в ресурсы",
            filetypes=[("PNG", "*.png"), ("Все файлы", "*.*")])
        if not paths:
            return
        added: List[str] = []
        replaced = 0
        for path in paths:
            try:
                with open(path, "rb") as fh:
                    data = fh.read()
            except OSError as exc:
                messagebox.showerror("Импорт", "Не удалось прочитать %s:\n%s" % (path, exc))
                continue
            key = constants.RES_IMAGE_DIR.lstrip("/") + os.path.basename(path)
            if key in self.app.resources:
                replaced += 1
            self.app.resources[key] = data
            added.append(key)
        if not added:
            return
        self.app.store.set_all(self.app.resources)
        self.app.push_history("Импорт ресурсов: %d" % len(added))
        self.app.after_change()
        self.refresh()
        self.app.note("Импортировано %d файл(ов)%s"
                      % (len(added), ", заменено %d" % replaced if replaced else ""))

    def extract_one(self) -> None:
        """Сохранить выбранный ресурс наружу отдельным файлом."""
        key = self._selected_key()
        if not key:
            self.app.note("Сначала выберите ресурс", error=True)
            return
        data = self.app.resources.get(key) or b""
        name = os.path.basename(key.rstrip("/")) or "resource.png"
        target = filedialog.asksaveasfilename(title="Сохранить ресурс как…",
                                              initialfile=name,
                                              defaultextension=".png",
                                              filetypes=[("PNG", "*.png"),
                                                         ("Все файлы", "*.*")])
        if not target:
            return
        try:
            with open(target, "wb") as fh:
                fh.write(data)
        except OSError as exc:
            messagebox.showerror("Извлечь", "Не удалось записать:\n%s" % exc)
            return
        self.app.note("Ресурс сохранён: %s" % target)

    def rename_one(self) -> None:
        """Переименовать путь ресурса (все ссылки слоёв обновляются)."""
        key = self._selected_key()
        if not key:
            self.app.note("Сначала выберите ресурс", error=True)
            return
        win = tk.Toplevel(self)
        win.title("Переименовать ресурс")
        win.transient(self.winfo_toplevel())
        win.grab_set()
        ttk.Label(win, text="Новый путь в документе:").pack(anchor="w", padx=10, pady=(10, 2))
        var = tk.StringVar(value=key)
        entry = ttk.Entry(win, textvariable=var, width=52)
        entry.pack(padx=10, fill="x")
        entry.focus_set()

        def _apply() -> None:
            new = var.get().strip()
            if not new or new == key:
                win.destroy()
                return
            new = new.replace("\\", "/").strip().lstrip("/")
            if "/" not in new:
                new = constants.RES_IMAGE_DIR.lstrip("/") + new
            if new in self.app.resources:
                messagebox.showwarning("Переименовать",
                                       "Такой ресурс уже есть в документе.",
                                       parent=win)
                return
            data = self.app.resources.pop(key)
            self.app.resources[new] = data
            doc = self.app.doc
            changed = 0
            if doc is not None:
                for el in doc.all_elements():
                    res = el.get_resource()
                    if not res:
                        continue
                    if res == key:
                        self._set_resource(el, new)
                        changed += 1
                    elif res.endswith("/") and key.startswith(res):
                        self._set_resource(el, new[:new.rfind("/") + 1])
                        changed += 1
            self.app.store.set_all(self.app.resources)
            self.app.push_history("Переименование ресурса")
            self.app.after_change()
            win.destroy()
            self.refresh()
            self.app.note("Ресурс переименован, обновлено слоёв: %d" % changed)

        ttk.Button(win, text="Переименовать", command=_apply).pack(pady=10)

    def _set_resource(self, element, value: str) -> None:
        """Записать путь ресурса в слой, не ломая остальные ключи payload."""
        if element.kind == "font":
            element.payload["family"] = value
        else:
            element.payload["resource"] = value

    def delete_one(self) -> None:
        """Удалить ресурс из документа (с предупреждением о ссылках)."""
        key = self._selected_key()
        if not key:
            self.app.note("Сначала выберите ресурс", error=True)
            return
        used = self._usage_map().get(key, 0)
        text = "Удалить ресурс из документа?\n\n%s" % key
        if used:
            text += "\n\nНа него ссылается слоёв: %d. Они станут пустыми." % used
        if not messagebox.askyesno("Удаление ресурса", text):
            return
        self.app.resources.pop(key, None)
        self.app.store.set_all(self.app.resources)
        self.app.push_history("Удалён ресурс %s" % key)
        self.app.after_change()
        self.refresh()
        self.app.note("Ресурс удалён из документа: %s" % key)

    def clean_unused(self) -> None:
        """Удалить все ресурсы, на которые нет ссылок."""
        usage = self._usage_map()
        unused = [key for key in self.app.resources if usage.get(key, 0) == 0]
        if not unused:
            self.app.note("Неиспользуемых ресурсов нет")
            return
        preview = "\n".join(unused[:12])
        if len(unused) > 12:
            preview += "\n… ещё %d" % (len(unused) - 12)
        if not messagebox.askyesno("Чистка ресурсов",
                                   "Удалить неиспользуемые ресурсы (%d шт.)?\n\n%s"
                                   % (len(unused), preview)):
            return
        for key in unused:
            self.app.resources.pop(key, None)
        self.app.store.set_all(self.app.resources)
        self.app.push_history("Удалено неиспользуемых ресурсов: %d" % len(unused))
        self.app.after_change()
        self.refresh()
        self.app.note("Удалено неиспользуемых ресурсов: %d" % len(unused))
