# -*- coding: utf-8 -*-
"""Панель «Данные»: симуляция показаний часов.

Все поля панели пишут прямо в app.sim (SimState), после чего превью
перерисовывается. Это позволяет проверить, как циферблат выглядит при
низком заряде, при морозе, ночью, без Bluetooth и т. п. — без самих часов.
"""

from __future__ import annotations

import datetime as _dt
import tkinter as tk
from tkinter import ttk

from .. import conditions
from .widgets import ScrollFrame, Section, row_entry, row_scale


class SimPanel(ttk.Frame):
    """Поля симуляции: время, шаги, пульс, батарея, погода, флаги."""

    def __init__(self, master, app) -> None:
        super().__init__(master, padding=2)
        self.app = app
        self._guard = False

        self.scroll = ScrollFrame(self)
        self.scroll.pack(fill="both", expand=True)
        body = self.scroll.inner

        # ------------------------------------------------------------- время
        sec_time = Section(body, "Время и дата")
        sec_time.pack(fill="x", pady=(0, 6), padx=4)
        b = sec_time.body
        self.lbl_now = ttk.Label(b, text="—", style="Hint.TLabel")
        self.lbl_now.grid(row=0, column=0, columnspan=3, sticky="w")
        self.var_hour = tk.IntVar(value=10)
        self.var_minute = tk.IntVar(value=10)
        self.var_second = tk.IntVar(value=0)
        row_scale(b, 1, "Часы", self.var_hour, 0, 23,
                  command=self._on_time).grid_configure(sticky="ew")
        row_scale(b, 2, "Минуты", self.var_minute, 0, 59,
                  command=self._on_time).grid_configure(sticky="ew")
        row_scale(b, 3, "Секунды", self.var_second, 0, 59,
                  command=self._on_time).grid_configure(sticky="ew")
        # ползунки целочисленных значений округляем вручную
        for var in (self.var_hour, self.var_minute, self.var_second):
            var.trace_add("write", lambda *_a: self._round_ints())

        row = ttk.Frame(b)
        row.grid(row=4, column=0, columnspan=3, sticky="w", pady=(4, 0))
        ttk.Button(row, text="Сейчас", command=self._set_now).pack(side="left")
        self.var_live = tk.BooleanVar(value=False)
        ttk.Checkbutton(row, text="Живые часы", variable=self.var_live,
                        command=self._toggle_live).pack(side="left", padx=6)
        ttk.Button(row, text="Демо", command=self.app.random_demo).pack(side="left")
        ttk.Button(row, text="Сброс", command=self.app.reset_sim).pack(side="left", padx=4)

        # ---------------------------------------------------------- активность
        sec_steps = Section(body, "Активность")
        sec_steps.pack(fill="x", pady=(0, 6), padx=4)
        b = sec_steps.body
        self.var_steps = tk.IntVar(value=6420)
        self.var_goal = tk.IntVar(value=10000)
        row_scale(b, 0, "Шаги", self.var_steps, 0, 30000, command=self._on_steps)
        row_entry(b, 1, "Цель шагов", self.var_goal, width=8, command=self._on_steps)
        self.var_calories = tk.IntVar(value=289)
        self.var_distance = tk.DoubleVar(value=4.82)
        row_entry(b, 2, "Калории", self.var_calories, width=8, command=self._on_steps)
        row_entry(b, 3, "Дистанция, км", self.var_distance, width=8, command=self._on_steps)
        self.lbl_progress = ttk.Label(b, text="", style="Hint.TLabel")
        self.lbl_progress.grid(row=4, column=0, columnspan=3, sticky="w")

        # ------------------------------------------------------------- пульс
        sec_heart = Section(body, "Пульс и батарея")
        sec_heart.pack(fill="x", pady=(0, 6), padx=4)
        b = sec_heart.body
        self.var_heart = tk.IntVar(value=72)
        row_scale(b, 0, "Пульс", self.var_heart, 40, 200, command=self._on_heart)
        self.var_battery = tk.IntVar(value=76)
        row_scale(b, 1, "Батарея, %", self.var_battery, 0, 100,
                  command=self._on_battery)
        self.var_charging = tk.BooleanVar(value=False)
        ttk.Checkbutton(b, text="На зарядке", variable=self.var_charging,
                        command=self._on_flags).grid(row=2, column=0, columnspan=3,
                                                    sticky="w", pady=(2, 0))
        self.lbl_battery = ttk.Label(b, text="", style="Hint.TLabel")
        self.lbl_battery.grid(row=3, column=0, columnspan=3, sticky="w")

        # ------------------------------------------------------------- погода
        sec_weather = Section(body, "Погода и связь")
        sec_weather.pack(fill="x", pady=(0, 6), padx=4)
        b = sec_weather.body
        self._weather_items = conditions.WEATHER_STATES
        self._weather_labels = conditions.pretty_weather_list()
        self.var_weather = tk.StringVar(value=self._weather_labels[2])
        ttk.Label(b, text="Состояние погоды:").grid(row=0, column=0, columnspan=3,
                                                   sticky="w")
        cb = ttk.Combobox(b, textvariable=self.var_weather, state="readonly",
                          values=self._weather_labels)
        cb.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(0, 4))
        cb.bind("<<ComboboxSelected>>", lambda e: self._on_weather())

        self.var_connected = tk.BooleanVar(value=True)
        ttk.Checkbutton(b, text="Связь с телефоном (Bluetooth)", variable=self.var_connected,
                        command=self._on_flags).grid(row=2, column=0, columnspan=3,
                                                    sticky="w")
        self.var_night = tk.BooleanVar(value=False)
        ttk.Checkbutton(b, text="Ночной режим", variable=self.var_night,
                        command=self._on_flags).grid(row=3, column=0, columnspan=3,
                                                    sticky="w")
        self.var_lang = tk.StringVar(value="ru")
        ttk.Label(b, text="Язык дня недели:").grid(row=4, column=0, columnspan=3,
                                                  sticky="w", pady=(4, 0))
        cb2 = ttk.Combobox(b, textvariable=self.var_lang, state="readonly",
                           values=["ru", "en", "de", "es", "fr", "it", "pl", "tr", "uk"])
        cb2.grid(row=5, column=0, columnspan=3, sticky="ew")
        cb2.bind("<<ComboboxSelected>>", lambda e: self._on_flags())

        ttk.Label(body, text="Значения только для превью: в файл .tbwf они не пишутся.",
                  style="Hint.TLabel", wraplength=330, justify="left").pack(
            anchor="w", padx=8, pady=(0, 8))

        self.refresh()

    # ================================================================ servants
    def refresh(self) -> None:
        """Перечитать app.sim в поля панели (без обратной записи)."""
        sim = self.app.sim
        self._guard = True
        try:
            now = sim.time or _dt.datetime.now()
            self.lbl_now.configure(text="В симуляции: %s"
                                   % now.strftime("%d.%m.%Y %H:%M:%S"))
            self.var_hour.set(int(now.hour))
            self.var_minute.set(int(now.minute))
            self.var_second.set(int(now.second))

            self.var_steps.set(int(sim.steps))
            self.var_goal.set(int(sim.steps_goal))
            self.var_calories.set(int(sim.calories))
            self.var_distance.set(round(float(sim.distance), 2))
            self.var_heart.set(int(sim.heart))
            self.var_battery.set(int(sim.battery))
            self.var_charging.set(bool(sim.charging))
            self.var_connected.set(bool(sim.connected))
            self.var_night.set(bool(sim.is_night))
            self.var_lang.set(str(sim.weekday_language or "ru"))
            self.var_live.set(bool(self.app.live_clock))

            index = int(sim.weather) if 0 <= int(sim.weather) < len(self._weather_labels) else 0
            self.var_weather.set(self._weather_labels[index])
            self._update_hints()
        finally:
            self._guard = False

    def _update_hints(self) -> None:
        """Подписи-подсказки под полями."""
        sim = self.app.sim
        goal = max(1, int(sim.steps_goal))
        pct = min(100.0, 100.0 * sim.steps / goal)
        self.lbl_progress.configure(text="Прогресс: %d%% от цели" % round(pct))
        batt = int(sim.battery)
        state = "заряжается" if sim.charging else ("разряжена" if batt <= 5 else "разряд")
        self.lbl_battery.configure(text="Батарея: %d%% (%s)" % (batt, state))
        try:
            now = sim.time or _dt.datetime.now()
            self.lbl_now.configure(text="В симуляции: %s"
                                   % now.strftime("%d.%m.%Y %H:%M:%S"))
        except (tk.TclError, AttributeError):
            pass

    # ================================================================ события
    def _round_ints(self) -> None:
        """Ползунки дают float — округляем часы/минуты/секунды."""
        if self._guard:
            return
        for var, top in ((self.var_hour, 23), (self.var_minute, 59),
                         (self.var_second, 59)):
            try:
                value = int(round(float(var.get())))
            except (tk.TclError, ValueError):
                continue
            value = min(top, max(0, value))
            if value != var.get():
                self._guard = True
                try:
                    var.set(value)
                finally:
                    self._guard = False

    def _apply(self) -> None:
        """Общая точка: перерисовать превью и обновить подсказки."""
        self._update_hints()
        self.app.canvas_view.schedule(10)

    def _on_time(self) -> None:
        if self._guard:
            return
        sim = self.app.sim
        base = sim.time or _dt.datetime.now()
        try:
            sim.time = base.replace(hour=int(round(self.var_hour.get())) % 24,
                                    minute=int(round(self.var_minute.get())) % 60,
                                    second=int(round(self.var_second.get())) % 60)
        except (tk.TclError, ValueError):
            return
        self._apply()

    def _set_now(self) -> None:
        self.app.sim.time = _dt.datetime.now()
        self.refresh()
        self._apply()
        self.app.note("Время симуляции = системное")

    def _toggle_live(self) -> None:
        self.app.live_clock = bool(self.var_live.get())
        self.app.note("Живые часы: %s" % ("включены" if self.app.live_clock else "выключены"))

    def _on_steps(self) -> None:
        if self._guard:
            return
        sim = self.app.sim
        try:
            sim.steps = max(0, int(float(self.var_steps.get())))
            sim.steps_goal = max(1, int(float(self.var_goal.get())))
            sim.calories = max(0, int(float(self.var_calories.get())))
            sim.distance = max(0.0, round(float(self.var_distance.get()), 2))
        except (tk.TclError, ValueError):
            self.app.note("Шаги/калории — целые, дистанция — число", error=True)
            return
        self._apply()

    def _on_heart(self) -> None:
        if self._guard:
            return
        try:
            self.app.sim.heart = max(30, min(220, int(round(self.var_heart.get()))))
        except (tk.TclError, ValueError):
            return
        self._apply()

    def _on_battery(self) -> None:
        if self._guard:
            return
        try:
            self.app.sim.battery = max(0, min(100, int(round(self.var_battery.get()))))
        except (tk.TclError, ValueError):
            return
        self._apply()

    def _on_weather(self) -> None:
        if self._guard:
            return
        label = self.var_weather.get()
        try:
            index = self._weather_labels.index(label)
        except ValueError:
            index = 0
        self.app.sim.weather = int(index)
        self._apply()

    def _on_flags(self) -> None:
        if self._guard:
            return
        sim = self.app.sim
        sim.charging = bool(self.var_charging.get())
        sim.connected = bool(self.var_connected.get())
        sim.is_night = bool(self.var_night.get())
        sim.weekday_language = self.var_lang.get() or "ru"
        self._apply()
