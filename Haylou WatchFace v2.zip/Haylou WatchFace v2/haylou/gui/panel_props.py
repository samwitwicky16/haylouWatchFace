# -*- coding: utf-8 -*-
"""Панель «Свойства»: редактирование выбранного слоя.

Панель перестраивается целиком при смене слоя (rebuild) и умеет тихо
обновлять только геометрию во время перетаскивания на канве (sync_geometry),
чтобы не терять фокус в полях ввода.

Любая правка проходит три шага: значение → модель → история/перерисовка.
Неизвестные ключи payload сохраняются как есть — панель их не удаляет.
"""

from __future__ import annotations

import os
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from typing import List, Optional

from .. import catalog, colors, conditions, constants, model
from .widgets import ScrollFrame, Section, Swatch, row_entry, row_scale

KIND_LABELS = [
    ("font", "font — текст/шрифт"),
    ("resourceCharacter", "resourceCharacter — картинки/цифры"),
    ("resourceIcon", "resourceIcon — иконки"),
    ("resourceImage", "resourceImage — изображения"),
    ("none", "none — пустой слой"),
]


def _argb_to_hex(value: int) -> str:
    """int32 ARGB → '#rrggbb' (для диалога цвета)."""
    try:
        return colors.argb_to_hex(int(value))
    except Exception:                                  # noqa: BLE001
        return "#FFFFFF"


def _hex_to_argb(hex_color: str) -> int:
    """'#rrggbb' → int32 ARGB (альфа 255)."""
    try:
        return int(colors.hex_to_argb(hex_color))
    except Exception:                                  # noqa: BLE001
        return -1


class PropsPanel(ttk.Frame):
    """Свойства выбранного слоя."""

    def __init__(self, master, app) -> None:
        super().__init__(master, padding=2)
        self.app = app
        self.el: Optional[model.DialElement] = None
        self.scroll = ScrollFrame(self)
        self.scroll.pack(fill="both", expand=True)
        self.body = self.scroll.inner

        # переменные геометрии живут постоянно — их обновляет sync_geometry
        self.var_x = tk.DoubleVar(value=0.5)
        self.var_y = tk.DoubleVar(value=0.5)
        self.var_size = tk.DoubleVar(value=0.1)
        self._geom_guard = False
        self._placeholder = None

        self.rebuild()

    # =============================================================== построение
    def rebuild(self) -> None:
        """Полностью перестроить панель под текущий выбранный слой."""
        for child in self.body.winfo_children():
            child.destroy()
        self.el = None

        doc = self.app.doc
        name = self.app.selected
        if doc is None or not name or name not in doc.elements:
            self._build_empty("Слой не выбран", "Выберите слой в списке «Слои»"
                              " или на превью слева.")
            return
        el = doc.elements[name]
        self.el = el

        self._build_header(el)
        self._build_geometry(el)
        self._build_data(el)
        self._build_color(el)
        self._build_resource(el)
        self._build_conditions(el)
        self._build_note(el)

    def _build_empty(self, title: str, hint: str) -> None:
        sec = Section(self.body, title)
        sec.pack(fill="x", pady=(0, 6), padx=4)
        ttk.Label(sec.body, text=hint, style="Hint.TLabel",
                  wraplength=320, justify="left").pack(anchor="w", pady=4)

    # ------------------------------------------------------------- заголовок
    def _build_header(self, el: model.DialElement) -> None:
        sec = Section(self.body, "Слой")
        sec.pack(fill="x", pady=(0, 6), padx=4)
        b = sec.body

        ttk.Label(b, text="Имя (ключ в JSON):", style="Hint.TLabel").pack(anchor="w")
        row = ttk.Frame(b)
        row.pack(fill="x", pady=(0, 4))
        ttk.Entry(row, state="readonly",
                  textvariable=tk.StringVar(value=el.name)).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="…", width=3,
                   command=self.app.rename_selected).pack(side="left", padx=(4, 0))

        ttk.Label(b, text="Описание: %s" % self._describe(el.name),
                  style="Hint.TLabel", wraplength=330, justify="left").pack(anchor="w", pady=(0, 6))

        ttk.Label(b, text="Тип элемента (ключ ресурса):").pack(anchor="w")
        cur = el.kind or "none"
        labels = [lab for _k, lab in KIND_LABELS]
        keys = [k for k, _lab in KIND_LABELS]
        self.var_kind = tk.StringVar(
            value=labels[keys.index(cur)] if cur in keys else "none — пустой слой")
        cb = ttk.Combobox(b, textvariable=self.var_kind, values=labels, state="readonly")
        cb.pack(fill="x", pady=(0, 4))
        cb.bind("<<ComboboxSelected>>", lambda e: self._change_kind(keys, cb))

        self.var_visible = tk.BooleanVar(value=bool(el.visible))
        ttk.Checkbutton(b, text="Слой видим", variable=self.var_visible,
                        command=self._toggle_visible).pack(anchor="w", pady=(2, 0))

    def _describe(self, name: str) -> str:
        """Русское имя + роль данных (если каталогу известен элемент)."""
        ru = self.app.ru_name(name)
        if not catalog.is_known(name):
            return "%s (не из каталога — свободное имя)" % ru
        try:
            role = catalog.role_label(catalog.data_role(name))
        except Exception:                              # noqa: BLE001
            role = ""
        return "%s — %s" % (ru, role) if role else ru

    def _change_kind(self, keys: List[str], cb: ttk.Combobox) -> None:
        if self.el is None:
            return
        label = self.var_kind.get()
        try:
            kind = keys[[lab for _k, lab in KIND_LABELS].index(label)]
        except ValueError:
            return
        if kind == self.el.kind:
            return
        if kind != "none" and not isinstance(self.el.payload, dict):
            self.el.payload = {}
        self.el.kind = kind
        self.app.push_history("Тип слоя «%s» → %s" % (self.el.name, kind))
        self.app.after_change()
        self.rebuild()

    def _toggle_visible(self) -> None:
        if self.el is None:
            return
        self.el.visible = bool(self.var_visible.get())
        self.app.push_history("Видимость «%s»" % self.el.name)
        self.app.after_change()

    # ------------------------------------------------------------- геометрия
    def _build_geometry(self, el: model.DialElement) -> None:
        sec = Section(self.body, "Положение и размер")
        sec.pack(fill="x", pady=(0, 6), padx=4)
        b = sec.body

        self._geom_guard = True
        try:
            self.var_x.set(float(el.x if el.x is not None else 0.5))
            self.var_y.set(float(el.y if el.y is not None else 0.5))
            self.var_size.set(float(el.get_size() or 0.10))
        finally:
            self._geom_guard = False

        self.ent_x = row_entry(b, 0, "X (0…1)", self.var_x, width=10,
                               command=self._commit_geometry)
        self.ent_y = row_entry(b, 1, "Y (0…1)", self.var_y, width=10,
                               command=self._commit_geometry)
        self.lbl_px = ttk.Label(b, text="", style="Hint.TLabel")
        self.lbl_px.grid(row=2, column=0, columnspan=3, sticky="w", pady=(0, 2))

        ttk.Scale(b, from_=0.0, to=1.0, variable=self.var_x, orient="horizontal",
                  command=lambda v: self._on_scale("x", v)).grid(
            row=3, column=0, columnspan=3, sticky="ew", pady=(0, 2))
        ttk.Scale(b, from_=0.0, to=1.0, variable=self.var_y, orient="horizontal",
                  command=lambda v: self._on_scale("y", v)).grid(
            row=4, column=0, columnspan=3, sticky="ew", pady=(0, 2))

        self.var_size_pct = tk.DoubleVar(value=round(self.var_size.get() * 100, 1))
        self.ent_size = row_entry(b, 5, "Размер, %", self.var_size_pct, width=10,
                                  command=self._commit_geometry)
        ttk.Scale(b, from_=0.5, to=100.0, variable=self.var_size_pct,
                  orient="horizontal",
                  command=lambda v: self._on_scale("size", v)).grid(
            row=6, column=0, columnspan=3, sticky="ew", pady=(0, 2))
        self._update_px_label()

        # размеры фона (dial) — width/height в пикселях
        if "width" in el.payload or "height" in el.payload or el.name == "dial":
            self.var_w = tk.StringVar(value=str(el.payload.get("width", constants.SCREEN_W)))
            self.var_h = tk.StringVar(value=str(el.payload.get("height", constants.SCREEN_H)))
            row_entry(b, 7, "Ширина, px", self.var_w, width=10,
                      command=self._commit_dial_size)
            row_entry(b, 8, "Высота, px", self.var_h, width=10,
                      command=self._commit_dial_size)
            ttk.Button(b, text="Сбросить на 410×502",
                       command=self._reset_dial_size).grid(row=9, column=0, columnspan=3,
                                                          sticky="w", pady=(2, 0))

    def _update_px_label(self) -> None:
        if self.el is None:
            return
        size = float(self.var_size.get() or 0.0)
        self.lbl_px.configure(text="≈ %.1f px по ширине экрана (410 px)"
                                   % (size * constants.SCREEN_W))

    def _on_scale(self, field: str, value) -> None:
        if self._geom_guard or self.el is None:
            return
        try:
            val = float(value)
        except (TypeError, ValueError):
            return
        if field == "x":
            self.el.x = min(1.0, max(0.0, val))
        elif field == "y":
            self.el.y = min(1.0, max(0.0, val))
        else:
            self.el.set_size(max(0.001, val / 100.0))
            self._update_px_label()
        self.app.on_geometry_drag(self.el)
        self.app.canvas_view.schedule(10)

    def _commit_geometry(self, *_args) -> None:
        """Ввод с клавиатуры: применить значения и зафиксировать в истории."""
        if self.el is None:
            return
        try:
            self.el.x = min(1.0, max(0.0, float(self.var_x.get())))
            self.el.y = min(1.0, max(0.0, float(self.var_y.get())))
            pct = float(self.var_size_pct.get())
            self.el.set_size(max(0.001, pct / 100.0))
        except (tk.TclError, TypeError, ValueError):
            self.app.note("Нужны числа: X/Y от 0 до 1, размер в процентах", error=True)
            return
        self._update_px_label()
        self.app.push_history("Геометрия «%s»" % self.el.name)
        self.app.after_change()
        self.sync_geometry()

    def _commit_dial_size(self, *_args) -> None:
        if self.el is None:
            return
        try:
            w = int(float(self.var_w.get()))
            h = int(float(self.var_h.get()))
        except (tk.TclError, TypeError, ValueError):
            self.app.note("Ширина и высота — целые числа", error=True)
            return
        if w < 8 or h < 8:
            self.app.note("Слишком маленький фон", error=True)
            return
        self.el.payload["width"] = w
        self.el.payload["height"] = h
        self.app.push_history("Размер фона «%s»" % self.el.name)
        self.app.after_change()

    def _reset_dial_size(self) -> None:
        if self.el is None:
            return
        self.var_w.set(str(constants.SCREEN_W))
        self.var_h.set(str(constants.SCREEN_H))
        self._commit_dial_size()

    def sync_geometry(self) -> None:
        """Тихо обновить числа после перетаскивания на канве."""
        if self.el is None:
            return
        self._geom_guard = True
        try:
            self.var_x.set(round(float(self.el.x if self.el.x is not None else 0.5), 4))
            self.var_y.set(round(float(self.el.y if self.el.y is not None else 0.5), 4))
            size = float(self.el.get_size() or 0.10)
            self.var_size.set(round(size, 4))
            self.var_size_pct.set(round(size * 100, 1))
        except (tk.TclError, TypeError, ValueError):
            pass
        finally:
            self._geom_guard = False
        self._update_px_label()

    # ------------------------------------------------------------- данные
    def _build_data(self, el: model.DialElement) -> None:
        sec = Section(self.body, "Данные (properties / sections)")
        sec.pack(fill="x", pady=(0, 6), padx=4)
        b = sec.body

        typical = catalog.typical_properties(el.name)
        cur = "" if el.properties is None else str(el.properties)
        self.var_props = tk.StringVar(value=cur)
        self.ent_props = row_entry(b, 0, "properties", self.var_props, width=10,
                                   command=self._commit_props)
        hint = "типовое: %s" % (", ".join(str(p) for p in typical) if typical else "нет данных")
        ttk.Label(b, text=hint, style="Hint.TLabel").grid(row=1, column=0, columnspan=3,
                                                          sticky="w")
        self.lbl_props_warn = ttk.Label(b, text="", style="Hint.TLabel",
                                        wraplength=330, justify="left",
                                        foreground="#b00020")
        self.lbl_props_warn.grid(row=2, column=0, columnspan=3, sticky="w")
        self._check_props()

        sec_types = catalog.typical_sections(el.name)
        vals = sorted(set(list(sec_types) + [1, 2, 5, 7, 11, 14, 16, 24]))
        self.var_sections = tk.StringVar(value=str(el.get_sections()))
        ttk.Label(b, text="sections (кадров в полосе)").grid(row=3, column=0, columnspan=3,
                                                             sticky="w", pady=(6, 0))
        cb = ttk.Combobox(b, textvariable=self.var_sections,
                          values=[str(v) for v in vals])
        cb.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(0, 2))
        cb.bind("<<ComboboxSelected>>", lambda e: self._commit_sections())
        cb.bind("<Return>", lambda e: self._commit_sections())
        cb.bind("<FocusOut>", lambda e: self._commit_sections())
        sec_hint = "типовое: %s" % (", ".join(str(s) for s in sec_types) if sec_types else "—")
        ttk.Label(b, text=sec_hint + "; наблюдались 1,2,5,7,11,14,16",
                  style="Hint.TLabel", wraplength=330,
                  justify="left").grid(row=5, column=0, columnspan=3, sticky="w")

        # кнопка быстрого «типового» заполнения
        ttk.Button(b, text="Подставить типовые значения",
                   command=self._apply_typical).grid(row=6, column=0, columnspan=3,
                                                     sticky="w", pady=(4, 0))

    def _check_props(self) -> None:
        text = ""
        raw = self.var_props.get().strip()
        if raw:
            try:
                value = int(float(raw))
            except ValueError:
                text = "properties должно быть целым числом"
            else:
                if value not in constants.OBSERVED_PROPERTIES:
                    near = min(constants.OBSERVED_PROPERTIES, key=lambda v: abs(v - value))
                    text = ("В образцах RS5 значение %d не встречалось (ближайшее %d). "
                            "Часы могут проигнорировать слой." % (value, near))
        try:
            self.lbl_props_warn.configure(text=text)
        except tk.TclError:
            pass

    def _commit_props(self, *_args) -> None:
        if self.el is None:
            return
        raw = self.var_props.get().strip()
        if not raw:
            self.el.properties = None
            self.app.push_history("properties «%s»" % self.el.name)
            self.app.after_change()
            self._check_props()
            return
        try:
            value = int(float(raw))
        except ValueError:
            self.app.note("properties — целое число", error=True)
            self._check_props()
            return
        self.el.properties = value
        self.app.push_history("properties «%s» = %d" % (self.el.name, value))
        self.app.after_change()
        self._check_props()

    def _commit_sections(self) -> None:
        if self.el is None:
            return
        try:
            value = int(float(self.var_sections.get()))
        except (TypeError, ValueError):
            self.app.note("sections — целое число", error=True)
            return
        if value < 1:
            value = 1
        if value == self.el.get_sections():
            return
        self.el.set_sections(value)
        self.app.push_history("sections «%s» = %d" % (self.el.name, value))
        self.app.after_change()

    def _apply_typical(self) -> None:
        if self.el is None:
            return
        props = catalog.typical_properties(self.el.name)
        if props:
            self.el.properties = int(props[0])
            self.var_props.set(str(props[0]))
        secs = catalog.typical_sections(self.el.name)
        if secs:
            self.el.set_sections(int(secs[0]))
            self.var_sections.set(str(secs[0]))
        self.app.push_history("Типовые значения «%s»" % self.el.name)
        self.app.after_change()
        self._check_props()

    # ------------------------------------------------------------- цвет
    def _build_color(self, el: model.DialElement) -> None:
        sec = Section(self.body, "Цвет и градиент")
        sec.pack(fill="x", pady=(0, 6), padx=4)
        b = sec.body

        cols = el.get_colors()
        if not cols and el.kind in ("font", "resourceCharacter", "resourceIcon"):
            cols = [-1]
        self.var_gradient = tk.StringVar(value=el.get_gradient() or "solid")
        ttk.Label(b, text="Градиент:").grid(row=0, column=0, sticky="w")
        cb = ttk.Combobox(b, textvariable=self.var_gradient, state="readonly",
                          values=list(constants.GRADIENT_KINDS))
        cb.grid(row=0, column=1, columnspan=2, sticky="ew", pady=(0, 4))
        cb.bind("<<ComboboxSelected>>", lambda e: self._change_gradient())

        row = ttk.Frame(b)
        row.grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 2))
        ttk.Label(row, text="Цвета:").pack(side="left", padx=(0, 6))
        for index, value in enumerate(cols):
            sw = Swatch(row, hex_color=_argb_to_hex(value), size=24,
                        on_click=lambda i=index: self._pick_color(i))
            sw.pack(side="left", padx=2)
        ttk.Button(row, text="+", width=2,
                   command=self._add_color).pack(side="left", padx=(6, 0))
        ttk.Button(row, text="−", width=2,
                   command=self._remove_color).pack(side="left", padx=2)

        raw = ", ".join(str(int(c)) for c in cols) if cols else "—"
        ttk.Label(b, text="int32: %s" % raw, style="Hint.TLabel",
                  wraplength=330, justify="left").grid(row=2, column=0, columnspan=3,
                                                       sticky="w")

        self.var_color_text = tk.StringVar(value=raw.replace("—", ""))
        row_entry(b, 3, "Цвета (int32)", self.var_color_text, width=18,
                  command=self._commit_colors_text)
        ttk.Label(b, text="-1 = белый, 0 = «не перерисовывать»",
                  style="Hint.TLabel").grid(row=4, column=0, columnspan=3, sticky="w")

    def _change_gradient(self) -> None:
        if self.el is None:
            return
        mode = self.var_gradient.get() or "solid"
        cols = self.el.get_colors() or [-1]
        self.el.set_colors(cols, mode)
        self.app.push_history("Градиент «%s»: %s" % (self.el.name, mode))
        self.app.after_change()
        self.rebuild()

    def _pick_color(self, index: int) -> None:
        if self.el is None:
            return
        cols = self.el.get_colors() or [-1]
        if index >= len(cols):
            return
        initial = _argb_to_hex(cols[index])
        _rgb, hex_color = colorchooser.askcolor(color=initial,
                                                title="Цвет слоя «%s»" % self.el.name)
        if not hex_color:
            return
        cols[index] = _hex_to_argb(hex_color)
        self.el.set_colors(cols, self.el.get_gradient() or "solid")
        self.app.push_history("Цвет «%s»" % self.el.name)
        self.app.after_change()
        self.rebuild()

    def _add_color(self) -> None:
        if self.el is None:
            return
        cols = self.el.get_colors() or [-1]
        cols.append(cols[-1])
        self.el.set_colors(cols, "linear_vertical")
        self.var_gradient.set("linear_vertical")
        self.app.push_history("Добавлен цвет «%s»" % self.el.name)
        self.app.after_change()
        self.rebuild()

    def _remove_color(self) -> None:
        if self.el is None:
            return
        cols = self.el.get_colors()
        if len(cols) <= 1:
            return
        cols.pop()
        self.el.set_colors(cols, self.el.get_gradient() or "solid")
        self.app.push_history("Удалён цвет «%s»" % self.el.name)
        self.app.after_change()
        self.rebuild()

    def _commit_colors_text(self, *_args) -> None:
        if self.el is None:
            return
        raw = self.var_color_text.get().replace(";", ",").strip()
        if not raw:
            return
        cols: List[int] = []
        for chunk in raw.split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            try:
                cols.append(int(float(chunk)))
            except ValueError:
                self.app.note("Цвета — целые числа через запятую", error=True)
                return
        if not cols:
            return
        self.el.set_colors(cols, self.el.get_gradient() or "solid")
        self.app.push_history("Цвета «%s»" % self.el.name)
        self.app.after_change()
        self.rebuild()

    # ------------------------------------------------------------- ресурс
    def _build_resource(self, el: model.DialElement) -> None:
        if el.kind not in ("resourceImage", "resourceCharacter", "resourceIcon", "font"):
            return
        sec = Section(self.body, "Ресурс слоя")
        sec.pack(fill="x", pady=(0, 6), padx=4)
        b = sec.body

        caption = "family (шрифт)" if el.kind == "font" else "resource (путь)"
        current = el.get_resource()
        self.var_resource = tk.StringVar(value=current)
        self.ent_resource = row_entry(b, 0, caption, self.var_resource, width=24,
                                      command=self._commit_resource)
        ttk.Label(b, text="Для папки путь заканчивается «/», кадры внутри — по sections",
                  style="Hint.TLabel", wraplength=330,
                  justify="left").grid(row=1, column=0, columnspan=3, sticky="w")

        row = ttk.Frame(b)
        row.grid(row=2, column=0, columnspan=3, sticky="w", pady=(4, 0))
        if el.kind == "font":
            ttk.Label(row, text="Шрифт:").pack(side="left", padx=(0, 4))
            self.var_family = tk.StringVar(value=str(el.payload.get("family")
                                                      or "sans-serif-medium"))
            cb = ttk.Combobox(row, textvariable=self.var_family, width=22,
                              values=["sans-serif-medium", "sans-serif", "sans-serif-light",
                                      "serif", "monospace", "Digits", "Default"])
            cb.pack(side="left")
            cb.bind("<<ComboboxSelected>>", lambda e: self._commit_resource())
            cb.bind("<Return>", lambda e: self._commit_resource())
        else:
            ttk.Button(row, text="Выбрать из ресурсов…",
                       command=self._pick_resource).pack(side="left")
            ttk.Button(row, text="Импорт PNG…",
                       command=self._import_png).pack(side="left", padx=4)

        # картинка, привязанная к официальной иконке
        official = el.extra.get("official_id")
        if official:
            info = catalog.official_icon(str(official)) or {}
            ttk.Label(b, text="Официальная иконка: %s" % info.get("ru", official),
                      style="Hint.TLabel", wraplength=330,
                      justify="left").grid(row=3, column=0, columnspan=3, sticky="w",
                                           pady=(4, 0))

    def _commit_resource(self, *_args) -> None:
        if self.el is None:
            return
        value = self.var_resource.get().strip()
        if self.el.kind == "font":
            family = getattr(self, "var_family", None)
            self.el.payload["family"] = (family.get().strip() if family else "") or "sans-serif-medium"
        else:
            if value and not value.startswith("/"):
                value = "/" + value
                self.var_resource.set(value)
            self.el.payload["resource"] = value
        self.app.push_history("Ресурс «%s»" % self.el.name)
        self.app.after_change()

    def _pick_resource(self) -> None:
        if self.el is None:
            return
        keys = sorted(self.app.resources.keys())
        if not keys:
            messagebox.showinfo("Ресурсы", "В документе пока нет ресурсов. Импортируйте PNG.")
            return
        win = tk.Toplevel(self)
        win.title("Ресурс для слоя «%s»" % self.el.name)
        win.geometry("520x400")
        win.transient(self)
        lb = tk.Listbox(win)
        for key in keys:
            lb.insert("end", key)
        lb.pack(fill="both", expand=True, padx=8, pady=8)

        def _take(_event=None):
            sel = lb.curselection()
            if sel:
                self.var_resource.set(keys[sel[0]])
                win.destroy()
                self._commit_resource()

        lb.bind("<Double-Button-1>", _take)
        ttk.Button(win, text="Выбрать", command=_take).pack(pady=(0, 8))

    def _import_png(self) -> None:
        if self.el is None:
            return
        path = filedialog.askopenfilename(title="Импорт PNG в ресурсы",
                                          filetypes=[("PNG", "*.png"), ("Все файлы", "*.*")])
        if not path:
            return
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        except OSError as exc:
            messagebox.showerror("Импорт", "Не удалось прочитать файл:\n%s" % exc)
            return
        key = constants.RES_IMAGE_DIR.lstrip("/") + os.path.basename(path)
        self.app.resources[key] = data
        self.app.store.set_all(self.app.resources)
        self.var_resource.set(key)
        self._commit_resource()
        self.app.panel_resources.refresh()
        self.app.note("Импортирован ресурс: %s" % key)

    # ------------------------------------------------------------- условия
    def _build_conditions(self, el: model.DialElement) -> None:
        sec = Section(self.body, "Моргание и условия")
        sec.pack(fill="x", pady=(0, 6), padx=4)
        b = sec.body

        blink = conditions.get_blink(el)
        self.var_blink_on = tk.BooleanVar(value=bool(blink.get("enabled")))
        ttk.Checkbutton(b, text="Моргание (_blink)", variable=self.var_blink_on,
                        command=self._commit_blink).grid(row=0, column=0, columnspan=3,
                                                        sticky="w")
        self.var_blink_up = tk.StringVar(value=_fmt(blink.get("on", 1.0)))
        self.var_blink_down = tk.StringVar(value=_fmt(blink.get("off", 0.6)))
        row_entry(b, 1, "Горит, с", self.var_blink_up, width=8,
                  command=self._commit_blink)
        row_entry(b, 2, "Не горит, с", self.var_blink_down, width=8,
                  command=self._commit_blink)

        cond = conditions.get_condition(el)
        self.var_cond_on = tk.BooleanVar(value=bool(cond.get("enabled")))
        ttk.Checkbutton(b, text="Условие показа (_cond)", variable=self.var_cond_on,
                        command=self._commit_condition).grid(row=3, column=0,
                                                            columnspan=3, sticky="w",
                                                            pady=(6, 0))
        sources = ["battery", "weather", "steps", "heart", "night", "charging", "bluetooth"]
        self.var_cond_src = tk.StringVar(value=str(cond.get("source") or "battery"))
        cb = ttk.Combobox(b, textvariable=self.var_cond_src, values=sources,
                          state="readonly")
        cb.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(0, 2))
        cb.bind("<<ComboboxSelected>>", lambda e: self._commit_condition())

        rules = cond.get("rules") or []
        ttk.Label(b, text="Правил в условии: %d (редактируются в JSON)"
                          % len(rules), style="Hint.TLabel").grid(
            row=5, column=0, columnspan=3, sticky="w")

        unsupported = conditions.has_unsupported(el)
        if unsupported:
            ttk.Label(b, text="Формат не гарантирует: " + ", ".join(unsupported),
                      style="Hint.TLabel", wraplength=330, justify="left",
                      foreground="#8a6d00").grid(row=6, column=0, columnspan=3,
                                                 sticky="w", pady=(4, 0))
            ttk.Button(b, text="Запечь такие слои в фон…",
                       command=self.app.bake_dialog).grid(row=7, column=0, columnspan=3,
                                                          sticky="w", pady=(2, 0))

    def _commit_blink(self, *_args) -> None:
        if self.el is None:
            return
        try:
            on = float(self.var_blink_up.get().replace(",", "."))
            off = float(self.var_blink_down.get().replace(",", "."))
        except (tk.TclError, ValueError):
            self.app.note("Периоды моргания — числа в секундах", error=True)
            return
        conditions.set_blink(self.el, bool(self.var_blink_on.get()), on, off)
        self.app.push_history("Моргание «%s»" % self.el.name)
        self.app.after_change()
        self.app.canvas_view.schedule(10)

    def _commit_condition(self, *_args) -> None:
        if self.el is None:
            return
        cond = conditions.get_condition(self.el)
        rules = cond.get("rules") or []
        conditions.set_condition(self.el, bool(self.var_cond_on.get()),
                                 self.var_cond_src.get(), rules)
        self.app.push_history("Условие «%s»" % self.el.name)
        self.app.after_change()

    # ------------------------------------------------------------- заметка
    def _build_note(self, el: model.DialElement) -> None:
        sec = Section(self.body, "Заметка (только в проекте)")
        sec.pack(fill="x", pady=(0, 10), padx=4)
        b = sec.body
        self.var_note = tk.StringVar(value=str(el.extra.get("_note") or ""))
        entry = row_entry(b, 0, "Комментарий", self.var_note, width=26,
                          command=self._commit_note)
        ttk.Label(b, text="Ключ _note не попадает в итоговый .tbwf",
                  style="Hint.TLabel", wraplength=330,
                  justify="left").grid(row=1, column=0, columnspan=3, sticky="w")

    def _commit_note(self, *_args) -> None:
        if self.el is None:
            return
        text = self.var_note.get().strip()
        if text:
            self.el.extra["_note"] = text
        else:
            self.el.extra.pop("_note", None)
        self.app.dirty = True
        self.app._update_status()


def _fmt(value) -> str:
    """Число → короткая строка без хвостовых нулей."""
    try:
        num = float(value)
    except (TypeError, ValueError):
        return "1.0"
    return ("%.2f" % num).rstrip("0").rstrip(".") or "0"
