# -*- coding: utf-8 -*-
"""Главное окно редактора циферблатов .tbwf для Haylou RS5.

Приложение работает «посредником» между панелями и моделью:
панели правят DialDocument, приложение перерисовывает превью, ведёт историю
undo/redo, автосохранение и статусбар. Канва сама обращается к app за данными
(app.doc, app.sim, app.store, app.selected, app.zoom_mult …).

Краткая инструкция по установке и запуску
-----------------------------------------
1. Нужен Python 3.10+ (проверено на 3.12) и библиотека Pillow:
       pip install -r requirements.txt
2. Запуск:  python main.py   (или двойной клик по run.bat)
3. Горячие клавиши см. в меню «Справка → Горячие клавиши».
"""

from __future__ import annotations

import datetime as _dt
import json
import os
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from typing import Dict, List, Optional

from PIL import Image

from .. import (bake, catalog, colors, conditions, constants, history,
                renderer, templates, tbwf, validate)
from ..model import DialDocument, DialElement
from . import panel_layers, panel_props, panel_resources, panel_sim
from .canvas_view import PreviewCanvas

PANEL_WIDTH = 380          # ширина боковой панели, px
DRAWER_BREAKPOINT = 1040   # уже этого — панель уезжает в «ящик»
TICK_MS = 300              # период анимации превью
AUTOSAVE_SECONDS = 120     # период автосохранения


def _ensure_dirs() -> None:
    """Создать рабочие каталоги проекта, если их нет."""
    for path in (constants.PROJECT_DIR, constants.PROJECTS_DIR,
                 constants.DOCS_DIR, constants.EXAMPLES_DIR):
        try:
            os.makedirs(path, exist_ok=True)
        except OSError:
            pass


class App(tk.Tk):
    """Окно редактора. Один экземпляр на процесс."""

    def __init__(self, autoclose: float = 0.0) -> None:
        super().__init__()
        _ensure_dirs()

        # ------------------------------------------------------------ состояние
        self.doc: Optional[DialDocument] = None
        self.resources: Dict[str, bytes] = {}
        self.store = renderer.ResourceStore({})
        self.sim = conditions.SimState()
        self.t = 0.0                      # время анимации, сек
        self.selected: Optional[str] = None
        self.path: Optional[str] = None   # путь .tbwf
        self.dirty = False
        self.playing = True               # анимация/моргание в превью
        self.live_clock = False           # подставлять системное время
        self.zoom_mult = 1.0
        self.show_grid = False
        self.show_safe = True
        self.hist = history.History(limit=100)
        self._autoclose = float(autoclose or 0.0)
        self._autosave_job: Optional[str] = None
        self._tick_job: Optional[str] = None
        self._resize_job: Optional[str] = None
        self._drawer_mode = False
        self._drawer_open = False
        self._syncing = False             # защита от рекурсии «поле → модель → поле»

        # ------------------------------------------------------------- геометрия
        self.title("Haylou Watchface Studio — редактор .tbwf для RS5")
        self.geometry("1400x900")
        self.minsize(780, 560)
        self.configure(bg="#20242c")

        self._setup_style()
        self._build_menu()
        self._build_toolbar()
        self._build_body()
        self._build_status()
        self._bind_keys()

        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.report_callback_exception = self._report_exception  # type: ignore[assignment]

        self.new_document("full")
        self._tick()
        self._schedule_autosave()
        self._offer_autosave_restore()

        if self._autoclose > 0:
            self.after(int(self._autoclose * 1000), self._autoclose_now)

    # ================================================================= оформление
    def _setup_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", font=("Segoe UI", 9))
        style.configure("TFrame", background="#f2f3f5")
        style.configure("TLabel", background="#f2f3f5", foreground="#1b1f27")
        style.configure("TLabelframe", background="#f2f3f5")
        style.configure("TLabelframe.Label", background="#f2f3f5",
                        foreground="#2a3140", font=("Segoe UI", 9, "bold"))
        style.configure("Tool.TFrame", background="#20242c")
        style.configure("Tool.TButton", background="#2c323c", foreground="#e6ecf5",
                        padding=(8, 4), borderwidth=0)
        style.map("Tool.TButton",
                  background=[("active", "#3a4250"), ("disabled", "#262b34")])
        style.configure("Tool.TCheckbutton", background="#20242c",
                        foreground="#c9d3e0", padding=(4, 2))
        style.map("Tool.TCheckbutton", background=[("active", "#2c323c")])
        style.configure("Tool.TLabel", background="#20242c", foreground="#93a2b5")
        style.configure("Status.TLabel", background="#171a20", foreground="#aab6c6",
                        padding=(8, 3))
        style.configure("Hint.TLabel", background="#f2f3f5", foreground="#5d6a7c")
        style.configure("Treeview", rowheight=22, font=("Segoe UI", 9),
                        background="#ffffff", fieldbackground="#ffffff")
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        style.configure("TNotebook.Tab", padding=(10, 5))

    # ===================================================================== меню
    def _build_menu(self) -> None:
        menubar = tk.Menu(self)

        m_file = tk.Menu(menubar, tearoff=0)
        m_new = tk.Menu(m_file, tearoff=0)
        m_new.add_command(label="Пустой циферблат", command=lambda: self.new_document("empty"))
        m_new.add_command(label="Минимальный набор", command=lambda: self.new_document("minimal"))
        m_new.add_command(label="Полный набор (RS5)", command=lambda: self.new_document("full"))
        m_file.add_cascade(label="Новый", menu=m_new)
        m_file.add_command(label="Открыть .tbwf…", accelerator="Ctrl+O",
                           command=self.open_dialog)
        m_file.add_command(label="Открыть образец из samples…",
                           command=self.open_sample_dialog)
        m_file.add_separator()
        m_file.add_command(label="Сохранить", accelerator="Ctrl+S", command=self.save)
        m_file.add_command(label="Сохранить как…", accelerator="Ctrl+Shift+S",
                           command=self.save_as)
        m_file.add_separator()
        m_file.add_command(label="Восстановить автосохранение",
                           command=self.restore_autosave)
        m_file.add_command(label="Экспорт PNG 410×502…", command=lambda: self.export_png(1))
        m_file.add_command(label="Экспорт PNG ×2 (820×1004)…", command=lambda: self.export_png(2))
        m_file.add_command(label="Запечь в фон и сохранить…", command=self.bake_dialog)
        m_file.add_separator()
        m_file.add_command(label="Выход", command=self.on_close)
        menubar.add_cascade(label="Файл", menu=m_file)

        m_edit = tk.Menu(menubar, tearoff=0)
        m_edit.add_command(label="Отменить", accelerator="Ctrl+Z", command=self.undo)
        m_edit.add_command(label="Повторить", accelerator="Ctrl+Y", command=self.redo)
        m_edit.add_separator()
        m_edit.add_command(label="Дублировать слой", accelerator="Ctrl+D",
                           command=self.duplicate_selected)
        m_edit.add_command(label="Удалить слой", accelerator="Delete",
                           command=self.delete_selected)
        m_edit.add_separator()
        m_edit.add_command(label="Пересчитать под RS5 (410×502)", command=self.recalc_rs5)
        m_edit.add_command(label="Переименовать слой…", command=self.rename_selected)
        menubar.add_cascade(label="Правка", menu=m_edit)

        m_view = tk.Menu(menubar, tearoff=0)
        self.var_grid = tk.BooleanVar(value=self.show_grid)
        self.var_safe = tk.BooleanVar(value=self.show_safe)
        m_view.add_checkbutton(label="Сетка 10×10", variable=self.var_grid,
                               command=self.toggle_grid)
        m_view.add_checkbutton(label="Безопасная зона", variable=self.var_safe,
                               command=self.toggle_safe)
        m_view.add_separator()
        m_view.add_command(label="Вписать в окно", accelerator="Ctrl+0",
                           command=self.fit_zoom)
        m_view.add_command(label="Панель справа", accelerator="Ctrl+B",
                           command=self.toggle_drawer)
        menubar.add_cascade(label="Вид", menu=m_view)

        m_tool = tk.Menu(menubar, tearoff=0)
        m_tool.add_command(label="Проверить документ (валидация)", accelerator="F5",
                           command=self.validate_dialog)
        m_tool.add_command(label="Демо-данные для превью", command=self.random_demo)
        m_tool.add_command(label="Сбросить симуляцию", command=self.reset_sim)
        m_tool.add_separator()
        m_tool.add_command(label="Анализ samples/ (отчёт в docs)", command=self.run_sample_analysis)
        menubar.add_cascade(label="Сервис", menu=m_tool)

        m_help = tk.Menu(menubar, tearoff=0)
        m_help.add_command(label="Руководство пользователя (README)", command=self.open_readme)
        m_help.add_command(label="Горячие клавиши", command=self.show_hotkeys)
        m_help.add_command(label="О программе", command=self.show_about)
        menubar.add_cascade(label="Справка", menu=m_help)

        self.config(menu=menubar)

    # ============================================================ панель инструментов
    def _build_toolbar(self) -> None:
        bar = ttk.Frame(self, style="Tool.TFrame", padding=(6, 5))
        bar.pack(side="top", fill="x")
        self.toolbar = bar

        self.btn_menu = ttk.Button(bar, text="☰", width=3, style="Tool.TButton",
                                   command=self.toggle_drawer)
        self.btn_menu.pack(side="left", padx=(0, 6))
        self.btn_menu.pack_forget()      # показываем только в «ящиковом» режиме

        self.btn_new = ttk.Button(bar, text="Новый", style="Tool.TButton",
                                  command=lambda: self.new_document("full"))
        self.btn_new.pack(side="left", padx=2)
        ttk.Button(bar, text="Открыть", style="Tool.TButton",
                   command=self.open_dialog).pack(side="left", padx=2)
        ttk.Button(bar, text="Сохранить", style="Tool.TButton",
                   command=self.save).pack(side="left", padx=2)

        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=6)
        self.btn_undo = ttk.Button(bar, text="↶", width=3, style="Tool.TButton",
                                   command=self.undo)
        self.btn_undo.pack(side="left", padx=2)
        self.btn_redo = ttk.Button(bar, text="↷", width=3, style="Tool.TButton",
                                   command=self.redo)
        self.btn_redo.pack(side="left", padx=2)

        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=6)
        ttk.Checkbutton(bar, text="Сетка", variable=self.var_grid,
                        style="Tool.TCheckbutton",
                        command=self.toggle_grid).pack(side="left", padx=2)
        ttk.Checkbutton(bar, text="Зона", variable=self.var_safe,
                        style="Tool.TCheckbutton",
                        command=self.toggle_safe).pack(side="left", padx=2)

        self.var_play = tk.BooleanVar(value=self.playing)
        ttk.Checkbutton(bar, text="Проигрывать", variable=self.var_play,
                        style="Tool.TCheckbutton",
                        command=self.toggle_play).pack(side="left", padx=(8, 2))
        ttk.Button(bar, text="Вписать", style="Tool.TButton",
                   command=self.fit_zoom).pack(side="left", padx=2)

        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=6)
        ttk.Button(bar, text="Проверка", style="Tool.TButton",
                   command=self.validate_dialog).pack(side="left", padx=2)
        ttk.Button(bar, text="Экспорт PNG", style="Tool.TButton",
                   command=lambda: self.export_png(1)).pack(side="left", padx=2)
        ttk.Button(bar, text="Запечь", style="Tool.TButton",
                   command=self.bake_dialog).pack(side="left", padx=2)

        self.lbl_zoom = ttk.Label(bar, text="100 %", style="Tool.TLabel", width=6,
                                  anchor="e")
        self.lbl_zoom.pack(side="right", padx=6)

    # ============================================================== тело окна
    def _build_body(self) -> None:
        self.body = ttk.Frame(self, style="Tool.TFrame")
        self.body.pack(side="top", fill="both", expand=True)

        # канва превью
        wrap = ttk.Frame(self.body, style="Tool.TFrame")
        wrap.pack(side="left", fill="both", expand=True)
        self.canvas_view = PreviewCanvas(wrap, self)
        self.canvas_view.pack(fill="both", expand=True)

        # затемнение под «ящиком»
        self.shade = tk.Canvas(self.body, bg="#20242c", highlightthickness=0)
        self.shade.bind("<Button-1>", lambda e: self.toggle_drawer())
        self.shade.bind("<Configure>", self._paint_shade)

        # боковая панель с четырьмя вкладками
        self.side = ttk.Frame(self.body, width=PANEL_WIDTH)
        self.nb = ttk.Notebook(self.side)
        self.nb.pack(fill="both", expand=True, padx=4, pady=4)
        self.panel_layers = panel_layers.LayersPanel(self.nb, self)
        self.panel_props = panel_props.PropsPanel(self.nb, self)
        self.panel_sim = panel_sim.SimPanel(self.nb, self)
        self.panel_resources = panel_resources.ResourcesPanel(self.nb, self)
        self.nb.add(self.panel_layers, text="Слои")
        self.nb.add(self.panel_props, text="Свойства")
        self.nb.add(self.panel_sim, text="Данные")
        self.nb.add(self.panel_resources, text="Ресурсы")

        self.side.pack(side="right", fill="y")
        self.bind("<Configure>", self._on_root_configure)

    def _paint_shade(self, _event=None) -> None:
        """Полупрозрачное затемнение канвы под выдвижной панелью."""
        self.shade.delete("all")
        w = self.shade.winfo_width()
        h = self.shade.winfo_height()
        if w > 1 and h > 1:
            self.shade.create_rectangle(0, 0, w, h, fill="#000000", stipple="gray50",
                                        outline="")

    # ================================================================ статусбар
    def _build_status(self) -> None:
        bar = ttk.Frame(self, style="Tool.TFrame")
        bar.pack(side="bottom", fill="x")
        self.lbl_msg = ttk.Label(bar, text="Готово", style="Status.TLabel",
                                 anchor="w")
        self.lbl_msg.pack(side="left", fill="x", expand=True)
        self.lbl_info = ttk.Label(bar, text="", style="Status.TLabel", anchor="e")
        self.lbl_info.pack(side="right", padx=4)

    def _bind_keys(self) -> None:
        self.bind_all("<Control-z>", lambda e: self.undo())
        self.bind_all("<Control-y>", lambda e: self.redo())
        self.bind_all("<Control-Z>", lambda e: self.redo())
        self.bind_all("<Control-s>", lambda e: self.save())
        self.bind_all("<Control-S>", lambda e: self.save_as())
        self.bind_all("<Control-o>", lambda e: self.open_dialog())
        self.bind_all("<Control-d>", lambda e: self.duplicate_selected())
        self.bind_all("<Control-0>", lambda e: self.fit_zoom())
        self.bind_all("<Control-b>", lambda e: self.toggle_drawer())
        self.bind_all("<F5>", lambda e: self.validate_dialog())
        self.bind_all("<Delete>", self._on_delete_key)

    def _on_delete_key(self, _event=None) -> None:
        # Delete не должен срабатывать, когда курсор в поле ввода
        try:
            widget = self.focus_get()
        except KeyError:
            widget = None
        if isinstance(widget, (tk.Entry, ttk.Entry, ttk.Combobox, tk.Text)):
            return
        self.delete_selected()

    # ============================================================= мелкие сервисы
    def ru_name(self, name: str) -> str:
        """Русская подпись элемента (или само имя)."""
        try:
            return catalog.ru_name(name) or name
        except Exception:                      # noqa: BLE001
            return name

    def note(self, text: str, error: bool = False) -> None:
        """Сообщение в статусбар (устойчиво к уже закрытому окну)."""
        try:
            if not self.lbl_msg.winfo_exists():
                return
            self.lbl_msg.configure(text=("⚠ " if error else "") + text,
                                   foreground="#ff8a80" if error else "#aab6c6")
        except tk.TclError:
            pass                       # окно уже уничтожено — молча выходим

    def _update_status(self) -> None:
        try:
            self._update_status_safe()
        except tk.TclError:
            pass

    def _update_status_safe(self) -> None:
        doc = self.doc
        if doc is None:
            self.lbl_info.configure(text="документ не открыт")
            return
        parts: List[str] = ["%d×%d" % (constants.SCREEN_W, constants.SCREEN_H),
                            "слоёв: %d" % len(doc)]
        name = self.selected
        if name and name in doc.elements:
            el = doc.elements[name]
            parts.append("x=%.3f y=%.3f" % (el.x if el.x is not None else 0.5,
                                            el.y if el.y is not None else 0.5))
        parts.append("изменён" if self.dirty else "сохранён")
        if self.path:
            parts.append(os.path.basename(self.path))
        self.lbl_info.configure(text="  |  ".join(parts))
        self.lbl_zoom.configure(text="%d %%" % round(self.zoom_mult * 100))

    # =============================================================== документ
    def new_document(self, kind: str = "full") -> None:
        try:
            doc, res = templates.build_template(kind)
        except Exception as exc:                       # noqa: BLE001
            messagebox.showerror("Новый документ", "Не удалось создать заготовку:\n%s" % exc)
            return
        self._load_state(doc, res, path=None, label="Новая заготовка (%s)" % kind)
        self.note("Создана заготовка «%s»: %d слоёв" % (kind, len(doc)))

    def _load_state(self, doc: DialDocument, resources: Dict[str, bytes],
                    path: Optional[str], label: str) -> None:
        """Поставить новый документ во все узлы приложения."""
        self.doc = doc
        self.resources = dict(resources or {})
        self._ensure_dial_resource()
        self.store.set_all(self.resources)
        self.path = path
        self.dirty = False
        self.selected = self._first_layer_name(doc)
        self.hist.reset(doc, label)
        self.refresh_all()
        self._update_status()
        self.canvas_view.schedule(10)

    def _first_layer_name(self, doc: DialDocument) -> Optional[str]:
        for el in doc.all_elements():
            if el.name != "dial":
                return el.name
        names = doc.names()
        return names[0] if names else None

    def _ensure_dial_resource(self) -> None:
        """Если фона нет — подложить стандартный dial.png (иначе превью пустое)."""
        key = constants.RES_IMAGE_DIR.lstrip("/") + "dial.png"
        if key not in self.resources:
            try:
                self.resources[key] = templates.default_dial_bytes()
            except Exception:                          # noqa: BLE001
                pass

    # ------------------------------------------------------------ открытие
    def open_dialog(self) -> None:
        path = filedialog.askopenfilename(
            title="Открыть циферблат .tbwf",
            initialdir=constants.SAMPLES_DIR if os.path.isdir(constants.SAMPLES_DIR) else constants.PROJECT_DIR,
            filetypes=[("Циферблат Haylou", "*.tbwf"), ("Все файлы", "*.*")])
        if path:
            self.open_path(path)

    def open_sample_dialog(self) -> None:
        folder = constants.SAMPLES_DIR
        if not os.path.isdir(folder):
            messagebox.showinfo("Образцы", "Каталог samples не найден:\n%s" % folder)
            return
        files = sorted(f for f in os.listdir(folder) if f.lower().endswith(".tbwf"))
        if not files:
            messagebox.showinfo("Образцы", "В samples нет файлов .tbwf")
            return
        win = tk.Toplevel(self)
        win.title("Образцы циферблатов")
        win.geometry("520x420")
        win.transient(self)
        lb = tk.Listbox(win, activestyle="dotbox")
        for name in files:
            lb.insert("end", name)
        lb.pack(fill="both", expand=True, padx=8, pady=8)

        def _take(_event=None):
            sel = lb.curselection()
            if sel:
                win.destroy()
                self.open_path(os.path.join(folder, files[sel[0]]))

        lb.bind("<Double-Button-1>", _take)
        ttk.Button(win, text="Открыть", command=_take).pack(pady=(0, 8))
        lb.selection_set(0)

    def open_path(self, path: str) -> None:
        """Загрузить .tbwf (или проект *.haylou.json) с проверкой пропорций."""
        try:
            if path.lower().endswith(".haylou.json"):
                doc, res, _meta = tbwf.load_project(path)
            else:
                doc, res = tbwf.load(path)
        except Exception as exc:                       # noqa: BLE001
            messagebox.showerror("Открыть", "Не удалось прочитать файл:\n%s\n\n%s" % (path, exc))
            self.note("Ошибка открытия: %s" % exc, error=True)
            return
        self._load_state(doc, res, path, "Открытие %s" % os.path.basename(path))
        self.note("Открыт %s — %d слоёв, %d ресурсов" %
                  (os.path.basename(path), len(doc), len(res)))
        self._check_aspect(doc)

    def _check_aspect(self, doc: DialDocument) -> None:
        """Предупредить, что файл из RS4 (другие пропорции)."""
        try:
            ratio = float(doc.aspect_ratio or 0)
        except (TypeError, ValueError):
            ratio = 0.0
        if abs(ratio - constants.ASPECT_RATIO) > 1e-6:
            self.note("Файл не RS5: aspectRatio=%.8f (RS5 — %.8f)" %
                      (ratio, constants.ASPECT_RATIO), error=True)
            txt = ("Пропорции файла %.8f отличаются от RS5 (%.8f).\n"
                   "Вероятно, циферблат сделан для RS4. Слои и координаты в порядке,\n"
                   "но фон и вертикальные позиции стоит пересчитать.\n\n"
                   "Выполнить «Пересчитать под RS5» сейчас?" % (ratio, constants.ASPECT_RATIO))
            try:
                answer = messagebox.askyesno("Пропорции не RS5", txt)
            except tk.TclError:
                return                 # окно закрыли, пока висел диалог
            if answer:
                self.recalc_rs5()

    # ------------------------------------------------------------ сохранение
    def save(self) -> None:
        if self.doc is None:
            return
        if not self.path:
            self.save_as()
            return
        self._write(self.path)

    def save_as(self) -> None:
        if self.doc is None:
            return
        initial = constants.EXAMPLES_DIR
        path = filedialog.asksaveasfilename(
            title="Сохранить циферблат .tbwf", initialdir=initial,
            defaultextension=".tbwf",
            initialfile=os.path.basename(self.path) if self.path else "haylou_rs5.tbwf",
            filetypes=[("Циферблат Haylou", "*.tbwf")])
        if path:
            self._write(path)

    def _write(self, path: str) -> None:
        try:
            issues = validate.validate_document(self.doc, self.resources)
            errs = [i for i in issues if i.get("level") == "error"]
            if errs:
                txt = "Документ содержит %d ошибок. Сохранить всё равно?\n\n" % len(errs)
                txt += "\n".join("• %s: %s" % (i.get("element"), i.get("message"))
                                 for i in errs[:8])
                if not messagebox.askyesno("Проверка не пройдена", txt):
                    self.note("Сохранение отменено (ошибки валидации)", error=True)
                    return
            tbwf.save(self.doc, path, self.resources, clean=True)
        except Exception as exc:                       # noqa: BLE001
            messagebox.showerror("Сохранить", "Не удалось сохранить:\n%s" % exc)
            self.note("Ошибка сохранения: %s" % exc, error=True)
            return
        self.path = path
        self.dirty = False
        self._update_status()
        self.note("Сохранено: %s" % path)

    def export_png(self, scale: int = 1) -> None:
        if self.doc is None:
            return
        scale = max(1, int(scale))
        w = constants.SCREEN_W * scale
        h = constants.SCREEN_H * scale
        path = filedialog.asksaveasfilename(
            title="Экспорт PNG %d×%d" % (w, h), initialdir=constants.EXAMPLES_DIR,
            defaultextension=".png",
            initialfile=("preview_%d_%d.png" % (w, h)),
            filetypes=[("PNG", "*.png")])
        if not path:
            return
        try:
            img = renderer.render_document(self.doc, self.sim, w, h,
                                           resources=self.store, t=self.t,
                                           ignore_blink=False)
            img.convert("RGBA").save(path, format="PNG")
        except Exception as exc:                       # noqa: BLE001
            messagebox.showerror("Экспорт PNG", "Не удалось отрисовать:\n%s" % exc)
            return
        self.note("PNG сохранён: %s (%d×%d)" % (path, w, h))

    # ------------------------------------------------------------ запекание
    def bake_dialog(self) -> None:
        if self.doc is None:
            return
        names = bake.plan_bake(self.doc)
        if not names:
            messagebox.showinfo("Запекание",
                                "Запекать нечего: все слои выражаются штатными средствами формата.")
            return
        win = tk.Toplevel(self)
        win.title("Запечь в фон")
        win.transient(self)
        win.resizable(False, False)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Слои, которые формат не умеет (уйдут в фон):",
                  font=("Segoe UI", 9, "bold")).pack(anchor="w")
        for name in names:
            ttk.Label(frame, text="• %s — %s" % (name, self.ru_name(name))).pack(anchor="w")
        var_frames = tk.IntVar(value=2)
        var_static = tk.BooleanVar(value=False)
        ttk.Label(frame, text="Сколько кадров фона делать:").pack(anchor="w", pady=(8, 0))
        ttk.Radiobutton(frame, text="1 кадр (моргание просто включено)",
                        variable=var_frames, value=1).pack(anchor="w")
        ttk.Radiobutton(frame, text="2 кадра (горит / не горит → sections=2)",
                        variable=var_frames, value=2).pack(anchor="w")
        ttk.Checkbutton(frame, text="Только статично (static)",
                        variable=var_static).pack(anchor="w", pady=(4, 0))

        def _run():
            win.destroy()
            path = filedialog.asksaveasfilename(
                title="Сохранить запечённый .tbwf", initialdir=constants.EXAMPLES_DIR,
                defaultextension=".tbwf", initialfile="haylou_rs5_baked.tbwf",
                filetypes=[("Циферблат Haylou", "*.tbwf")])
            if not path:
                return
            try:
                report = bake.bake_to_file(self.doc, self.sim, self.resources, path,
                                            frames=int(var_frames.get()),
                                            static=bool(var_static.get()))
            except Exception as exc:                   # noqa: BLE001
                messagebox.showerror("Запекание", "Ошибка:\n%s" % exc)
                return
            self.note(bake.describe_report(report))
            messagebox.showinfo("Запекание", bake.describe_report(report) + "\n\nФайл: " + path)
            try:                        # открыть результат для контроля
                doc, res = tbwf.load(path)
                self._load_state(doc, res, path, "Запечённый файл")
            except Exception:                          # noqa: BLE001
                pass

        ttk.Button(frame, text="Запечь и сохранить…", command=_run).pack(pady=(10, 0))

    # ------------------------------------------------------------ валидация
    def validate_dialog(self) -> None:
        if self.doc is None:
            return
        issues = validate.validate_document(self.doc, self.resources)
        win = tk.Toplevel(self)
        win.title("Проверка документа")
        win.geometry("720x460")
        win.transient(self)
        head = validate.summarize(issues)
        ttk.Label(win, text=head, font=("Segoe UI", 10, "bold"),
                  padding=(10, 8)).pack(anchor="w")
        body = ttk.Frame(win, padding=(10, 0))
        body.pack(fill="both", expand=True)
        tree = ttk.Treeview(body, columns=("level", "element", "message"),
                            show="headings", height=14)
        for col, text, width in (("level", "Уровень", 80), ("element", "Слой", 160),
                                 ("message", "Замечание", 430)):
            tree.heading(col, text=text)
            tree.column(col, width=width, anchor="w")
        tree.tag_configure("error", foreground="#b00020")
        tree.tag_configure("warn", foreground="#8a6d00")
        for item in issues:
            tree.insert("", "end", values=(item.get("level"), item.get("element"),
                                           item.get("message")),
                        tags=(item.get("level"),))
        vs = ttk.Scrollbar(body, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vs.set)
        tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")
        self.note(head, error=validate.has_errors(issues))

    # ------------------------------------------------------------ undo/redo
    def undo(self) -> None:
        if self.doc is None:
            return
        result = self.hist.undo()
        if not result:
            self.note("Отменять нечего")
            return
        doc, label = result
        self.doc = doc
        self.selected = self._first_layer_name(doc)
        self.dirty = True
        self.refresh_all()
        self.canvas_view.schedule(10)
        self.note("Отменено: %s" % label)

    def redo(self) -> None:
        if self.doc is None:
            return
        result = self.hist.redo()
        if not result:
            self.note("Повторять нечего")
            return
        doc, label = result
        self.doc = doc
        self.selected = self._first_layer_name(doc)
        self.dirty = True
        self.refresh_all()
        self.canvas_view.schedule(10)
        self.note("Повторено: %s" % label)

    def push_history(self, label: str = "Изменение") -> None:
        """Зафиксировать текущее состояние документа в истории."""
        if self.doc is not None:
            self.hist.push(self.doc, label)

    # ------------------------------------------------------------ правки
    def select(self, name: Optional[str]) -> None:
        if name == self.selected:
            return
        self.selected = name
        self.panel_props.rebuild()
        self.panel_layers.highlight(name)
        self._update_status()
        self.canvas_view.schedule(10)

    def after_change(self, label: Optional[str] = None) -> None:
        """Вызывается панелями после правки модели."""
        self.dirty = True
        if label:
            self.hist.push(self.doc, label)
        self.store.set_all(self.resources)
        self.panel_layers.refresh()
        self._update_status()
        self.canvas_view.schedule(15)

    def on_geometry_drag(self, element: DialElement) -> None:
        """Канва тянет слой — обновляем только числа в панели свойств."""
        self.dirty = True
        self.panel_props.sync_geometry()
        self._update_status()

    def refresh_all(self) -> None:
        self.panel_layers.refresh()
        self.panel_props.rebuild()
        self.panel_sim.refresh()
        self.panel_resources.refresh()
        self.store.set_all(self.resources)
        self._update_status()
        self._update_undo_buttons()

    def _update_undo_buttons(self) -> None:
        back, forward = self.hist.depth()
        self.btn_undo.state(["!disabled"] if back > 0 else ["disabled"])
        self.btn_redo.state(["!disabled"] if forward > 0 else ["disabled"])

    def add_element(self, base_name: str, kind: str) -> Optional[str]:
        """Добавить слой выбранного типа с разумными значениями по умолчанию."""
        if self.doc is None:
            return None
        name = self.doc.unique_name(base_name)
        try:
            if kind == "font":
                el = templates.make_text(name, 0.5, 0.5, 0.08)
            elif kind == "resourceCharacter":
                el = templates.make_char(name, 0.5, 0.5, 0.08)
            elif kind == "resourceIcon":
                official = catalog.OFFICIAL_ICONS[0]["id"]
                el = templates.make_icon(name, official, 0.5, 0.5, 0.07)
            elif kind == "resourceImage":
                el = templates.make_image(name, constants.RES_IMAGE_DIR + "dial.png",
                                          0.5, 0.5, 0.20)
            else:
                el = DialElement(name=name, kind=kind)
                el.x, el.y = 0.5, 0.5
                el.payload["size"] = 0.08
        except Exception as exc:                       # noqa: BLE001
            self.note("Не удалось создать слой: %s" % exc, error=True)
            return None
        self.doc.add(name, el)
        self.hist.push(self.doc, "Добавлен слой «%s»" % self.ru_name(name))
        self.selected = name
        self.refresh_all()
        self.canvas_view.schedule(10)
        self.note("Добавлен слой: %s (%s)" % (name, kind))
        return name

    def duplicate_selected(self) -> None:
        if self.doc is None or not self.selected:
            return
        el = self.doc.elements.get(self.selected)
        if el is None or el.name == "dial":
            self.note("Нечего дублировать", error=True)
            return
        name = self.doc.unique_name(el.name + "_copy")
        clone = el.clone()
        clone.name = name
        clone.x = min(1.0, (clone.x or 0.5) + 0.02)
        clone.y = min(1.0, (clone.y or 0.5) + 0.02)
        self.doc.add(name, clone, self.doc.index_of(el.name) + 1)
        self.hist.push(self.doc, "Дублирован слой «%s»" % el.name)
        self.selected = name
        self.refresh_all()
        self.canvas_view.schedule(10)

    def delete_selected(self) -> None:
        if self.doc is None or not self.selected:
            return
        name = self.selected
        if name == "dial":
            self.note("Фон dial удалять нельзя", error=True)
            return
        if not messagebox.askyesno("Удалить слой",
                                   "Удалить слой «%s» (%s)?" % (name, self.ru_name(name))):
            return
        self.doc.remove(name)
        self.hist.push(self.doc, "Удалён слой «%s»" % name)
        self.selected = self._first_layer_name(self.doc)
        self.refresh_all()
        self.canvas_view.schedule(10)

    def rename_selected(self) -> None:
        if self.doc is None or not self.selected:
            return
        old = self.selected
        win = tk.Toplevel(self)
        win.title("Переименовать слой")
        win.transient(self)
        var = tk.StringVar(value=old)
        ttk.Label(win, text="Новое имя:").pack(padx=10, pady=(10, 0), anchor="w")
        ent = ttk.Entry(win, textvariable=var, width=32)
        ent.pack(padx=10, pady=6)
        ent.focus_set()

        def _ok():
            new = var.get().strip()
            win.destroy()
            if not new or new == old:
                return
            if new in self.doc:
                self.note("Имя «%s» уже занято" % new, error=True)
                return
            self.doc.rename(old, new)
            self.hist.push(self.doc, "Переименование «%s» → «%s»" % (old, new))
            self.selected = new
            self.refresh_all()

        ttk.Button(win, text="OK", command=_ok).pack(pady=(0, 10))

    def recalc_rs5(self) -> None:
        """Привести документ к пропорциям RS5 (410×502)."""
        if self.doc is None:
            return
        old = self.doc.aspect_ratio
        self.doc.aspect_ratio = constants.ASPECT_RATIO
        self.doc.case_shape = constants.CASE_SHAPE
        dial = self.doc.elements.get("dial")
        if dial is not None:
            dial.payload["width"] = constants.SCREEN_W
            dial.payload["height"] = constants.SCREEN_H
            dial.payload["size"] = 1.0
        self.hist.push(self.doc, "Пересчёт под RS5")
        self.after_change()
        self.note("Пропорции: %.8f → %.8f. Фон при необходимости замените в «Ресурсы»."
                  % (float(old or 0), constants.ASPECT_RATIO))

    # ------------------------------------------------------------ вид/симуляция
    def toggle_grid(self) -> None:
        self.show_grid = bool(self.var_grid.get())
        self.canvas_view.schedule(10)

    def toggle_safe(self) -> None:
        self.show_safe = bool(self.var_safe.get())
        self.canvas_view.schedule(10)

    def toggle_play(self) -> None:
        self.playing = bool(self.var_play.get())
        self.canvas_view.schedule(10)

    def fit_zoom(self) -> None:
        self.zoom_mult = 1.0
        self.canvas_view.schedule(10)
        self._update_status()

    def random_demo(self) -> None:
        self.sim.random_demo()
        self.panel_sim.refresh()
        self.canvas_view.schedule(10)
        self.note("Демо-данные обновлены")

    def reset_sim(self) -> None:
        self.sim = conditions.SimState()
        self.panel_sim.refresh()
        self.canvas_view.schedule(10)
        self.note("Симуляция сброшена")

    # ------------------------------------------------------------ адаптивность
    def _on_root_configure(self, event) -> None:
        if event.widget is not self:
            return
        if self._resize_job is not None:
            try:
                self.after_cancel(self._resize_job)
            except tk.TclError:
                pass
        self._resize_job = self.after(120, self._apply_layout)

    def _apply_layout(self) -> None:
        self._resize_job = None
        width = self.winfo_width()
        drawer = width < DRAWER_BREAKPOINT
        if drawer != self._drawer_mode:
            self._drawer_mode = drawer
            if drawer:
                self.side.pack_forget()
                self.btn_menu.pack(side="left", padx=(0, 6), before=self.btn_new)
                self._drawer_open = False
                self._place_drawer()
            else:
                self._drawer_open = False
                self.side.place_forget()
                self.shade.place_forget()
                self.btn_menu.pack_forget()
                self.side.pack(side="right", fill="y")
        # подстройка шрифтов под размер окна
        base = 10 if width >= 1500 else 9 if width >= 1100 else 8
        try:
            style = ttk.Style(self)
            style.configure(".", font=("Segoe UI", base))
            style.configure("Treeview", font=("Segoe UI", base), rowheight=base + 13)
            style.configure("Treeview.Heading", font=("Segoe UI", base, "bold"))
        except tk.TclError:
            pass
        self.canvas_view.schedule(20)

    def toggle_drawer(self) -> None:
        if not self._drawer_mode:
            # в обычном режиме просто скрываем/показываем панель
            if self.side.winfo_manager():
                self.side.pack_forget()
            else:
                self.side.pack(side="right", fill="y")
            self.canvas_view.schedule(20)
            return
        self._drawer_open = not self._drawer_open
        self._place_drawer()

    def _place_drawer(self) -> None:
        if not self._drawer_mode:
            return
        if self._drawer_open:
            self.shade.place(in_=self.body, x=0, y=0, relwidth=1, relheight=1)
            self.side.place(in_=self.body, relx=1.0, rely=0, anchor="ne",
                            relheight=1.0, width=PANEL_WIDTH)
            self.side.lift()
            self._paint_shade()
        else:
            self.shade.place_forget()
            self.side.place_forget()

    # ------------------------------------------------------------ автосохранение
    def _schedule_autosave(self) -> None:
        if self._autosave_job is not None:
            try:
                self.after_cancel(self._autosave_job)
            except tk.TclError:
                pass
        self._autosave_job = self.after(AUTOSAVE_SECONDS * 1000, self._autosave)

    def _autosave(self) -> None:
        self._autosave_job = None
        if self.doc is not None:
            try:
                meta = {"saved": _dt.datetime.now().isoformat(timespec="seconds"),
                        "path": self.path or "", "selected": self.selected or ""}
                tbwf.save_project(constants.AUTOSAVE_PATH, self.doc, self.resources, meta)
            except Exception as exc:                   # noqa: BLE001
                self.note("Автосохранение не удалось: %s" % exc, error=True)
        self._schedule_autosave()

    def _offer_autosave_restore(self) -> None:
        """Ненавязчиво сообщить, что есть автосохранение."""
        if os.path.isfile(constants.AUTOSAVE_PATH):
            stamp = _dt.datetime.fromtimestamp(
                os.path.getmtime(constants.AUTOSAVE_PATH))
            self.note("Есть автосохранение от %s — «Файл → Восстановить автосохранение»"
                      % stamp.strftime("%d.%m.%Y %H:%M"))

    def restore_autosave(self) -> None:
        if not os.path.isfile(constants.AUTOSAVE_PATH):
            messagebox.showinfo("Автосохранение", "Файл автосохранения не найден.")
            return
        try:
            doc, res, meta = tbwf.load_project(constants.AUTOSAVE_PATH)
        except Exception as exc:                       # noqa: BLE001
            messagebox.showerror("Автосохранение", "Не удалось прочитать:\n%s" % exc)
            return
        self._load_state(doc, res, meta.get("path") or None,
                         "Восстановление автосохранения")
        self.note("Восстановлено автосохранение от %s" % meta.get("saved", "—"))

    # ------------------------------------------------------------ анализ образцов
    def run_sample_analysis(self) -> None:
        try:
            from .. import sample_analysis            # ленивый импорт: модуль необязателен
            report = sample_analysis.analyze_folder(constants.SAMPLES_DIR)
            path = os.path.join(constants.DOCS_DIR, "format_analysis.md")
            os.makedirs(constants.DOCS_DIR, exist_ok=True)
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(report)
        except Exception as exc:                       # noqa: BLE001
            messagebox.showerror("Анализ samples", "Не удалось выполнить анализ:\n%s" % exc)
            return
        self.note("Отчёт по samples записан: %s" % path)

    # ------------------------------------------------------------ справка
    def open_readme(self) -> None:
        path = os.path.join(constants.PROJECT_DIR, "README.md")
        if os.path.isfile(path):
            try:
                os.startfile(path)                     # noqa: S606
                return
            except OSError:
                pass
        messagebox.showinfo("Руководство", "Файл README.md не найден:\n%s" % path)

    def show_hotkeys(self) -> None:
        text = ("Ctrl+Z / Ctrl+Y — отменить / повторить\n"
                "Ctrl+S / Ctrl+Shift+S — сохранить / сохранить как\n"
                "Ctrl+O — открыть .tbwf\n"
                "Ctrl+D — дублировать слой\n"
                "Delete — удалить слой\n"
                "Ctrl+0 — вписать превью в окно\n"
                "Ctrl+колесо — масштаб превью, Shift при перетаскивании — без привязки\n"
                "Ctrl+B — показать/скрыть панель справа\n"
                "F5 — проверка документа")
        messagebox.showinfo("Горячие клавиши", text)

    def show_about(self) -> None:
        from .. import __version__
        messagebox.showinfo(
            "О программе",
            "Haylou Watchface Studio %s\n\n"
            "Визуальный редактор циферблатов .tbwf для часов Haylou RS5.\n"
            "Экран %d×%d, пропорции %.8f, caseShape=\"%s\".\n\n"
            "Ядро: Python + Pillow + tkinter. Без внешних сервисов."
            % (__version__, constants.SCREEN_W, constants.SCREEN_H,
               constants.ASPECT_RATIO, constants.CASE_SHAPE))

    # ------------------------------------------------------------ анимация
    def _tick(self) -> None:
        self._tick_job = None
        try:
            if self.playing:
                self.t += TICK_MS / 1000.0
            if self.live_clock:
                self.sim.time = _dt.datetime.now()
            if self.playing or self.live_clock:
                self.canvas_view.schedule(0)
            self._tick_job = self.after(TICK_MS, self._tick)
        except tk.TclError:
            pass

    # ------------------------------------------------------------ закрытие
    def on_close(self) -> None:
        if self._autoclose > 0:
            self._shutdown()
            return
        if self.dirty:
            answer = messagebox.askyesnocancel(
                "Выход", "Документ изменён. Сохранить перед выходом?")
            if answer is None:
                return
            if answer:
                self.save()
                if self.dirty:            # сохранение отменили/не удалось
                    return
        self._shutdown()

    def _shutdown(self) -> None:
        # финальное автосохранение, чтобы ничего не потерять
        if self.doc is not None:
            try:
                meta = {"saved": _dt.datetime.now().isoformat(timespec="seconds"),
                        "path": self.path or "", "selected": self.selected or ""}
                tbwf.save_project(constants.AUTOSAVE_PATH, self.doc, self.resources, meta)
            except Exception:                          # noqa: BLE001
                pass
        for job in (self._tick_job, self._autosave_job, self._resize_job):
            if job is not None:
                try:
                    self.after_cancel(job)
                except tk.TclError:
                    pass
        try:
            self.destroy()
        except tk.TclError:
            pass

    def _autoclose_now(self) -> None:
        print("[autoclose] окно закрыто через %.1f с" % self._autoclose)
        self._shutdown()

    # ------------------------------------------------------------ ошибки
    def _report_exception(self, exc_type, exc_value, exc_traceback) -> None:
        """Все необработанные ошибки tkinter — в projects/error.log + диалог."""
        import traceback
        text = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        try:
            _ensure_dirs()
            with open(constants.ERROR_LOG, "a", encoding="utf-8") as fh:
                fh.write("\n=== %s ===\n%s" % (_dt.datetime.now().isoformat(timespec="seconds"), text))
        except OSError:
            pass
        self.note("Ошибка: %s" % exc_value, error=True)
        try:
            messagebox.showerror("Ошибка", "%s\n\nПодробности: %s"
                                 % (exc_value, constants.ERROR_LOG))
        except tk.TclError:
            pass
