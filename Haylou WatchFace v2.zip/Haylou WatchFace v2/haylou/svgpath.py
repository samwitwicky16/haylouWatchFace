# -*- coding: utf-8 -*-
"""Собственный парсер и растеризатор SVG-path.

CairoSVG в проекте недоступен (нет native cairo), поэтому:
  1) разбираем строку path в набор ломаных (с аппроксимацией кривых Безье и дуг);
  2) рисуем их на увеличенном холсте (суперсэмплинг x4);
  3) уменьшаем методом LANCZOS — получаем гладкие края в любом размере.

Поддержаны команды: M m L l H h V v C c S s Q q T t A a Z z.
"""

from __future__ import annotations

import math
import re
from typing import Iterable, List, Sequence, Tuple

from PIL import Image, ImageDraw

RESAMPLE = getattr(Image, "Resampling", Image).LANCZOS

_TOKEN_RE = re.compile(r"[MmLlHhVvCcSsQqTtAaZz]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?")
_CMD_ARGS = {"M": 2, "L": 2, "H": 1, "V": 1, "C": 6, "S": 4, "Q": 4, "T": 2, "A": 7, "Z": 0}
_BEZIER_STEPS = 20


def _tokenize(path: str) -> List[str]:
    return _TOKEN_RE.findall(path or "")


def _arc_to_points(x0: float, y0: float, rx: float, ry: float, phi_deg: float,
                   large_arc: int, sweep: int, x1: float, y1: float,
                   steps: int = 24) -> List[Tuple[float, float]]:
    """Преобразовать SVG-дугу в набор точек (через центр эллипса)."""
    if rx == 0 or ry == 0:
        return [(x1, y1)]
    phi = math.radians(phi_deg)
    cos_phi, sin_phi = math.cos(phi), math.sin(phi)
    dx2 = (x0 - x1) / 2.0
    dy2 = (y0 - y1) / 2.0
    x1p = cos_phi * dx2 + sin_phi * dy2
    y1p = -sin_phi * dx2 + cos_phi * dy2
    rx, ry = abs(rx), abs(ry)
    lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
    if lam > 1.0:                       # радиусы малы — масштабируем
        k = math.sqrt(lam)
        rx *= k
        ry *= k
    num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
    den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
    ratio = max(0.0, num / den) if den else 0.0
    coef = math.sqrt(ratio)
    if large_arc == sweep:
        coef = -coef
    cxp = coef * (rx * y1p / ry)
    cyp = -coef * (ry * x1p / rx)
    cx = cos_phi * cxp - sin_phi * cyp + (x0 + x1) / 2.0
    cy = sin_phi * cxp + cos_phi * cyp + (y0 + y1) / 2.0

    def angle(ux: float, uy: float, vx: float, vy: float) -> float:
        dot = ux * vx + uy * vy
        norm = math.hypot(ux, uy) * math.hypot(vx, vy)
        if norm == 0:
            return 0.0
        a = math.acos(max(-1.0, min(1.0, dot / norm)))
        return -a if (ux * vy - uy * vx) < 0 else a

    theta1 = angle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dtheta = angle((x1p - cxp) / rx, (y1p - cyp) / ry,
                   (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if sweep == 0 and dtheta > 0:
        dtheta -= 2 * math.pi
    elif sweep == 1 and dtheta < 0:
        dtheta += 2 * math.pi

    pts: List[Tuple[float, float]] = []
    n = max(4, int(steps * max(1.0, abs(dtheta) / (math.pi / 2))))
    for i in range(1, n + 1):
        t = theta1 + dtheta * i / n
        xt = rx * math.cos(t)
        yt = ry * math.sin(t)
        pts.append((cos_phi * xt - sin_phi * yt + cx,
                    sin_phi * xt + cos_phi * yt + cy))
    pts[-1] = (x1, y1)
    return pts


def _cubic(p0, p1, p2, p3, steps: int = _BEZIER_STEPS) -> List[Tuple[float, float]]:
    out = []
    for i in range(1, steps + 1):
        t = i / steps
        mt = 1 - t
        a = mt * mt * mt
        b = 3 * mt * mt * t
        c = 3 * mt * t * t
        d = t * t * t
        out.append((a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0],
                    a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]))
    return out


def parse_path(path: str) -> List[dict]:
    """Разобрать SVG-path в список подконтуров: [{'points': [(x,y)...], 'closed': bool}]."""
    tokens = _tokenize(path)
    subpaths: List[dict] = []
    current: List[Tuple[float, float]] = []
    cur = (0.0, 0.0)
    start = (0.0, 0.0)
    last_cmd = ""
    prev_cubic_ctrl = None
    prev_quad_ctrl = None
    i = 0
    cmd = ""

    def flush(closed: bool = False) -> None:
        nonlocal current
        if len(current) >= 2:
            pts = list(current)
            if closed:
                pts.append(pts[0])
            subpaths.append({"points": pts, "closed": closed})
        current = []

    def num() -> float:
        nonlocal i
        if i >= len(tokens):
            raise ValueError("не хватает чисел в path")
        tok = tokens[i]
        i += 1
        return float(tok)

    def flag() -> int:
        """Флаг дуги: может прийти слипшимся ('01' -> 0, затем 1)."""
        nonlocal i
        tok = tokens[i]
        if len(tok) > 1 and tok[0] in "01":
            tokens[i] = tok[1:]
            return int(tok[0])
        i += 1
        return 1 if float(tok) >= 0.5 else 0

    while i < len(tokens):
        tok = tokens[i]
        if tok.isalpha():
            cmd = tok
            i += 1
            if cmd in "Zz":
                flush(closed=True)
                cur = start
                last_cmd = cmd
                prev_cubic_ctrl = prev_quad_ctrl = None
                continue
        elif not cmd:
            break
        # повтор последней команды без буквы (implicit)
        up = cmd.upper()
        rel = cmd.islower()

        if up == "M":
            x, y = num(), num()
            if rel:
                x += cur[0]
                y += cur[1]
            flush(closed=False)
            cur = start = (x, y)
            current = [cur]
            cmd = "l" if rel else "L"      # последующие пары — линия
            last_cmd = "M"
            prev_cubic_ctrl = prev_quad_ctrl = None
        elif up == "L":
            x, y = num(), num()
            if rel:
                x += cur[0]
                y += cur[1]
            cur = (x, y)
            if not current:
                current = [cur]
            else:
                current.append(cur)
            last_cmd = "L"
            prev_cubic_ctrl = prev_quad_ctrl = None
        elif up == "H":
            x = num()
            if rel:
                x += cur[0]
            cur = (x, cur[1])
            current = current or [(cur[0], cur[1])]
            current.append(cur)
            last_cmd = "H"
            prev_cubic_ctrl = prev_quad_ctrl = None
        elif up == "V":
            y = num()
            if rel:
                y += cur[1]
            cur = (cur[0], y)
            current = current or [cur]
            current.append(cur)
            last_cmd = "V"
            prev_cubic_ctrl = prev_quad_ctrl = None
        elif up == "C":
            x1, y1 = num(), num()
            x2, y2 = num(), num()
            x, y = num(), num()
            if rel:
                x1 += cur[0]; y1 += cur[1]
                x2 += cur[0]; y2 += cur[1]
                x += cur[0]; y += cur[1]
            pts = _cubic(cur, (x1, y1), (x2, y2), (x, y))
            current = (current or [cur]) + pts
            prev_cubic_ctrl = (x2, y2)
            prev_quad_ctrl = None
            cur = (x, y)
            last_cmd = "C"
        elif up == "S":
            x2, y2 = num(), num()
            x, y = num(), num()
            if rel:
                x2 += cur[0]; y2 += cur[1]
                x += cur[0]; y += cur[1]
            if last_cmd.upper() in ("C", "S") and prev_cubic_ctrl:
                x1 = 2 * cur[0] - prev_cubic_ctrl[0]
                y1 = 2 * cur[1] - prev_cubic_ctrl[1]
            else:
                x1, y1 = cur
            pts = _cubic(cur, (x1, y1), (x2, y2), (x, y))
            current = (current or [cur]) + pts
            prev_cubic_ctrl = (x2, y2)
            prev_quad_ctrl = None
            cur = (x, y)
            last_cmd = "S"
        elif up == "Q":
            qx, qy = num(), num()
            x, y = num(), num()
            if rel:
                qx += cur[0]; qy += cur[1]
                x += cur[0]; y += cur[1]
            c1 = (cur[0] + 2.0 / 3.0 * (qx - cur[0]), cur[1] + 2.0 / 3.0 * (qy - cur[1]))
            c2 = (x + 2.0 / 3.0 * (qx - x), y + 2.0 / 3.0 * (qy - y))
            pts = _cubic(cur, c1, c2, (x, y))
            current = (current or [cur]) + pts
            prev_quad_ctrl = (qx, qy)
            prev_cubic_ctrl = None
            cur = (x, y)
            last_cmd = "Q"
        elif up == "T":
            x, y = num(), num()
            if rel:
                x += cur[0]; y += cur[1]
            if last_cmd.upper() in ("Q", "T") and prev_quad_ctrl:
                qx = 2 * cur[0] - prev_quad_ctrl[0]
                qy = 2 * cur[1] - prev_quad_ctrl[1]
            else:
                qx, qy = cur
            c1 = (cur[0] + 2.0 / 3.0 * (qx - cur[0]), cur[1] + 2.0 / 3.0 * (qy - cur[1]))
            c2 = (x + 2.0 / 3.0 * (qx - x), y + 2.0 / 3.0 * (qy - y))
            pts = _cubic(cur, c1, c2, (x, y))
            current = (current or [cur]) + pts
            prev_quad_ctrl = (qx, qy)
            prev_cubic_ctrl = None
            cur = (x, y)
            last_cmd = "T"
        elif up == "A":
            rx, ry = num(), num()
            phi = num()
            large = flag()
            sweep = flag()
            x, y = num(), num()
            if rel:
                x += cur[0]; y += cur[1]
            pts = _arc_to_points(cur[0], cur[1], rx, ry, phi, large, sweep, x, y)
            current = (current or [cur]) + pts
            cur = (x, y)
            last_cmd = "A"
            prev_cubic_ctrl = prev_quad_ctrl = None
        else:
            i += 1        # неизвестная команда — пропускаем, чтобы не зациклиться
        if i == 0:
            break
    flush(closed=False)
    return subpaths


def render_shape(size_px: int, shapes: Sequence[dict],
                 viewbox: Tuple[float, float] = (24.0, 24.0),
                 color: Tuple[int, int, int, int] = (255, 255, 255, 255),
                 supersample: int = 4) -> Image.Image:
    """Нарисовать набор фигур в RGBA-картинку заданного размера.

    shapes — список словарей:
        {'d': 'M...', 'fill': True, 'stroke': 0.0}   # stroke — толщина в единицах viewbox
        {'d': 'M...', 'fill': False, 'stroke': 2.0}
    """
    size_px = max(1, int(size_px))
    ss = max(1, int(supersample))
    canvas_px = size_px * ss
    vb_w, vb_h = float(viewbox[0] or 24.0), float(viewbox[1] or 24.0)
    sx = canvas_px / vb_w
    sy = canvas_px / vb_h

    img = Image.new("RGBA", (canvas_px, canvas_px), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    for shape in shapes:
        d = shape.get("d") or ""
        if not d:
            continue
        try:
            subpaths = parse_path(d)
        except Exception:
            continue
        for sub in subpaths:
            pts = [(p[0] * sx, p[1] * sy) for p in sub["points"]]
            if len(pts) < 2:
                continue
            if shape.get("fill"):
                draw.polygon(pts, fill=color)
            stroke_w = float(shape.get("stroke") or 0.0)
            if stroke_w > 0:
                width = max(1, int(round(stroke_w * min(sx, sy))))
                if sub["closed"]:
                    pts_line = pts + [pts[0]]
                else:
                    pts_line = pts
                draw.line(pts_line, fill=color, width=width, joint="curve")
                # круглые «заглушки» на концах, чтобы линии не были обрубленными
                r = width / 2.0
                for p in (pts_line[0], pts_line[-1]):
                    draw.ellipse([p[0] - r, p[1] - r, p[0] + r, p[1] + r], fill=color)

    return img.resize((size_px, size_px), RESAMPLE)


def circle_path(cx: float, cy: float, r: float) -> str:
    """Круг как путь (2 дуги) — удобно для иконок."""
    return ("M%g %gA%g %g 0 1 0 %g %gA%g %g 0 1 0 %g %gZ"
            % (cx - r, cy, r, r, cx + r, cy, r, r, cx - r, cy))


def rect_path(x: float, y: float, w: float, h: float, r: float = 0.0) -> str:
    """Прямоугольник, опционально со скруглением."""
    if r <= 0:
        return "M%g %gH%gV%gH%gZ" % (x, y, x + w, y + h, x)
    return ("M%g %gH%gA%g %g 0 0 1 %g %gV%gA%g %g 0 0 1 %g %gH%g"
            "A%g %g 0 0 1 %g %gV%gA%g %g 0 0 1 %g %gZ"
            % (x + r, y, x + w - r, r, r, x + w, y + r,
               y + h - r, r, r, x + w - r, y + h,
               x + r, r, r, x, y + h - r,
               y + r, r, r, x + r, y))


def line_path(points: Iterable[Tuple[float, float]]) -> str:
    """Ломаная по точкам."""
    pts = list(points)
    if not pts:
        return ""
    out = ["M%g %g" % pts[0]]
    for x, y in pts[1:]:
        out.append("L%g %g" % (x, y))
    return "".join(out)
