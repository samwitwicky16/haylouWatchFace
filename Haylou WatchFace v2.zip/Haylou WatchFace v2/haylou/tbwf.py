# -*- coding: utf-8 -*-
"""Работа с контейнером .tbwf (ZIP + TiBoWaFe.json + ресурсы) и файлом проекта.

Ключи ресурсов внутри приложения нормализованы: без ведущего слэша,
разделители — прямые, поиск регистронезависимый (helper `res_key`).
Регистр сохраняется, чтобы при записи архива пути остались ровно такими,
как их ждёт Hello Haylou ('resourceImage/dial.png').
"""

from __future__ import annotations

import base64
import io
import json
import os
import re
import zipfile
from typing import Dict, List, Optional, Sequence, Tuple

from . import constants
from .model import DialDocument

JSON_NAME = constants.JSON_NAME


# ---------------------------------------------------------------- утилиты путей
def normalize_res_path(path: str) -> str:
    """Путь ресурса без ведущего слэша: '/resourceImage/dial.png' -> 'resourceImage/dial.png'."""
    p = (path or "").replace("\\", "/").strip()
    return p.lstrip("/")


def res_key(path: str) -> str:
    """Ключ для поиска в словаре ресурсов (регистр не важен)."""
    return normalize_res_path(path).lower()


def find_key(resources: Dict[str, bytes], path: str) -> Optional[str]:
    """Найти фактический ключ ресурса по пути из JSON."""
    want = res_key(path)
    if want in resources:
        return want
    for key in resources.keys():
        if key.lower() == want:
            return key
    # особая мелочь: в именах папок бывает хвостовой пробел ('/resourceCharacter/Hora /')
    for key in resources.keys():
        if key.lower().rstrip() == want.rstrip():
            return key
    return None


def folder_keys(resources: Dict[str, bytes], folder: str) -> List[str]:
    """Все ресурсы внутри папки (без вложенности глубже одного уровня)."""
    prefix = res_key(folder).rstrip("/") + "/"
    out = []
    for key in resources.keys():
        low = key.lower()
        if low.startswith(prefix) and low.count("/") == prefix.count("/"):
            out.append(key)
    return out


# ------------------------------------------------------------------- чтение
def find_json_name(zf: zipfile.ZipFile) -> Optional[str]:
    """Имя JSON-описания внутри архива (регистр может отличаться)."""
    names = zf.namelist()
    for name in names:
        if name.split("/")[-1].lower() == JSON_NAME.lower():
            return name
    for name in names:
        if name.lower().endswith(".json"):
            return name
    return None


def decode_json_bytes(raw: bytes) -> str:
    for enc in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def load(path: str) -> Tuple[DialDocument, Dict[str, bytes]]:
    """Прочитать .tbwf: (документ, словарь ресурсов {путь без слэша: байты})."""
    with zipfile.ZipFile(path, "r") as zf:
        json_name = find_json_name(zf)
        if not json_name:
            raise ValueError("В архиве нет JSON-описания (ожидался %s)" % JSON_NAME)
        data = json.loads(decode_json_bytes(zf.read(json_name)))
        resources: Dict[str, bytes] = {}
        for name in zf.namelist():
            if name.endswith("/"):
                continue
            if name == json_name or name.lower().endswith(".json"):
                continue
            resources[normalize_res_path(name)] = zf.read(name)
    return DialDocument.from_dict(data), resources


def read_json_raw(path: str) -> dict:
    """Только JSON из архива (для анализа образцов)."""
    with zipfile.ZipFile(path, "r") as zf:
        json_name = find_json_name(zf)
        if not json_name:
            raise ValueError("В архиве нет JSON-описания")
        return json.loads(decode_json_bytes(zf.read(json_name)))


def archive_listing(path: str) -> List[Tuple[str, int]]:
    """Содержимое архива: [(путь без слэша, размер в байтах)]."""
    out = []
    with zipfile.ZipFile(path, "r") as zf:
        for info in zf.infolist():
            if info.filename.endswith("/"):
                continue
            out.append((normalize_res_path(info.filename), info.file_size))
    return out


# ------------------------------------------------------------------- запись
def used_resources(doc: DialDocument, resources: Dict[str, bytes]) -> Dict[str, bytes]:
    """Отобрать только те ресурсы, на которые ссылается документ (плюс весь dial)."""
    keep: Dict[str, bytes] = {}

    def add(path: str, whole_folder: bool = False) -> None:
        path = normalize_res_path(path)
        if not path:
            return
        if whole_folder or path.endswith("/"):
            for key in folder_keys(resources, path):
                keep[key] = resources[key]
            if not path.endswith("/"):
                key = find_key(resources, path)
                if key:
                    keep[key] = resources[key]
            return
        key = find_key(resources, path)
        if key:
            keep[key] = resources[key]
            return
        # путь-секвенция вида 'resourceImage/battery/battery_0.png' -> вся папка
        if "/" in path:
            for key in folder_keys(resources, path.rsplit("/", 1)[0] + "/"):
                keep[key] = resources[key]

    for el in doc.all_elements():
        if el.kind == "resourceImage":
            res = el.get_resource()
            if res:
                add(res, whole_folder=el.get_sections() > 1 or res.endswith("/"))
        elif el.kind == "resourceCharacter":
            add(el.get_resource(), whole_folder=True)
        elif el.kind == "resourceIcon":
            custom = el.extra.get(constants.EXT_CUSTOM_ICON)
            if custom and find_key(resources, custom):
                add(custom)
        # шрифты из архива нужны приложению
    for key in list(resources.keys()):
        if key.lower().startswith("font/"):
            keep[key] = resources[key]
    if "dial" in doc:
        add("resourceImage/dial.png")
    return keep or dict(resources)


def save(doc: DialDocument, path: str, resources: Optional[Dict[str, bytes]] = None,
         clean: bool = True) -> str:
    """Сохранить .tbwf. Порядок ключей элементов сохраняется."""
    resources = resources or {}
    folder = os.path.dirname(os.path.abspath(path))
    if folder and not os.path.isdir(folder):
        os.makedirs(folder, exist_ok=True)

    text = doc.to_json_text(clean=clean)
    json.loads(text)          # контрольная проверка читаемости

    payload = used_resources(doc, resources)
    tmp_path = path + ".tmp"
    with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(JSON_NAME, text.encode("utf-8"))
        for res_path, data in sorted(payload.items()):
            if not data:
                continue
            arc = normalize_res_path(res_path)
            if arc.lower().endswith(".json"):
                continue
            zf.writestr(arc, data)
    os.replace(tmp_path, path)
    return path


# ------------------------------------------------------------- файл проекта
def save_project(path: str, doc: DialDocument, resources: Dict[str, bytes],
                 meta: Optional[dict] = None) -> str:
    """Промежуточный формат проекта (автосохранение) — JSON с ресурсами в base64."""
    payload = {
        "format": "HaylouWatchfaceStudio.project",
        "format_version": 1,
        "meta": meta or {},
        "document": doc.to_dict(clean=False),
        "resources": {
            normalize_res_path(k): base64.b64encode(v).decode("ascii")
            for k, v in (resources or {}).items() if v
        },
    }
    folder = os.path.dirname(os.path.abspath(path))
    if folder and not os.path.isdir(folder):
        os.makedirs(folder, exist_ok=True)
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=1)
    os.replace(tmp_path, path)
    return path


def load_project(path: str) -> Tuple[DialDocument, Dict[str, bytes], dict]:
    """Прочитать проект: (документ, ресурсы, метаданные)."""
    with open(path, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    if payload.get("format") != "HaylouWatchfaceStudio.project":
        raise ValueError("Это не файл проекта Haylou Watchface Studio")
    doc = DialDocument.from_dict(payload.get("document") or {})
    resources: Dict[str, bytes] = {}
    for key, value in (payload.get("resources") or {}).items():
        try:
            resources[normalize_res_path(key)] = base64.b64decode(value)
        except Exception:
            continue
    return doc, resources, payload.get("meta") or {}


# ----------------------------------------------------------- кадры-последовательности
_GLYPH_ORDER = ["_0", "_1", "_2", "_3", "_4", "_5", "_6", "_7", "_8", "_9",
                "_colon", "_dot", "_percent", "_hyphen", "_degree"]
_WEEKDAY_ORDER = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


def _natural_key(name: str) -> Tuple:
    """Ключ сортировки: числовой хвост, иначе — по имени."""
    base = os.path.splitext(os.path.basename(name))[0]
    m = re.search(r"(\d+)$", base)
    if m:
        return (0, int(m.group(1)), base.lower())
    return (1, 0, base.lower())


def _glyph_key(name: str) -> Tuple:
    base = os.path.splitext(os.path.basename(name))[0].lower()
    if base in _GLYPH_ORDER:
        return (0, _GLYPH_ORDER.index(base), base)
    return (1, 0, base)


def _weekday_key(name: str) -> Tuple:
    base = os.path.splitext(os.path.basename(name))[0].lower()
    for i, tag in enumerate(_WEEKDAY_ORDER):
        if tag in base:
            return (0, i, base)
    return (1, 0, base)


def _sort_frames(paths: Sequence[str], resource_path: str) -> List[str]:
    low = res_key(resource_path)
    if "resourcecharacter" in low:
        return sorted(paths, key=_glyph_key)
    if "dayofweek" in low:
        return sorted(paths, key=_weekday_key)
    return sorted(paths, key=_natural_key)


def iter_frames(resource_path: str, sections: int, resources: Dict[str, bytes]):
    """Кадры элемента как список PIL-картинок.

    Поддерживаются:
      * папка-последовательность ('resourceImage/dayOfWeek/') — все PNG внутри;
      * файл с суффиксом кадра ('resourceImage/x_3.png' или 'x.png' + sections>1);
      * одиночный файл.
    Возвращает (список картинок, список путей).
    """
    from PIL import Image

    def open_bytes(data: bytes):
        try:
            img = Image.open(io.BytesIO(data))
            img.load()
            return img.convert("RGBA")
        except Exception:
            return None

    sections = max(1, int(sections or 1))
    frames: List = []
    paths: List[str] = []
    rp = normalize_res_path(resource_path)

    if rp.endswith("/") or not rp.lower().endswith((".png", ".webp", ".jpg", ".jpeg")):
        keys = folder_keys(resources, rp)
        keys = _sort_frames(keys, rp)
        for key in keys:
            img = open_bytes(resources[key])
            if img is not None:
                frames.append(img)
                paths.append(key)
        return frames, paths

    keys = ([rp] if res_key(rp) in resources else []) or [
        k for k in resources if k.lower() == rp.lower()]
    if keys and sections <= 1:
        img = open_bytes(resources[keys[0]])
        return ([img], [keys[0]]) if img else ([], [])
    if keys:
        # файл с sections>1: ищем варианты '..._N.png' рядом
        base = os.path.splitext(keys[0])[0]
        ext = os.path.splitext(keys[0])[1]
        candidates = [k for k in resources
                      if k.lower().startswith((base + "_").lower()) and k.lower().endswith(ext.lower())]
        if candidates:
            ordered = sorted(candidates, key=_natural_key)
            for key in ordered:
                img = open_bytes(resources[key])
                if img is not None:
                    frames.append(img)
                    paths.append(key)
            return frames, paths
        img = open_bytes(resources[keys[0]])
        return ([img], [keys[0]]) if img else ([], [])
    return [], []


# ------------------------------------------------------------- PNG-ресурсы
def png_bytes(image) -> bytes:
    """PIL-картинка -> байты PNG (RGBA)."""
    buf = io.BytesIO()
    image.save(buf, format="PNG", optimize=True)
    return buf.getvalue()


def image_from_bytes(data: bytes):
    """Байты -> PIL-картинка (или None)."""
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(data))
        img.load()
        return img
    except Exception:
        return None
