# -*- coding: utf-8 -*-
"""Модель документа циферблата.

Ключевое отличие от «наивного» подхода: элементы хранятся в OrderedDict,
потому что в .tbwf порядок ключей = порядок отрисовки (первый — нижний слой).
Всё, чего мы не знаем про формат, складывается в extra/payload и сохраняется
как есть — чтобы файл проходил round-trip без потерь.
"""

from __future__ import annotations

import copy
import json
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional

from . import constants

# Допустимые «виды» ресурса элемента (ключ в JSON)
KIND_KEYS = ("resourceImage", "resourceIcon", "resourceCharacter", "font")
KIND_NONE = "none"


@dataclass
class DialElement:
    """Один элемент циферблата (слой)."""

    name: str
    kind: str = KIND_NONE
    payload: Dict[str, Any] = field(default_factory=dict)
    color: Optional[Dict[str, Any]] = None
    properties: Optional[int] = None
    visible: bool = True
    x: Optional[float] = None
    y: Optional[float] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------ размер
    @property
    def is_text(self) -> bool:
        """Текстовый элемент (шрифт), а не картинка."""
        return self.kind == "font"

    def get_size(self) -> Optional[float]:
        """Размер: у текста — font.size, у картинок — size."""
        if self.kind == "font":
            try:
                return float(self.payload.get("size"))
            except (TypeError, ValueError):
                return None
        try:
            return float(self.payload.get("size"))
        except (TypeError, ValueError):
            return None

    def set_size(self, value: float) -> None:
        self.payload["size"] = float(value)

    def get_sections(self) -> int:
        try:
            return int(self.payload.get("sections", 1))
        except (TypeError, ValueError):
            return 1

    def set_sections(self, value: int) -> None:
        self.payload["sections"] = int(value)

    def get_resource(self) -> str:
        return str(self.payload.get("resource") or self.payload.get("family") or "")

    def get_colors(self) -> List[int]:
        if not self.color:
            return []
        return list(self.color.get("colors") or [])

    def get_gradient(self) -> str:
        if not self.color:
            return "solid"
        return str(self.color.get("gradient") or "solid")

    def set_colors(self, colors: Iterable[int], gradient: str = "solid",
                   positions: Optional[Iterable[float]] = None) -> None:
        cols = [int(c) for c in colors]
        if not cols:
            cols = [-1]
        if gradient == "linear_vertical" and len(cols) < 2:
            cols = cols + [cols[0]]
        pos = list(positions or [])
        if len(pos) != len(cols):
            if len(cols) == 1:
                pos = [0.0]
            else:
                pos = [i / (len(cols) - 1) for i in range(len(cols))]
        self.color = {"colors": cols, "gradient": gradient, "positions": pos}

    def ensure_color(self) -> None:
        if self.color is None:
            self.set_colors([-1])

    # ------------------------------------------------------------- сериализация
    def to_dict(self, clean: bool = False) -> Dict[str, Any]:
        """В словарь JSON. clean=True — выбросить служебные (проектные) ключи."""
        out: Dict[str, Any] = OrderedDict()
        if self.kind in KIND_KEYS:
            out[self.kind] = copy.deepcopy(self.payload)
        if self.color is not None:
            out["color"] = copy.deepcopy(self.color)
        if self.properties is not None:
            out["properties"] = int(self.properties)
        out["visible"] = bool(self.visible)
        if self.x is not None:
            out["x"] = float(self.x)
        if self.y is not None:
            out["y"] = float(self.y)
        for key, value in self.extra.items():
            if clean and key in constants.PRIVATE_KEYS:
                continue
            out[key] = copy.deepcopy(value)
        return out

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> "DialElement":
        data = dict(data or {})
        kind = KIND_NONE
        payload: Dict[str, Any] = {}
        for key in KIND_KEYS:
            if key in data:
                kind = key
                payload = copy.deepcopy(data.get(key) or {})
                break
        known = set(KIND_KEYS) | {"color", "properties", "visible", "x", "y"}
        extra = {k: copy.deepcopy(v) for k, v in data.items() if k not in known}
        color = copy.deepcopy(data.get("color")) if isinstance(data.get("color"), dict) else None
        props = data.get("properties")
        try:
            props = int(props) if props is not None else None
        except (TypeError, ValueError):
            props = None
        x = _as_float(data.get("x"))
        y = _as_float(data.get("y"))
        return cls(name=name, kind=kind, payload=payload, color=color,
                   properties=props, visible=bool(data.get("visible", True)),
                   x=x, y=y, extra=extra)

    def clone(self) -> "DialElement":
        return copy.deepcopy(self)

    # ------------------------------------------------------------------ прочее
    def describe(self) -> str:
        """Короткое описание для статус-бара/списка слоёв."""
        res = self.get_resource()
        parts = [self.kind]
        if res:
            parts.append(res.rstrip("/").split("/")[-1] or res)
        sec = self.get_sections()
        if sec > 1:
            parts.append("секций: %d" % sec)
        return " · ".join(parts)

    def effective_properties(self) -> int:
        """properties с подстановкой типового значения для известных имён."""
        if self.properties is not None:
            return int(self.properties)
        return int(constants.DEFAULT_PROPERTIES_BY_NAME.get(self.name, 0))


def _as_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


@dataclass
class DialDocument:
    """Документ циферблата: верхний уровень + упорядоченный набор слоёв."""

    aspect_ratio: float = constants.ASPECT_RATIO
    case_shape: str = constants.CASE_SHAPE
    version: float = constants.JSON_VERSION
    elements: "OrderedDict[str, DialElement]" = field(default_factory=OrderedDict)
    extra: Dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------- сериализация
    def to_dict(self, clean: bool = False) -> Dict[str, Any]:
        out: Dict[str, Any] = OrderedDict()
        out["aspectRatio"] = float(self.aspect_ratio)
        out["caseShape"] = str(self.case_shape)
        out["elements"] = OrderedDict(
            (name, el.to_dict(clean=clean)) for name, el in self.elements.items()
        )
        out["version"] = float(self.version)
        for key, value in self.extra.items():
            if key in ("aspectRatio", "caseShape", "elements", "version"):
                continue
            out[key] = copy.deepcopy(value)
        return out

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DialDocument":
        data = dict(data or {})
        raw_elements = data.get("elements") or {}
        elements: "OrderedDict[str, DialElement]" = OrderedDict()
        if isinstance(raw_elements, dict):
            items = raw_elements.items()
        elif isinstance(raw_elements, list):
            # На случай списка (в реальных файлах не встречалось, но пусть не падаем)
            items = [(str(i), v) for i, v in enumerate(raw_elements)]
        else:
            items = []
        for name, value in items:
            if isinstance(value, dict):
                elements[str(name)] = DialElement.from_dict(str(name), value)
        known = {"aspectRatio", "caseShape", "elements", "version"}
        extra = {k: copy.deepcopy(v) for k, v in data.items() if k not in known}
        aspect = _as_float(data.get("aspectRatio")) or constants.ASPECT_RATIO
        return cls(aspect_ratio=float(aspect),
                   case_shape=str(data.get("caseShape") or constants.CASE_SHAPE),
                   version=float(_as_float(data.get("version")) or constants.JSON_VERSION),
                   elements=elements, extra=extra)

    def to_json_text(self, clean: bool = True) -> str:
        return json.dumps(self.to_dict(clean=clean), ensure_ascii=False, indent=2)

    def clone(self) -> "DialDocument":
        return copy.deepcopy(self)

    # ---------------------------------------------------------------- операции
    def get(self, name: str) -> Optional[DialElement]:
        return self.elements.get(name)

    def names(self) -> List[str]:
        return list(self.elements.keys())

    def __contains__(self, name: str) -> bool:
        return name in self.elements

    def __len__(self) -> int:
        return len(self.elements)

    def add(self, name: str, element: Optional[DialElement] = None,
            index: Optional[int] = None) -> DialElement:
        """Добавить слой. Если имя занято — добавляется числовой суффикс."""
        name = self.unique_name(name)
        el = element or DialElement(name=name)
        el.name = name
        if index is None or index >= len(self.elements):
            self.elements[name] = el
        else:
            items = list(self.elements.items())
            items.insert(max(0, index), (name, el))
            self.elements = OrderedDict(items)
        return el

    def remove(self, name: str) -> bool:
        if name in self.elements:
            del self.elements[name]
            return True
        return False

    def move(self, name: str, index: int) -> bool:
        """Переместить слой на новую позицию (0 — самый нижний)."""
        if name not in self.elements:
            return False
        items = [(n, e) for n, e in self.elements.items() if n != name]
        index = max(0, min(int(index), len(items)))
        el = self.elements[name]
        items.insert(index, (name, el))
        self.elements = OrderedDict(items)
        return True

    def move_by(self, name: str, delta: int) -> bool:
        idx = self.index_of(name)
        if idx < 0:
            return False
        return self.move(name, idx + int(delta))

    def index_of(self, name: str) -> int:
        for i, key in enumerate(self.elements.keys()):
            if key == name:
                return i
        return -1

    def unique_name(self, base: str) -> str:
        base = (base or "element").strip() or "element"
        if base not in self.elements:
            return base
        i = 2
        while ("%s_%d" % (base, i)) in self.elements:
            i += 1
        return "%s_%d" % (base, i)

    def rename(self, old: str, new: str) -> bool:
        """Переименовать слой с сохранением позиции в порядке отрисовки."""
        if old not in self.elements or not new:
            return False
        if new == old:
            return True
        new_name = self.unique_name(new)
        items = []
        for key, el in self.elements.items():
            if key == old:
                el.name = new_name
                items.append((new_name, el))
            else:
                items.append((key, el))
        self.elements = OrderedDict(items)
        return True

    def visible_elements(self) -> List[DialElement]:
        return [el for el in self.elements.values() if el.visible]

    def all_elements(self) -> List[DialElement]:
        return list(self.elements.values())

    def find_by_role(self, role: str) -> List[DialElement]:
        """Найти элементы по смысловой роли (см. catalog.data_role)."""
        from . import catalog
        out = []
        for el in self.elements.values():
            info = catalog.get_info(el.name)
            if info.get("data_role") == role:
                out.append(el)
        return out
