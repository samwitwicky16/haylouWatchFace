# -*- coding: utf-8 -*-
"""Работа с растровыми ресурсами: загрузка PNG/WebP, перекраска, вписывание, кэш.

Особенность формата: color 0 означает «не перекрашивать» (иконка остаётся как
нарисована), -1 — белый. Для своих PNG/WebP мы сохраняем прозрачность и
перекрашиваем только непрозрачные пиксели (альфа остаётся исходной).
"""

from __future__ import annotations

import hashlib
import io
import os
from typing import Dict, Optional, Tuple

from PIL import Image

RESAMPLE = getattr(Image, "Resampling", Image).LANCZOS

# Кэш перекрашенных/масштабированных картинок: ключ -> Image
_CACHE: Dict[Tuple[str, int, int, int], Image.Image] = {}
_CACHE_LIMIT = 400


def load_image(path: str) -> Optional[Image.Image]:
    """Прочитать PNG/WebP/JPEG с диска (с сохранением альфы)."""
    try:
        img = Image.open(path)
        img.load()
        if img.mode != "RGBA":
            img = img.convert("RGBA")
        return img
    except Exception:
        return None


def load_image_bytes(data: bytes) -> Optional[Image.Image]:
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
        return img.convert("RGBA") if img.mode != "RGBA" else img
    except Exception:
        return None


def tint(image: Image.Image, rgba: Optional[Tuple[int, int, int, int]]) -> Image.Image:
    """Перекрасить непрозрачные пиксели в цвет, сохранив альфу.

    rgba=None (или альфа 0) — вернуть картинку как есть (режим «не перекрашивать»).
    """
    if rgba is None:
        return image
    r, g, b, a = rgba
    if a == 0:
        return image
    img = image.convert("RGBA")
    r_ch, g_ch, b_ch, a_ch = img.split()
    base = Image.new("RGBA", img.size, (r, g, b, a))
    base.putalpha(a_ch)
    return base


def fit_size(image: Image.Image, width: int, height: int) -> Image.Image:
    """Растянуть картинку ровно под размер (без сохранения пропорций)."""
    return image.resize((max(1, int(width)), max(1, int(height))), RESAMPLE)


def fit_into(image: Image.Image, box_w: int, box_h: int) -> Image.Image:
    """Вписать с сохранением пропорций внутрь рамки."""
    box_w = max(1, int(box_w))
    box_h = max(1, int(box_h))
    k = min(box_w / image.width, box_h / image.height)
    size = (max(1, int(round(image.width * k))), max(1, int(round(image.height * k))))
    return image.resize(size, RESAMPLE)


def scale_to_height(image: Image.Image, height: int) -> Image.Image:
    height = max(1, int(height))
    width = max(1, int(round(image.width * height / max(1, image.height))))
    return image.resize((width, height), RESAMPLE)


def image_hash(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()[:12]


def cached(key: str, size: Tuple[int, int], rgba: Tuple[int, int, int, int],
           factory) -> Image.Image:
    """Кэш результата по (ключ ресурса, размер, цвет)."""
    ck = (key, int(size[0]), int(size[1]), int(rgba[0] << 24 | rgba[1] << 16 | rgba[2] << 8 | rgba[3]))
    hit = _CACHE.get(ck)
    if hit is not None:
        return hit
    img = factory()
    if len(_CACHE) > _CACHE_LIMIT:
        _CACHE.clear()
    _CACHE[ck] = img
    return img


def clear_cache() -> None:
    _CACHE.clear()


def guess_mime(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    return {".png": "image/png", ".webp": "image/webp",
            ".jpg": "image/jpeg", ".jpeg": "image/jpeg"}.get(ext, "image/png")
