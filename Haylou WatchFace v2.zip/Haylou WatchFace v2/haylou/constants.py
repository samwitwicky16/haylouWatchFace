# -*- coding: utf-8 -*-
"""Константы устройства и формата .tbwf.

Здесь собраны все «магические числа» формата в одном месте,
чтобы остальные модули не дублировали их.
"""

# --- целевое устройство: Haylou RS5 ---------------------------------------
SCREEN_W = 410          # ширина экрана в пикселях
SCREEN_H = 502          # высота экрана в пикселях
ASPECT_RATIO = round(SCREEN_W / SCREEN_H, 8)   # 0.81673307
CASE_SHAPE = "rectangle"
TARGET_DEVICE = "Haylou RS5"

# Наблюдённые значения у RS4 (для предупреждения при импорте)
LEGACY_ASPECTS = (0.82142854, 0.85714287)

# --- формат архива --------------------------------------------------------
JSON_NAME = "TiBoWaFe.json"      # ровно такое имя внутри архива
JSON_VERSION = 1.0
RES_IMAGE_DIR = "/resourceImage/"
RES_CHAR_DIR = "/resourceCharacter/"
FONT_DIR = "/font/"

# --- наблюдаемые значения полей (из 10 реальных файлов) -------------------
OBSERVED_PROPERTIES = [1, 2, 4, 6, 10, 11, 12, 14, 16, 17, 20, 32, 33, 34, 36, 64, 65, 68]
OBSERVED_SECTIONS = [1, 2, 4, 5, 6, 7, 10, 11, 12, 14, 16]
GRADIENT_KINDS = ("solid", "linear_vertical")

# Значения properties по смыслу имени (копируем из рабочих примеров,
# ничего не изобретаем — иначе Hello Haylou может отказаться конвертировать).
DEFAULT_PROPERTIES_BY_NAME = {
    "hourHand": 1,
    "minuteHand": 1,
    "secondHand": 4,
    "dayOfWeek": 34,
    "battery": 36,
    "weatherTemperature": 4,
    "weatherTemperatureUnitSign": 4,
}

# Служебные имена встроенных шрифтов Hello Haylou -> ближайший системный.
# Используется ТОЛЬКО для превью: в JSON всегда пишется служебное имя.
BUILTIN_FONT_FALLBACK = {
    "sans-serif": "Segoe UI",
    "sans-serif-medium": "Segoe UI Semibold",
    "sans-serif-black": "Segoe UI Black",
    "rubik_light": "Segoe UI Light",
    "rubik_regular": "Segoe UI",
    "rubik_medium": "Segoe UI Semibold",
    "rubik_bold": "Segoe UI Bold",
    "oswald_medium": "Arial Narrow",
    "oswald_bold": "Arial Narrow Bold",
    "big_shoulders_text_regular": "Arial Black",
    "big_shoulders_text_medium": "Arial Black",
    "fira_sans_condensed_regular": "Consolas",
    "fira_sans_condensed_medium": "Consolas",
    "fira_sans_condensed_bold": "Consolas Bold",
}

# Кандидаты файлов системных шрифтов (первый существующий побеждает)
FONT_FILE_CANDIDATES = {
    "sans-serif": ["segoeui.ttf", "arial.ttf", "DejaVuSans.ttf"],
    "sans-serif-medium": ["seguisb.ttf", "segoeui.ttf", "arial.ttf"],
    "sans-serif-black": ["seguibl.ttf", "seguisb.ttf", "arialbd.ttf"],
    "rubik_light": ["segoeuil.ttf", "segoeui.ttf"],
    "rubik_regular": ["segoeui.ttf", "arial.ttf"],
    "rubik_medium": ["seguisb.ttf", "segoeui.ttf"],
    "rubik_bold": ["segoeuib.ttf", "arialbd.ttf"],
    "oswald_medium": ["arialn.ttf", "impact.ttf", "arial.ttf"],
    "oswald_bold": ["arialnb.ttf", "impact.ttf", "arialbd.ttf"],
    "big_shoulders_text_regular": ["ariblk.ttf", "impact.ttf", "arialbd.ttf"],
    "big_shoulders_text_medium": ["ariblk.ttf", "impact.ttf", "arialbd.ttf"],
    "fira_sans_condensed_regular": ["consola.ttf", "cour.ttf"],
    "fira_sans_condensed_medium": ["consola.ttf", "cour.ttf"],
    "fira_sans_condensed_bold": ["consolab.ttf", "courbd.ttf"],
}

# --- погода: 16 состояний, как в weatherResource ---------------------------
WEATHER_STATES = [
    (0, "Ясно"),
    (1, "Малооблачно"),
    (2, "Облачно"),
    (3, "Пасмурно"),
    (4, "Дождь"),
    (5, "Ливень"),
    (6, "Гроза"),
    (7, "Снег"),
    (8, "Метель"),
    (9, "Туман"),
    (10, "Ветер"),
    (11, "Жара"),
    (12, "Мороз"),
    (13, "Гололёд"),
    (14, "Ясно (ночь)"),
    (15, "Неизвестно"),
]
WEATHER_RU = dict(WEATHER_STATES)

# --- список официальных id встроенных иконок Hello Haylou (для подсказок) --
# В архив пишется именно этот id, а превью показывает нашу похожую иконку.
BUILTIN_ICON_IDS = [
    "batteryResource_ic_wf_anim_battery_circle.png",
    "batteryResource_ic_wf_anim_battery_horizontal.png",
    "batteryResource_ic_wf_anim_battery_semicircular.png",
    "batteryResource_ic_wf_anim_battery_vertical.png",
    "calorieResource_ic_wf_calorie_burn.png",
    "calorieResource_ic_wf_calorie_burn_5.png",
    "connectionResource_ic_wf_anim_connection_ble.png",
    "connectionResource_ic_wf_anim_connection_link.png",
    "distanceResource_ic_wf_distance_direction.png",
    "distanceResource_ic_wf_distance_map_marker.png",
    "heartRateResource_ic_wf_heart_rate_beat.png",
    "heartRateResource_ic_wf_heart_rate_favorite.png",
    "hourHand_ic_wf_hand_hour_fill.png",
    "hourHand_ic_wf_hand_hour_fill_2.png",
    "hourHand_ic_wf_hand_hour_outline.png",
    "hourHand_ic_wf_hand_hour_round.png",
    "minuteHand_ic_wf_hand_minute_fill.png",
    "minuteHand_ic_wf_hand_minute_fill_2.png",
    "minuteHand_ic_wf_hand_minute_outline.png",
    "minuteHand_ic_wf_hand_minute_round.png",
    "secondHand_ic_wf_hand_second_fill.png",
    "secondHand_ic_wf_hand_second_fill_2.png",
    "secondHand_ic_wf_hand_second_outline.png",
    "secondHand_ic_wf_hand_second_round.png",
    "stepGoalProgressResource_ic_wf_anim_goal_circular.png",
    "stepResource_ic_wf_step_foot_print.png",
    "stepResource_ic_wf_step_shoe_print.png",
    "stepResource_ic_wf_step_sneakers_2.png",
    "weatherResource_ic_wf_anim_weather_fill.png",
    "weatherResource_ic_wf_anim_weather_outline.png",
]

# Символы, которые умеет рендерить resourceCharacter (по именам файлов-глифов)
CHAR_GLYPHS = {
    "0": "_0", "1": "_1", "2": "_2", "3": "_3", "4": "_4",
    "5": "_5", "6": "_6", "7": "_7", "8": "_8", "9": "_9",
    ":": "_colon", ".": "_dot", "%": "_percent",
    "-": "_hyphen", "−": "_hyphen", "°": "_degree",
}

# Служебные (проектные) ключи, которые НЕ пишутся в .tbwf
EXT_BLINK = "_blink"      # настройка «моргания» элемента (только для запекания)
EXT_COND = "_cond"        # условия по данным (только для превью и запекания)
EXT_CUSTOM_ICON = "_custom_icon"   # имя своей иконки для превью

PRIVATE_KEYS = {EXT_BLINK, EXT_COND, EXT_CUSTOM_ICON,
                "_blink_period", "_locked", "_note"}

# Пути проекта
PROJECT_DIR = r"C:\Haylou"
SAMPLES_DIR = r"C:\Haylou\samples"
PROJECTS_DIR = r"C:\Haylou\projects"
DOCS_DIR = r"C:\Haylou\docs"
EXAMPLES_DIR = r"C:\Haylou\examples"
AUTOSAVE_PATH = r"C:\Haylou\projects\autosave.haylou.json"
ERROR_LOG = r"C:\Haylou\projects\error.log"
