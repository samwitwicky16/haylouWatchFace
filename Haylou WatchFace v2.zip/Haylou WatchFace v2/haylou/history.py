# -*- coding: utf-8 -*-
"""Undo/Redo для документа циферблата.

Храним снимки документа (полные копии). Документы маленькие (десятки элементов),
поэтому простота важнее экономии памяти: 60 шагов истории — это доли мегабайта.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

from .model import DialDocument


class History:
    """Стек состояний документа с подписями действий."""

    def __init__(self, limit: int = 60) -> None:
        self.limit = max(5, int(limit))
        self._states: List[DialDocument] = []
        self._labels: List[str] = []
        self._index = -1

    # ------------------------------------------------------------------ служебное
    def reset(self, doc: DialDocument, label: str = "Открытие проекта") -> None:
        self._states = [doc.clone()]
        self._labels = [label]
        self._index = 0

    def clear(self) -> None:
        self._states = []
        self._labels = []
        self._index = -1

    # ------------------------------------------------------------------ запись
    def push(self, doc: DialDocument, label: str = "Изменение") -> None:
        """Зафиксировать новое состояние (после изменения документа)."""
        if self._index < 0:
            self.reset(doc, label)
            return
        # всё, что было «впереди» после отмен — отбрасываем
        del self._states[self._index + 1:]
        del self._labels[self._index + 1:]
        self._states.append(doc.clone())
        self._labels.append(label)
        self._index += 1
        while len(self._states) > self.limit:
            self._states.pop(0)
            self._labels.pop(0)
            self._index -= 1

    # ------------------------------------------------------------------ отмена
    def can_undo(self) -> bool:
        return self._index > 0

    def can_redo(self) -> bool:
        return 0 <= self._index < len(self._states) - 1

    def undo_label(self) -> str:
        return self._labels[self._index] if 0 <= self._index < len(self._labels) else ""

    def redo_label(self) -> str:
        if 0 <= self._index + 1 < len(self._labels):
            return self._labels[self._index + 1]
        return ""

    def undo(self) -> Optional[Tuple[DialDocument, str]]:
        """Вернуть предыдущее состояние и подпись отменённого действия."""
        if not self.can_undo():
            return None
        label = self._labels[self._index]
        self._index -= 1
        return self._states[self._index].clone(), label

    def redo(self) -> Optional[Tuple[DialDocument, str]]:
        """Вернуть следующее состояние и подпись повторённого действия."""
        if not self.can_redo():
            return None
        self._index += 1
        return self._states[self._index].clone(), self._labels[self._index]

    def depth(self) -> Tuple[int, int]:
        """(сколько шагов назад, сколько вперёд) — для кнопок тулбара."""
        return self._index, max(0, len(self._states) - 1 - self._index)
